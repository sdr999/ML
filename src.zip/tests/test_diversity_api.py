# coding: utf-8

from fastapi.testclient import TestClient


from typing import Any  # noqa: F401
from hire_pilot.models.diversity import Diversity  # noqa: F401


def test_profile_diversity_get(client: TestClient):
    """Test case for profile_diversity_get

    Get diversity info
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/diversity",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_diversity_put(client: TestClient):
    """Test case for profile_diversity_put

    Update diversity info
    """
    diversity = {"disability_status":1,"gov_military_experience":1,"gender":"MALE","maternity_plan":1,"career_break":1}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/diversity",
    #    headers=headers,
    #    json=diversity,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

