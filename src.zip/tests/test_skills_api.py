# coding: utf-8

from fastapi.testclient import TestClient


from pydantic import StrictStr  # noqa: F401
from typing import Any, List  # noqa: F401


def test_profile_skills_get(client: TestClient):
    """Test case for profile_skills_get

    Get user skills
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/skills",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_skills_put(client: TestClient):
    """Test case for profile_skills_put

    Replace all user skills
    """
    request_body = [['request_body_example']]

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/skills",
    #    headers=headers,
    #    json=request_body,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

