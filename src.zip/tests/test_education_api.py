# coding: utf-8

from fastapi.testclient import TestClient


from pydantic import Field, StrictStr  # noqa: F401
from typing import Any, List  # noqa: F401
from typing_extensions import Annotated  # noqa: F401
from hire_pilot.models.education import Education  # noqa: F401
from hire_pilot.models.education_input import EducationInput  # noqa: F401


def test_profile_education_get(client: TestClient):
    """Test case for profile_education_get

    Get all education
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/education",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_education_id_delete(client: TestClient):
    """Test case for profile_education_id_delete

    Delete specific education
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/profile/education/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_education_id_get(client: TestClient):
    """Test case for profile_education_id_get

    Get specific education
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/education/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_education_id_put(client: TestClient):
    """Test case for profile_education_id_put

    Update specific education
    """
    education_input = {"college_tier":"college_tier","end_date":"end_date","score":0.8008281904610115,"degree_name":"degree_name","tech_stack":["tech_stack","tech_stack"],"currently_pursuing":0,"certificate":"certificate","description":"description","org_name":"org_name","degree_level":"12TH","start_date":"start_date"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/education/{id}".format(id='id_example'),
    #    headers=headers,
    #    json=education_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_education_post(client: TestClient):
    """Test case for profile_education_post

    Add education (Max 3)
    """
    education_input = {"college_tier":"college_tier","end_date":"end_date","score":0.8008281904610115,"degree_name":"degree_name","tech_stack":["tech_stack","tech_stack"],"currently_pursuing":0,"certificate":"certificate","description":"description","org_name":"org_name","degree_level":"12TH","start_date":"start_date"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/profile/education",
    #    headers=headers,
    #    json=education_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

