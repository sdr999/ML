# coding: utf-8

from fastapi.testclient import TestClient


from pydantic import Field, StrictStr  # noqa: F401
from typing import Any, List, Optional  # noqa: F401
from typing_extensions import Annotated  # noqa: F401
from hire_pilot.models.employment_detail import EmploymentDetail  # noqa: F401
from hire_pilot.models.employment_detail_input import EmploymentDetailInput  # noqa: F401
from hire_pilot.models.error_response import ErrorResponse  # noqa: F401


def test_profile_employment_details_get(client: TestClient):
    """Test case for profile_employment_details_get

    Get all employment details
    """
    params = [("page", 1),     ("limit", 20)]
    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/employment-details",
    #    headers=headers,
    #    params=params,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_employment_details_id_delete(client: TestClient):
    """Test case for profile_employment_details_id_delete

    Delete employment detail
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/profile/employment-details/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_employment_details_id_get(client: TestClient):
    """Test case for profile_employment_details_id_get

    Get specific employment detail
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/employment-details/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_employment_details_id_put(client: TestClient):
    """Test case for profile_employment_details_id_put

    Update employment detail
    """
    employment_detail_input = {"preferred_salary":1.4658129805029452,"current_notice_period_days":6,"last_working_day":"2000-01-23","preferred_location":["preferred_location","preferred_location"],"current_salary":0.8008281904610115,"currency":"currency","serving_notice":0,"preferred_working_hours":"preferred_working_hours","preferred_role":"preferred_role","work_mode":"REMOTE","preferred_currency":"preferred_currency","current_location":"current_location"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/employment-details/{id}".format(id='id_example'),
    #    headers=headers,
    #    json=employment_detail_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_employment_details_post(client: TestClient):
    """Test case for profile_employment_details_post

    Add employment details record
    """
    employment_detail_input = {"preferred_salary":1.4658129805029452,"current_notice_period_days":6,"last_working_day":"2000-01-23","preferred_location":["preferred_location","preferred_location"],"current_salary":0.8008281904610115,"currency":"currency","serving_notice":0,"preferred_working_hours":"preferred_working_hours","preferred_role":"preferred_role","work_mode":"REMOTE","preferred_currency":"preferred_currency","current_location":"current_location"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/profile/employment-details",
    #    headers=headers,
    #    json=employment_detail_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

