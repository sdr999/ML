# coding: utf-8

from fastapi.testclient import TestClient


from pydantic import Field, StrictStr  # noqa: F401
from typing import Any, List  # noqa: F401
from typing_extensions import Annotated  # noqa: F401
from hire_pilot.models.language import Language  # noqa: F401
from hire_pilot.models.language_input import LanguageInput  # noqa: F401


def test_profile_languages_get(client: TestClient):
    """Test case for profile_languages_get

    Get all languages
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/languages",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_languages_id_delete(client: TestClient):
    """Test case for profile_languages_id_delete

    Delete language
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/profile/languages/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_languages_id_get(client: TestClient):
    """Test case for profile_languages_id_get

    Get specific language
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/languages/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_languages_id_put(client: TestClient):
    """Test case for profile_languages_id_put

    Update language
    """
    language_input = {"speaking_prof":"NATIVE","writing_prof":"NATIVE","document":"document","name":"name","reading_prof":"NATIVE"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/languages/{id}".format(id='id_example'),
    #    headers=headers,
    #    json=language_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_languages_post(client: TestClient):
    """Test case for profile_languages_post

    Add language
    """
    language_input = {"speaking_prof":"NATIVE","writing_prof":"NATIVE","document":"document","name":"name","reading_prof":"NATIVE"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/profile/languages",
    #    headers=headers,
    #    json=language_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

