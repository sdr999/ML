# coding: utf-8

from fastapi.testclient import TestClient


from typing import Any  # noqa: F401
from hire_pilot.models.error_response import ErrorResponse  # noqa: F401
from hire_pilot.models.profile_resume_parse_post_request import ProfileResumeParsePostRequest  # noqa: F401


def test_profile_resume_parse_post(client: TestClient):
    """Test case for profile_resume_parse_post

    Autofill profile with Resume
    """
    profile_resume_parse_post_request = ProfileResumeParsePostRequest()

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/profile/resume-parse",
    #    headers=headers,
    #    json=profile_resume_parse_post_request,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

