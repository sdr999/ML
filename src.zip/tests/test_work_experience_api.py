# coding: utf-8

from fastapi.testclient import TestClient


from pydantic import Field, StrictStr  # noqa: F401
from typing import Any, List, Optional  # noqa: F401
from typing_extensions import Annotated  # noqa: F401
from hire_pilot.models.error_response import ErrorResponse  # noqa: F401
from hire_pilot.models.work_experience import WorkExperience  # noqa: F401
from hire_pilot.models.work_experience_input import WorkExperienceInput  # noqa: F401


def test_profile_work_experience_get(client: TestClient):
    """Test case for profile_work_experience_get

    Get all work experience
    """
    params = [("page", 1),     ("limit", 20)]
    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/work-experience",
    #    headers=headers,
    #    params=params,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_work_experience_id_delete(client: TestClient):
    """Test case for profile_work_experience_id_delete

    Delete specific work experience
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/profile/work-experience/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_work_experience_id_get(client: TestClient):
    """Test case for profile_work_experience_id_get

    Get specific work experience
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/work-experience/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_work_experience_id_put(client: TestClient):
    """Test case for profile_work_experience_id_put

    Update specific work experience
    """
    work_experience_input = {"end_date":"end_date","role":"role","tech_stack":["tech_stack","tech_stack"],"company_name":"company_name","relevant_document":"relevant_document","description":"description","location":"location","start_date":"start_date","currently_working":0}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/work-experience/{id}".format(id='id_example'),
    #    headers=headers,
    #    json=work_experience_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_work_experience_post(client: TestClient):
    """Test case for profile_work_experience_post

    Add work experience
    """
    work_experience_input = {"end_date":"end_date","role":"role","tech_stack":["tech_stack","tech_stack"],"company_name":"company_name","relevant_document":"relevant_document","description":"description","location":"location","start_date":"start_date","currently_working":0}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/profile/work-experience",
    #    headers=headers,
    #    json=work_experience_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

