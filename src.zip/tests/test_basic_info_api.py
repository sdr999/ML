# coding: utf-8

from fastapi.testclient import TestClient


from typing import Any  # noqa: F401
from hire_pilot.models.basic_info import BasicInfo  # noqa: F401
from hire_pilot.models.error_response import ErrorResponse  # noqa: F401


def test_profile_basic_info_get(client: TestClient):
    """Test case for profile_basic_info_get

    Get basic info
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/basic-info",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_basic_info_put(client: TestClient):
    """Test case for profile_basic_info_put

    Update basic info
    """
    basic_info = {"github":"https://openapi-generator.tech","address":"address","name":"name","mobile":"mobile","linkedin":"https://openapi-generator.tech","additional_prop":{"key":""},"email":"email"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/basic-info",
    #    headers=headers,
    #    json=basic_info,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

