# coding: utf-8

from fastapi.testclient import TestClient


from pydantic import Field, StrictStr  # noqa: F401
from typing import Any, List  # noqa: F401
from typing_extensions import Annotated  # noqa: F401
from hire_pilot.models.personal_project import PersonalProject  # noqa: F401
from hire_pilot.models.personal_project_input import PersonalProjectInput  # noqa: F401


def test_profile_projects_get(client: TestClient):
    """Test case for profile_projects_get

    Get all projects
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/projects",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_projects_id_delete(client: TestClient):
    """Test case for profile_projects_id_delete

    Delete project
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/profile/projects/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_projects_id_get(client: TestClient):
    """Test case for profile_projects_id_get

    Get specific project
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/projects/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_projects_id_put(client: TestClient):
    """Test case for profile_projects_id_put

    Update project
    """
    personal_project_input = {"tech_stack":["tech_stack","tech_stack"],"name":"name","start":"start","description":"description","end":"end","url":"https://openapi-generator.tech"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/projects/{id}".format(id='id_example'),
    #    headers=headers,
    #    json=personal_project_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_projects_post(client: TestClient):
    """Test case for profile_projects_post

    Add project
    """
    personal_project_input = {"tech_stack":["tech_stack","tech_stack"],"name":"name","start":"start","description":"description","end":"end","url":"https://openapi-generator.tech"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/profile/projects",
    #    headers=headers,
    #    json=personal_project_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

