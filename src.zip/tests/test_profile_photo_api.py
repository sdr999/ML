# coding: utf-8

from fastapi.testclient import TestClient


from typing import Any  # noqa: F401
from hire_pilot.models.profile_photo_get200_response import ProfilePhotoGet200Response  # noqa: F401


def test_profile_photo_delete(client: TestClient):
    """Test case for profile_photo_delete

    Remove profile photo
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/profile/photo",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_photo_get(client: TestClient):
    """Test case for profile_photo_get

    Get profile photo
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/photo",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_photo_put(client: TestClient):
    """Test case for profile_photo_put

    Upload profile photo
    """
    profile_photo_get200_response = ProfilePhotoGet200Response()

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/photo",
    #    headers=headers,
    #    json=profile_photo_get200_response,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

