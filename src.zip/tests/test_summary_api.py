# coding: utf-8

from fastapi.testclient import TestClient


from typing import Any  # noqa: F401
from hire_pilot.models.profile_summary_get200_response import ProfileSummaryGet200Response  # noqa: F401
from hire_pilot.models.profile_summary_put_request import ProfileSummaryPutRequest  # noqa: F401


def test_profile_summary_get(client: TestClient):
    """Test case for profile_summary_get

    Get summary
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/summary",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_summary_put(client: TestClient):
    """Test case for profile_summary_put

    Update summary
    """
    profile_summary_put_request = ProfileSummaryPutRequest()

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/summary",
    #    headers=headers,
    #    json=profile_summary_put_request,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

