# coding: utf-8

from fastapi.testclient import TestClient


from pydantic import Field, StrictStr  # noqa: F401
from typing import Any, List  # noqa: F401
from typing_extensions import Annotated  # noqa: F401
from hire_pilot.models.certification import Certification  # noqa: F401
from hire_pilot.models.certification_input import CertificationInput  # noqa: F401


def test_profile_certifications_get(client: TestClient):
    """Test case for profile_certifications_get

    Get all certifications
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/certifications",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_certifications_id_delete(client: TestClient):
    """Test case for profile_certifications_id_delete

    Delete certification
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/profile/certifications/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_certifications_id_get(client: TestClient):
    """Test case for profile_certifications_id_get

    Get specific certification
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/certifications/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_certifications_id_put(client: TestClient):
    """Test case for profile_certifications_id_put

    Update certification
    """
    certification_input = {"end_date":"2000-01-23","org":"org","document":"document","name":"name","description":"description","url":"https://openapi-generator.tech"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/certifications/{id}".format(id='id_example'),
    #    headers=headers,
    #    json=certification_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_certifications_post(client: TestClient):
    """Test case for profile_certifications_post

    Add certification
    """
    certification_input = {"end_date":"2000-01-23","org":"org","document":"document","name":"name","description":"description","url":"https://openapi-generator.tech"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/profile/certifications",
    #    headers=headers,
    #    json=certification_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

