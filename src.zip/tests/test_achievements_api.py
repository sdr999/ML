# coding: utf-8

from fastapi.testclient import TestClient


from pydantic import Field, StrictStr  # noqa: F401
from typing import Any, List  # noqa: F401
from typing_extensions import Annotated  # noqa: F401
from hire_pilot.models.achievement import Achievement  # noqa: F401
from hire_pilot.models.achievement_input import AchievementInput  # noqa: F401


def test_profile_achievements_get(client: TestClient):
    """Test case for profile_achievements_get

    Get all achievements
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/achievements",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_achievements_id_delete(client: TestClient):
    """Test case for profile_achievements_id_delete

    Delete achievement
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/profile/achievements/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_achievements_id_get(client: TestClient):
    """Test case for profile_achievements_id_get

    Get specific achievement
    """

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/profile/achievements/{id}".format(id='id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_achievements_id_put(client: TestClient):
    """Test case for profile_achievements_id_put

    Update achievement
    """
    achievement_input = {"org":"org","name":"name","description":"description","time":"2000-01-23"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/profile/achievements/{id}".format(id='id_example'),
    #    headers=headers,
    #    json=achievement_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_profile_achievements_post(client: TestClient):
    """Test case for profile_achievements_post

    Add achievement
    """
    achievement_input = {"org":"org","name":"name","description":"description","time":"2000-01-23"}

    headers = {
        "Authorization": "Bearer special-key",
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/profile/achievements",
    #    headers=headers,
    #    json=achievement_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

