# coding: utf-8

from fastapi.testclient import TestClient


from typing import Any  # noqa: F401
from hire_pilot.models.auth_response import AuthResponse  # noqa: F401
from hire_pilot.models.error_response import ErrorResponse  # noqa: F401
from hire_pilot.models.sign_in_request import SignInRequest  # noqa: F401
from hire_pilot.models.sign_up_request import SignUpRequest  # noqa: F401


def test_auth_signin_post(client: TestClient):
    """Test case for auth_signin_post

    User Sign In
    """
    sign_in_request = {"password":"password","captcha":"captcha","username":"username"}

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/auth/signin",
    #    headers=headers,
    #    json=sign_in_request,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_auth_signup_post(client: TestClient):
    """Test case for auth_signup_post

    User Sign Up (Supabase)
    """
    sign_up_request = {"password":"password","dob":"2000-01-23","additional":{"key":""},"mobile_no":"mobile_no","last_name":"last_name","middle_name":"middle_name","first_name":"first_name","email":"email","confirm_password":"confirm_password"}

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/auth/signup",
    #    headers=headers,
    #    json=sign_up_request,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

