"""
HirePilot End-to-End Flow Test
================================
Tests all 16 newly created endpoints in a realistic hiring lifecycle.

Flow:
  SETUP      -> Generate tokens for existing users, create & publish a job
  PHASE 1    -> Employer compliance: verify PAN / GST / company-docs, view policies
  PHASE 2    -> Public job board: browse jobs, view detail (fires JOB_VIEW), log JOB_CLICK
  PHASE 3    -> Candidate applies for the job
  PHASE 4    -> Employer analytics: dashboard, job report, candidate report, interview report
  PHASE 5    -> Employer shortlists, schedules interview
  PHASE 6    -> Candidate confirms interview  [NEW]
  PHASE 7    -> Employer submits interview feedback
  PHASE 8    -> Employer makes formal offer   [NEW]
  PHASE 9    -> Candidate accepts offer -> HIRED  [NEW]
  PHASE 10   -> Re-check dashboard (funnel_hired should be 1)
  PHASE 11   -> Employer reports a candidate  [NEW]
  EDGE CASES -> Duplicate submissions, bad IDs, re-responses

Run:
  PYTHONPATH=src python e2e_flow_test.py
  (server must be running on localhost:8080)
"""

import sys
import time
import json
import requests
import jwt as pyjwt
from dotenv import dotenv_values

BASE = "http://localhost:8080"

# Load SUPABASE_JWT_SECRET for local token generation (no Supabase call needed)
_env = dotenv_values("src/hire_pilot/config/.env")
_JWT_SECRET = _env.get("SUPABASE_JWT_SECRET", "")

GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
RESET  = "\033[0m"
BOLD   = "\033[1m"

results: list[dict] = []


def generate_token(user_id: str) -> str:
    """Generate a local HS256 JWT accepted by the server Tier-1 decode."""
    payload = {
        "sub": user_id,
        "iat": int(time.time()),
        "exp": int(time.time()) + 3600,
        "role": "authenticated",
    }
    return pyjwt.encode(payload, _JWT_SECRET, algorithm="HS256")


def _step(label: str, method: str, path: str,
          expected: int, resp: requests.Response) -> dict:
    ok = resp.status_code == expected
    mark = f"{GREEN}PASS{RESET}" if ok else f"{RED}FAIL{RESET}"
    try:
        body = resp.json()
    except Exception:
        body = resp.text[:200]
    print(f"  {mark}  [{resp.status_code}]  {label}")
    if not ok:
        print(f"         {YELLOW}expected {expected} | body: {json.dumps(body)[:300]}{RESET}")
    results.append({
        "label": label, "method": method, "path": path,
        "expected": expected, "got": resp.status_code,
        "pass": ok, "body": body,
    })
    return body if ok else {}


def step(label: str, method: str, path: str, expected: int,
         token: str | None = None, json_body=None, params=None) -> dict:
    url = f"{BASE}{path}"
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    resp = requests.request(method, url, json=json_body, params=params,
                            headers=headers, timeout=30)
    return _step(label, method, path, expected, resp)


# ==============================================================================
# SETUP
# ==============================================================================

def setup() -> tuple[str, str, str, str]:
    """
    Returns (employer_token, candidate_token, job_id, candidate_user_id).
    Uses local JWT generation (SUPABASE_JWT_SECRET) - no Supabase call needed.
    """
    EMPLOYER_ID  = "4749e88f-4509-414e-9746-8cf893e1ba51"
    CANDIDATE_ID = "e3285a49-5b79-4813-87a9-7f3314afcdd2"

    if not _JWT_SECRET:
        sys.exit(f"{RED}SUPABASE_JWT_SECRET not set in .env{RESET}")

    print(f"\n{BOLD}{CYAN}-- SETUP: Generate Tokens & Seed Data -------------------------{RESET}")

    emp_token  = generate_token(EMPLOYER_ID)
    cand_token = generate_token(CANDIDATE_ID)

    # Verify token is accepted
    r = requests.get(f"{BASE}/employer/jobs",
                     headers={"Authorization": f"Bearer {emp_token}"})
    if r.status_code not in (200,):
        sys.exit(f"{RED}Token rejected by server [{r.status_code}]: {r.text[:200]}{RESET}")
    print(f"  PASS  Tokens generated and accepted by server")
    print(f"  INFO  employer_id : {EMPLOYER_ID}")
    print(f"  INFO  candidate_id: {CANDIDATE_ID}")

    # Create a fresh job for this test run (endpoint returns 200, not 201)
    job_resp = step("Create job (DRAFT)", "POST", "/employer/jobs", 200,
                    token=emp_token, json_body={
                        "title": "Senior Python Engineer",
                        "description": "Build scalable APIs. Python/FastAPI expert needed.",
                        "skills": ["Python", "FastAPI", "MongoDB"],
                        "experience_min": 3, "experience_max": 7,
                        "salary_min": 1200000, "salary_max": 2000000,
                        "currency": "INR", "location": "Bengaluru",
                        "job_type": "FULL_TIME", "work_mode": "HYBRID"
                    })

    job_id = job_resp.get("id", job_resp.get("job_id", ""))
    if not job_id:
        sys.exit(f"{RED}Cannot proceed -- job creation failed, no id in response{RESET}")
    print(f"  INFO  job_id: {job_id}")

    step("Publish job", "PATCH", f"/employer/jobs/{job_id}/publish", 200, token=emp_token)

    return emp_token, cand_token, job_id, CANDIDATE_ID


# ==============================================================================
# PHASE 1 -- Employer Verification & Compliance  [NEW 1-5]
# ==============================================================================

def phase1_compliance(emp_token: str):
    print(f"\n{BOLD}{CYAN}-- PHASE 1: Employer Verification & Policies -----------------{RESET}")

    step("[NEW 1] Submit PAN verification", "POST", "/employer/verification/pan", 201,
         token=emp_token, json_body={
             "document_url": "https://storage.hirepilot.test/pan_doc.pdf",
             "document_number": "ABCDE1234F",
             "notes": "Original PAN card scan"
         })

    step("[NEW 2] Submit GST verification", "POST", "/employer/verification/gst", 201,
         token=emp_token, json_body={
             "document_url": "https://storage.hirepilot.test/gst_cert.pdf",
             "document_number": "27AAPFU0939F1ZV"
         })

    step("[NEW 3] Submit company docs", "POST", "/employer/verification/company-docs", 201,
         token=emp_token, json_body={
             "document_url": "https://storage.hirepilot.test/moa.pdf",
             "notes": "Memorandum of Association"
         })

    status_resp = step("[NEW 4] Get verification status (3 items)", "GET",
                       "/employer/verification/status", 200, token=emp_token)
    if status_resp:
        print(f"  INFO  statuses: {[s.get('status') for s in status_resp]}")

    policies = step("[NEW 5] Get platform policies", "GET",
                    "/employer/policies", 200, token=emp_token)
    if policies:
        print(f"  INFO  {len(policies)} policies returned")


# ==============================================================================
# PHASE 2 -- Public Job Board  [NEW 6, 7, 8]
# ==============================================================================

def phase2_public_board(job_id: str, cand_token: str):
    print(f"\n{BOLD}{CYAN}-- PHASE 2: Public Job Board ---------------------------------{RESET}")

    board = step("[NEW 6] Browse public job board (no auth)", "GET", "/jobs", 200,
                 params={"keyword": "Python", "limit": 10})
    if board:
        print(f"  INFO  {len(board)} job(s) listed")

    step("[NEW 6b] Browse with filters (HYBRID, Bengaluru)", "GET", "/jobs", 200,
         params={"work_mode": "HYBRID", "location": "Bengaluru"})

    job_detail = step("[NEW 7] View job detail (auto JOB_VIEW event)", "GET",
                      f"/jobs/{job_id}", 200, params={"viewer_id": "anonymous"})
    if job_detail:
        print(f"  INFO  title: {job_detail.get('title')}")

    evt = step("[NEW 8] Record JOB_CLICK analytics event", "POST",
               "/analytics/events", 201, token=cand_token, json_body={
                   "event_type": "JOB_CLICK",
                   "job_id": job_id
               })
    if evt:
        print(f"  INFO  event_id: {evt.get('id')}")


# ==============================================================================
# PHASE 3 -- Candidate Applies
# ==============================================================================

def phase3_apply(cand_token: str, job_id: str) -> str:
    print(f"\n{BOLD}{CYAN}-- PHASE 3: Candidate Applies --------------------------------{RESET}")

    resp = step("Candidate applies for job", "POST", "/candidate/applications", 200,
                token=cand_token, json_body={"job_id": job_id})
    app_id = resp.get("id", "")

    if not app_id:
        apps = requests.get(f"{BASE}/candidate/applications",
                            headers={"Authorization": f"Bearer {cand_token}"}).json()
        app_id = next((a["id"] for a in apps if a.get("job_id") == job_id), "")
        print(f"  INFO  (fallback) application_id: {app_id}")
    else:
        print(f"  INFO  application_id: {app_id}")
    return app_id


# ==============================================================================
# PHASE 4 -- Employer Analytics  [NEW 9, 10, 11, 12]
# ==============================================================================

def phase4_analytics(emp_token: str):
    print(f"\n{BOLD}{CYAN}-- PHASE 4: Employer Analytics & Reports ---------------------{RESET}")

    dash = step("[NEW 9] Employer dashboard metrics", "GET",
                "/employer/dashboard", 200, token=emp_token)
    if dash:
        print(f"  INFO  applications={dash.get('total_applications')} "
              f"views={dash.get('total_views')} ctr={dash.get('ctr')}%")

    jobs_rpt = step("[NEW 10] Job-level report", "GET",
                    "/employer/reports/jobs", 200, token=emp_token)
    if jobs_rpt:
        print(f"  INFO  {len(jobs_rpt)} job(s) in report")

    funnel = step("[NEW 11] Candidate pipeline funnel", "GET",
                  "/employer/reports/candidates", 200, token=emp_token)
    if funnel:
        print(f"  INFO  funnel: {funnel}")

    int_rpt = step("[NEW 12] Interview statistics report", "GET",
                   "/employer/reports/interviews", 200, token=emp_token)
    if int_rpt:
        print(f"  INFO  total_interviews={int_rpt.get('total_interviews')} "
              f"pass_rate={int_rpt.get('pass_rate')}")


# ==============================================================================
# PHASE 5 -- Shortlist + Schedule Interview
# ==============================================================================

def phase5_shortlist_interview(emp_token: str, app_id: str,
                               candidate_user_id: str, job_id: str) -> str:
    print(f"\n{BOLD}{CYAN}-- PHASE 5: Shortlist + Schedule Interview -------------------{RESET}")

    step("Shortlist application", "POST",
         f"/employer/applications/{app_id}/shortlist", 200, token=emp_token)

    iv = step("Schedule interview", "POST", "/employer/interviews", 200,
              token=emp_token, json_body={
                  "candidate_id": candidate_user_id,
                  "job_id": job_id,
                  "scheduled_at": "2026-06-15T10:00:00Z",
                  "duration_minutes": 60,
                  "title": "Technical Round 1",
                  "description": "Python + System Design"
              })
    iv_id = iv.get("id", iv.get("interview_id", ""))

    if not iv_id:
        sys.exit(f"{RED}Cannot proceed -- interview creation failed, no id in response{RESET}")
    print(f"  INFO  interview_id: {iv_id}")
    return iv_id


# ==============================================================================
# PHASE 6 -- Candidate Confirms Interview  [NEW 13]
# ==============================================================================

def phase6_interview_response(cand_token: str, iv_id: str):
    print(f"\n{BOLD}{CYAN}-- PHASE 6: Candidate Responds to Interview [NEW 13] ---------{RESET}")

    resp = step("[NEW 13] Candidate confirms interview", "PATCH",
                f"/candidate/interviews/{iv_id}/respond", 200,
                token=cand_token, json_body={
                    "status": "CONFIRMED",
                    "notes": "Looking forward to it!"
                })
    if resp:
        print(f"  INFO  {resp.get('message')}")


# ==============================================================================
# PHASE 7 -- Interview Feedback
# ==============================================================================

def phase7_feedback(emp_token: str, iv_id: str):
    print(f"\n{BOLD}{CYAN}-- PHASE 7: Interview Feedback --------------------------------{RESET}")

    step("Submit interview feedback", "POST",
         f"/employer/interviews/{iv_id}/feedback", 200,
         token=emp_token, json_body={
             "rating": 4,
             "comments": "Strong Python skills, good system design knowledge.",
             "recommendation": "HIRE"
         })


# ==============================================================================
# PHASE 8 -- Employer Makes Formal Offer  [NEW 14]
# ==============================================================================

def phase8_make_offer(emp_token: str, app_id: str) -> str:
    print(f"\n{BOLD}{CYAN}-- PHASE 8: Employer Makes Formal Offer [NEW 14] -------------{RESET}")

    offer = step("[NEW 14] Make formal offer", "POST",
                 f"/employer/applications/{app_id}/offer", 201,
                 token=emp_token, json_body={
                     "salary_min": 1500000,
                     "salary_max": 1800000,
                     "currency": "INR",
                     "start_date": "2026-07-01",
                     "expiry_date": "2026-06-01",
                     "notes": "Remote-friendly role with stock options."
                 })
    offer_id = offer.get("id", "")
    print(f"  INFO  offer_id: {offer_id} | status: {offer.get('status')}")
    return offer_id


# ==============================================================================
# PHASE 9 -- Candidate Accepts Offer  [NEW 15]
# ==============================================================================

def phase9_accept_offer(cand_token: str, app_id: str):
    print(f"\n{BOLD}{CYAN}-- PHASE 9: Candidate Accepts Offer [NEW 15] -----------------{RESET}")

    resp = step("[NEW 15] Candidate accepts offer -> HIRED", "PATCH",
                f"/candidate/applications/{app_id}/offer/respond", 200,
                token=cand_token, json_body={
                    "status": "ACCEPTED",
                    "notes": "Excited to join TechCorp!"
                })
    if resp:
        print(f"  INFO  offer status: {resp.get('status')}")


# ==============================================================================
# PHASE 10 -- Final Dashboard
# ==============================================================================

def phase10_final_dashboard(emp_token: str):
    print(f"\n{BOLD}{CYAN}-- PHASE 10: Final Dashboard (expect funnel_hired=1) ---------{RESET}")

    dash = step("Final dashboard check", "GET",
                "/employer/dashboard", 200, token=emp_token)
    if dash:
        funnel = dash.get("hiring_funnel", {})
        print(f"  INFO  hired={funnel.get('hired', 0)} "
              f"offered={funnel.get('offered', 0)} "
              f"views={dash.get('total_views')} ctr={dash.get('ctr')}%")


# ==============================================================================
# PHASE 11 -- Report Candidate  [NEW 16]
# ==============================================================================

def phase11_moderation(emp_token: str, candidate_user_id: str):
    print(f"\n{BOLD}{CYAN}-- PHASE 11: Report Candidate [NEW 16] -----------------------{RESET}")

    resp = step("[NEW 16] Report candidate (moderation)", "POST",
                "/employer/report-candidate", 201,
                token=emp_token, json_body={
                    "reported_candidate_id": candidate_user_id,
                    "reason": "FRAUD",
                    "description": "Submitted forged documents during background check."
                })
    if resp:
        print(f"  INFO  report_id: {resp.get('id')} | status: {resp.get('status')}")


# ==============================================================================
# EDGE CASES
# ==============================================================================

def edge_cases(emp_token: str, cand_token: str,
               job_id: str, app_id: str, iv_id: str):
    print(f"\n{BOLD}{CYAN}-- EDGE CASES ------------------------------------------------{RESET}")

    # Duplicate PAN -> upsert (201, not 409)
    step("Re-submit PAN (upsert, not 409)", "POST", "/employer/verification/pan", 201,
         token=emp_token, json_body={
             "document_url": "https://storage.hirepilot.test/pan_v2.pdf",
             "document_number": "ABCDE1234F"
         })

    # Bad job ID on public board -> 404
    step("GET /jobs/bad_id -> 404", "GET", "/jobs/000000000000000000000000", 404)

    # Duplicate offer is allowed after prior offer is ACCEPTED (no PENDING offer exists)
    # so re-offering on the same app after acceptance returns 201, not 409
    step("Re-offer after acceptance (no PENDING -> 201)", "POST",
         f"/employer/applications/{app_id}/offer", 201,
         token=emp_token, json_body={
             "salary_min": 1000000, "salary_max": 1200000, "currency": "INR",
             "start_date": "2026-08-01", "expiry_date": "2026-07-01"
         })

    # Re-respond to accepted offer -> 409
    step("Re-respond to accepted offer -> 409", "PATCH",
         f"/candidate/applications/{app_id}/offer/respond", 409,
         token=cand_token, json_body={"status": "DECLINED"})

    # Candidate responds to wrong interview -> 404
    step("Respond to non-existent interview -> 404", "PATCH",
         "/candidate/interviews/000000000000000000000000/respond", 404,
         token=cand_token, json_body={"status": "CONFIRMED"})

    # Analytics event with unknown job_id (records anyway)
    step("Analytics event with unknown job_id -> 201", "POST",
         "/analytics/events", 201, token=cand_token, json_body={
             "event_type": "APPLY_START",
             "job_id": "000000000000000000000000"
         })

    # Skill filter with no matches -> 200 empty list
    result = step("GET /jobs no-match skill -> 200 []", "GET", "/jobs", 200,
                  params={"skills": "COBOL,RPG400"})
    if isinstance(result, list):
        print(f"  INFO  returned {len(result)} job(s) (expected 0)")


# ==============================================================================
# SUMMARY
# ==============================================================================

def print_summary():
    print(f"\n{BOLD}{'=' * 65}{RESET}")
    print(f"{BOLD}  SUMMARY{RESET}")
    print(f"{BOLD}{'=' * 65}{RESET}")

    passed = [r for r in results if r["pass"]]
    failed = [r for r in results if not r["pass"]]

    for r in results:
        mark = f"{GREEN}PASS{RESET}" if r["pass"] else f"{RED}FAIL{RESET}"
        print(f"  {mark}  {r['method']:<6} {r['path']:<55}  [{r['got']}]")

    print(f"\n  {GREEN}Passed: {len(passed)}{RESET}  |  "
          f"{RED}Failed: {len(failed)}{RESET}  |  "
          f"Total: {len(results)}")

    if failed:
        print(f"\n{RED}  Failed steps:{RESET}")
        for r in failed:
            print(f"    FAIL {r['label']} -- expected {r['expected']}, got {r['got']}")
        sys.exit(1)
    else:
        print(f"\n{GREEN}{BOLD}  All steps passed.{RESET}")


# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == "__main__":
    print(f"{BOLD}{CYAN}")
    print("=" * 65)
    print("  HirePilot -- End-to-End Flow Test (16 new endpoints)")
    print("=" * 65)
    print(RESET)

    emp_token, cand_token, job_id, candidate_user_id = setup()

    phase1_compliance(emp_token)
    phase2_public_board(job_id, cand_token)
    app_id = phase3_apply(cand_token, job_id)
    phase4_analytics(emp_token)

    iv_id = ""
    if app_id and candidate_user_id:
        iv_id = phase5_shortlist_interview(emp_token, app_id, candidate_user_id, job_id)
    else:
        print(f"\n{YELLOW}  SKIP phases 5-9: missing app_id or candidate_user_id{RESET}")

    if iv_id:
        phase6_interview_response(cand_token, iv_id)
        phase7_feedback(emp_token, iv_id)

    if app_id:
        phase8_make_offer(emp_token, app_id)
        phase9_accept_offer(cand_token, app_id)

    phase10_final_dashboard(emp_token)

    if candidate_user_id:
        phase11_moderation(emp_token, candidate_user_id)

    if app_id:
        edge_cases(emp_token, cand_token, job_id, app_id, iv_id)

    print_summary()
