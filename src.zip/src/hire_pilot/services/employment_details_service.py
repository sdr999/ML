import time
from typing import List

from bson.errors import InvalidId
from fastapi import HTTPException, status
from hire_pilot.models.employment_detail import EmploymentDetail
from hire_pilot.models.employment_detail_input import EmploymentDetailInput
from hire_pilot.repositories.employment_details_repository import EmploymentDetailsRepository
from hire_pilot.utils.logger import log


class EmploymentDetailsService:
    def __init__(self):
        self.repo = EmploymentDetailsRepository()
        log.info("EmploymentDetailsService initialized")

    # ── List all ─────────────────────────────────────────────────────

    async def get_all(self, user_id: str, page: int, limit: int) -> List[EmploymentDetail]:
        start = time.monotonic()
        skip = (page - 1) * limit
        log.info("Fetching all employment details | user_id=%s, page=%d, limit=%d", user_id, page, limit)

        try:
            docs = await self.repo.find_all_by_user(user_id, skip=skip, limit=limit)
            details = [EmploymentDetail(**doc) for doc in docs]
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Fetched employment details | user_id=%s, count=%d, duration_ms=%s",
                user_id, len(details), elapsed,
            )
            return details

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch employment details | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve employment details.",
            )

    # ── Get one ──────────────────────────────────────────────────────

    async def get_by_id(self, detail_id: str, user_id: str) -> EmploymentDetail:
        start = time.monotonic()
        log.info("Fetching employment detail | id=%s, user_id=%s", detail_id, user_id)

        self._validate_object_id(detail_id)

        try:
            doc = await self.repo.find_one_by_id(detail_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid employment detail ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch employment detail | id=%s, error_type=%s, duration_ms=%s",
                detail_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve employment detail.",
            )

        if doc is None:
            log.warning("Employment detail not found | id=%s, user_id=%s", detail_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Employment detail not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Fetched employment detail | id=%s, duration_ms=%s", detail_id, elapsed)
        return EmploymentDetail(**doc)

    # ── Create ───────────────────────────────────────────────────────

    async def create(self, user_id: str, input_data: EmploymentDetailInput) -> EmploymentDetail:
        start = time.monotonic()
        log.info("Creating employment detail | user_id=%s", user_id)

        self._validate_input(input_data)

        try:
            data = input_data.to_dict()
            if "last_working_day" in data and hasattr(data["last_working_day"], "isoformat"):
                data["last_working_day"] = data["last_working_day"].isoformat()
                
            inserted_id = await self.repo.insert_one(user_id, data)
            data["id"] = inserted_id

            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Employment detail created | id=%s, user_id=%s, duration_ms=%s",
                inserted_id, user_id, elapsed,
            )
            return EmploymentDetail(**data)

        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to create employment detail | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create employment detail.",
            )

    # ── Update ───────────────────────────────────────────────────────

    async def update(
        self, detail_id: str, user_id: str, input_data: EmploymentDetailInput
    ) -> None:
        start = time.monotonic()
        log.info("Updating employment detail | id=%s, user_id=%s", detail_id, user_id)

        self._validate_object_id(detail_id)
        self._validate_input(input_data)

        try:
            data = input_data.to_dict()
            if "last_working_day" in data and hasattr(data["last_working_day"], "isoformat"):
                data["last_working_day"] = data["last_working_day"].isoformat()
                
            modified = await self.repo.update_one(detail_id, user_id, data)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid employment detail ID format.",
            )
        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update employment detail | id=%s, error_type=%s, duration_ms=%s",
                detail_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update employment detail.",
            )

        if modified == 0:
            log.warning("Employment detail not found for update | id=%s, user_id=%s", detail_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Employment detail not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Employment detail updated | id=%s, duration_ms=%s", detail_id, elapsed)

    # ── Delete ───────────────────────────────────────────────────────

    async def delete(self, detail_id: str, user_id: str) -> None:
        start = time.monotonic()
        log.info("Deleting employment detail | id=%s, user_id=%s", detail_id, user_id)

        self._validate_object_id(detail_id)

        try:
            deleted = await self.repo.delete_one(detail_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid employment detail ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to delete employment detail | id=%s, error_type=%s, duration_ms=%s",
                detail_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete employment detail.",
            )

        if deleted == 0:
            log.warning("Employment detail not found for deletion | id=%s, user_id=%s", detail_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Employment detail not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Employment detail deleted | id=%s, duration_ms=%s", detail_id, elapsed)

    # ── Validation helpers ───────────────────────────────────────────

    @staticmethod
    def _validate_input(inp: EmploymentDetailInput) -> None:
        # All fields are optional in EmploymentDetailInput
        # We could add cross-field validation here if necessary
        pass

    @staticmethod
    def _validate_object_id(oid: str) -> None:
        if not oid or len(oid) != 24:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid employment detail ID format.",
            )
        try:
            int(oid, 16)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid employment detail ID format.",
            )
