from datetime import datetime, timezone
from typing import Any, Dict
from fastapi import HTTPException, status
from hire_pilot.models.offer import Offer, OfferInput, OfferResponseInput, OfferStatus
from hire_pilot.repositories.application_repository import ApplicationRepository
from hire_pilot.repositories.offer_repository import OfferRepository
from hire_pilot.utils.logger import log


class OfferService:
    def __init__(self):
        self.offer_repo = OfferRepository()
        self.app_repo = ApplicationRepository()

    async def make_offer(
        self, employer_id: str, application_id: str, offer_input: OfferInput
    ) -> Offer:
        app = await self.app_repo.find_by_id(application_id)
        if not app:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Application not found.")

        # Verify this employer owns the job the application belongs to
        job_id = app.get("job_id", "")
        candidate_id = app.get("candidate_id", "")

        # Block duplicate active offers
        existing = await self.offer_repo.find_by_application(application_id)
        if existing and existing.get("status") == "PENDING":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="An active offer already exists for this application.",
            )

        data: Dict[str, Any] = {
            "application_id": application_id,
            "employer_id": employer_id,
            "candidate_id": candidate_id,
            "job_id": job_id,
            **{k: str(v) if hasattr(v, "isoformat") else v
               for k, v in offer_input.model_dump(exclude_none=True).items()},
        }
        offer_id = await self.offer_repo.insert_offer(data)

        # Update application status to OFFERED and record in status_history
        await self.app_repo.update_status(application_id, "OFFERED")

        # Notify candidate (non-fatal)
        try:
            from hire_pilot.repositories.messaging_notifications_repository import (
                MessagingNotificationsRepository,
            )
            await MessagingNotificationsRepository().create_notification(
                user_id=candidate_id,
                title="You have a job offer!",
                message="An employer has extended a formal offer for your application. Check the offers section.",
                notify_type="offer",
            )
        except Exception as exc:
            log.warning("Could not send offer notification | error=%s", str(exc))

        return Offer(
            id=offer_id,
            application_id=application_id,
            employer_id=employer_id,
            candidate_id=candidate_id,
            status=OfferStatus.PENDING,
            created_at=datetime.now(timezone.utc),
            **offer_input.model_dump(exclude_none=True),
        )

    async def respond_to_offer(
        self, candidate_id: str, application_id: str, response: OfferResponseInput
    ) -> Offer:
        if response.status not in (OfferStatus.ACCEPTED, OfferStatus.DECLINED):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Response must be ACCEPTED or DECLINED.",
            )

        offer = await self.offer_repo.find_by_application(application_id)
        if not offer:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No offer found for this application.")
        if offer.get("candidate_id") != candidate_id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="This offer does not belong to you.")
        if offer.get("status") != "PENDING":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Offer is already {offer.get('status')}.",
            )

        updated = await self.offer_repo.update_offer_response(
            offer["id"], candidate_id, response.status.value, response.notes
        )
        if not updated:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update offer.",
            )

        # Mirror the decision into the application status
        new_app_status = "HIRED" if response.status == OfferStatus.ACCEPTED else "REJECTED"
        await self.app_repo.update_status(application_id, new_app_status)

        now = datetime.now(timezone.utc)
        return Offer(
            id=offer["id"],
            application_id=application_id,
            employer_id=offer.get("employer_id", ""),
            candidate_id=candidate_id,
            salary_min=offer.get("salary_min"),
            salary_max=offer.get("salary_max"),
            currency=offer.get("currency", "INR"),
            status=response.status,
            notes=offer.get("notes"),
            candidate_notes=response.notes,
            responded_at=now,
        )
