from typing import Any, List, Optional, Dict
from fastapi import HTTPException, status
from hire_pilot.repositories.candidate_search_repository import CandidateSearchRepository
from hire_pilot.services.profile_details_service import ProfileDetailsService
from hire_pilot.utils.logger import log

class CandidateSearchService:
    def __init__(self):
        self.repo = CandidateSearchRepository()
        self.profile_svc = ProfileDetailsService()
        log.info("CandidateSearchService initialized")

    async def search_candidates(
        self, 
        skills: Optional[str] = None, 
        experience: Optional[int] = None, 
        location: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        try:
            return await self.repo.search_candidates(skills, experience, location)
        except Exception as exc:
            log.exception("Search failed | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Candidate search failed."
            )

    async def get_candidate_profile(self, candidate_id: str) -> Any:
        try:
            # First check if candidate exists and is an employee
            candidate = await self.repo.find_candidate_by_id(candidate_id)
            if not candidate:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Candidate not found."
                )
            
            # Use ProfileDetailsService to get full profile
            return await self.profile_svc.get_full_profile(candidate_id)
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to fetch candidate profile | candidate_id=%s, error=%s", candidate_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error while fetching candidate profile."
            )

    async def save_search_filters(self, user_id: str, filters: dict) -> dict:
        try:
            search_id = await self.repo.save_search(user_id, filters)
            return {"id": search_id, "message": "Search filters saved successfully"}
        except Exception as exc:
            log.exception("Failed to save search | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to save search filters."
            )

    async def get_saved_searches(self, user_id: str) -> List[dict]:
        try:
            return await self.repo.get_saved_searches(user_id)
        except Exception as exc:
            log.exception("Failed to fetch saved searches | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to fetch saved searches."
            )

    async def delete_saved_search(self, user_id: str, search_id: str) -> None:
        try:
            count = await self.repo.delete_saved_search(user_id, search_id)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Saved search not found."
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to delete saved search | id=%s, error=%s", search_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete saved search."
            )

    async def get_talent_pools(self, employer_id: str) -> List[Dict[str, Any]]:
        try:
            return await self.repo.get_talent_pools(employer_id)
        except Exception as exc:
            log.exception("Failed to fetch talent pools | employer_id=%s, error=%s", employer_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to fetch talent pools."
            )

    async def create_talent_pool(self, employer_id: str, name: str, description: Optional[str] = None) -> Dict[str, Any]:
        try:
            pool_id = await self.repo.create_talent_pool(employer_id, name, description)
            return {"id": pool_id, "name": name, "description": description, "message": "Talent pool created successfully"}
        except Exception as exc:
            log.exception("Failed to create talent pool | employer_id=%s, error=%s", employer_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create talent pool."
            )

    async def add_candidate_to_pool(self, employer_id: str, pool_id: str, candidate_id: str) -> Dict[str, Any]:
        try:
            success = await self.repo.add_candidate_to_pool(employer_id, pool_id, candidate_id)
            if not success:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Talent pool not found or unauthorized."
                )
            return {"message": "Candidate added to pool successfully"}
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to add candidate to pool | pool_id=%s, candidate_id=%s, error=%s", pool_id, candidate_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to add candidate to pool."
            )

