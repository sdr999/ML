import time
from typing import List

from bson.errors import InvalidId
from fastapi import HTTPException, status
from hire_pilot.models.work_experience import WorkExperience
from hire_pilot.models.work_experience_input import WorkExperienceInput
from hire_pilot.repositories.work_experience_repository import WorkExperienceRepository
from hire_pilot.utils.logger import log


class WorkExperienceService:
    def __init__(self):
        self.repo = WorkExperienceRepository()
        log.info("WorkExperienceService initialized")

    # ── List all ─────────────────────────────────────────────────────

    async def get_all(self, user_id: str, page: int = 1, limit: int = 20) -> List[WorkExperience]:
        start = time.monotonic()
        skip = (page - 1) * limit
        log.info("Fetching all work experiences | user_id=%s, page=%d, limit=%d", user_id, page, limit)

        try:
            docs = await self.repo.find_all_by_user(user_id, skip=skip, limit=limit)
            experiences = [WorkExperience(**doc) for doc in docs]
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Fetched work experiences | user_id=%s, count=%d, duration_ms=%s",
                user_id, len(experiences), elapsed,
            )
            return experiences

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch work experiences | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve work experiences.",
            )

    # ── Get one ──────────────────────────────────────────────────────

    async def get_by_id(self, exp_id: str, user_id: str) -> WorkExperience:
        start = time.monotonic()
        log.info("Fetching work experience | id=%s, user_id=%s", exp_id, user_id)

        self._validate_object_id(exp_id)

        try:
            doc = await self.repo.find_one_by_id(exp_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid work experience ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch work experience | id=%s, error_type=%s, duration_ms=%s",
                exp_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve work experience.",
            )

        if doc is None:
            log.warning("Work experience not found | id=%s, user_id=%s", exp_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Work experience not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Fetched work experience | id=%s, duration_ms=%s", exp_id, elapsed)
        return WorkExperience(**doc)

    # ── Create ───────────────────────────────────────────────────────

    async def create(self, user_id: str, exp_input: WorkExperienceInput) -> WorkExperience:
        start = time.monotonic()
        log.info("Creating work experience | user_id=%s", user_id)

        self._validate_input(exp_input)

        try:
            data = exp_input.to_dict()
            inserted_id = await self.repo.insert_one(user_id, data)
            
            # Fetch it back to return the complete object
            new_doc = await self.repo.find_one_by_id(inserted_id, user_id)
            if not new_doc:
                raise Exception("Failed to retrieve created document.")

            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Work experience created | id=%s, user_id=%s, duration_ms=%s",
                inserted_id, user_id, elapsed,
            )
            return WorkExperience(**new_doc)

        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to create work experience | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create work experience.",
            )

    # ── Update ───────────────────────────────────────────────────────

    async def update(
        self, exp_id: str, user_id: str, exp_input: WorkExperienceInput
    ) -> None:
        start = time.monotonic()
        log.info("Updating work experience | id=%s, user_id=%s", exp_id, user_id)

        self._validate_object_id(exp_id)
        self._validate_input(exp_input)

        try:
            data = exp_input.to_dict()
            modified = await self.repo.update_one(exp_id, user_id, data)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid work experience ID format.",
            )
        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update work experience | id=%s, error_type=%s, duration_ms=%s",
                exp_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update work experience.",
            )

        if modified == 0:
            log.warning("Work experience not found for update | id=%s, user_id=%s", exp_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Work experience not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Work experience updated | id=%s, duration_ms=%s", exp_id, elapsed)

    # ── Delete ───────────────────────────────────────────────────────

    async def delete(self, exp_id: str, user_id: str) -> None:
        start = time.monotonic()
        log.info("Deleting work experience | id=%s, user_id=%s", exp_id, user_id)

        self._validate_object_id(exp_id)

        try:
            deleted = await self.repo.delete_one(exp_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid work experience ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to delete work experience | id=%s, error_type=%s, duration_ms=%s",
                exp_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete work experience.",
            )

        if deleted == 0:
            log.warning("Work experience not found for deletion | id=%s, user_id=%s", exp_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Work experience not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Work experience deleted | id=%s, duration_ms=%s", exp_id, elapsed)

    # ── Validation helpers ───────────────────────────────────────────

    @staticmethod
    def _validate_input(inp: WorkExperienceInput) -> None:
        errors: list[str] = []

        if not inp.company_name or not inp.company_name.strip():
            errors.append("Company name is required.")
        if not inp.start_date or not inp.start_date.strip():
            errors.append("Start date is required.")
        if not inp.location or not inp.location.strip():
            errors.append("Location is required.")
        if not inp.role or not inp.role.strip():
            errors.append("Role is required.")

        if errors:
            log.warning("Work experience validation failed | errors=%s", errors)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=errors[0] if len(errors) == 1 else errors,
            )

    @staticmethod
    def _validate_object_id(oid: str) -> None:
        if not oid or len(oid) != 24:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid work experience ID format.",
            )
        try:
            int(oid, 16)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid work experience ID format.",
            )
