import base64
import io
import time
import logging
from typing import Optional, Dict, Any

from fastapi import HTTPException, status
from hire_pilot.repositories.resume_repository import ResumeRepository
from hire_pilot.services.profile_details_service import ProfileDetailsService
from hire_pilot.utils.logger import log

try:
    from fpdf import FPDF
except ImportError:
    FPDF = None

logger = logging.getLogger(__name__)


class ResumeService:
    def __init__(self):
        self.repo = ResumeRepository()
        self.profile_details_service = ProfileDetailsService()
        log.info("ResumeService initialized")

    # ── Save uploaded resume ─────────────────────────────────────────

    async def save_uploaded_resume(
        self, user_id: str, file_bytes_b64: str, filename: str, content_type: str
    ) -> None:
        """Persist the original uploaded resume file."""
        start = time.monotonic()
        log.info("Saving uploaded resume | user_id=%s, filename=%s", user_id, filename)

        try:
            await self.repo.upsert_one(
                user_id=user_id,
                file_bytes_b64=file_bytes_b64,
                filename=filename,
                content_type=content_type,
                source="uploaded",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to save uploaded resume | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to save resume.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Uploaded resume saved | user_id=%s, duration_ms=%s", user_id, elapsed)

    # ── Generate resume from profile data ────────────────────────────

    async def generate_resume_from_profile(self, user_id: str) -> None:
        """Build a PDF resume from the user's profile data and save it."""
        start = time.monotonic()
        log.info("Generating resume from profile | user_id=%s", user_id)

        if not FPDF:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="PDF generation library (fpdf2) is not installed.",
            )

        profile = await self.profile_details_service.get_full_profile(user_id)

        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()

        # ── Header / Name ────────────────────────────────────────────
        pdf.set_font("Helvetica", "B", 20)
        pdf.cell(0, 12, "Resume", new_x="LMARGIN", new_y="NEXT", align="C")
        pdf.ln(4)

        # ── Summary ──────────────────────────────────────────────────
        if profile.summary:
            self._section_title(pdf, "Professional Summary")
            pdf.set_font("Helvetica", "", 10)
            pdf.multi_cell(0, 5, self._clean_text(profile.summary))
            pdf.ln(3)

        # ── Skills ───────────────────────────────────────────────────
        if profile.skills:
            self._section_title(pdf, "Skills")
            pdf.set_font("Helvetica", "", 10)
            pdf.multi_cell(0, 5, self._clean_text(", ".join(profile.skills)))
            pdf.ln(3)

        # ── Work Experience ──────────────────────────────────────────
        if profile.work_experience:
            self._section_title(pdf, "Work Experience")
            for exp in profile.work_experience:
                pdf.set_font("Helvetica", "B", 11)
                role = getattr(exp, "role", "")
                company = getattr(exp, "company_name", "")
                pdf.cell(0, 6, self._clean_text(f"{role} at {company}"), new_x="LMARGIN", new_y="NEXT")
                pdf.set_font("Helvetica", "I", 9)
                start_d = getattr(exp, "start_date", "")
                end_d = getattr(exp, "end_date", "Present") or "Present"
                location = getattr(exp, "location", "")
                pdf.cell(0, 5, self._clean_text(f"{start_d} - {end_d} | {location}"), new_x="LMARGIN", new_y="NEXT")
                desc = getattr(exp, "description", "")
                if desc:
                    pdf.set_font("Helvetica", "", 10)
                    pdf.multi_cell(0, 5, self._clean_text(desc))
                pdf.ln(2)

        # ── Education ────────────────────────────────────────────────
        if profile.education:
            self._section_title(pdf, "Education")
            for edu in profile.education:
                pdf.set_font("Helvetica", "B", 11)
                degree = getattr(edu, "degree_name", "")
                level = getattr(edu, "degree_level", "")
                org = getattr(edu, "org_name", "")
                pdf.cell(0, 6, self._clean_text(f"{degree} ({level}) - {org}"), new_x="LMARGIN", new_y="NEXT")
                pdf.set_font("Helvetica", "I", 9)
                start_d = getattr(edu, "start_date", "")
                end_d = getattr(edu, "end_date", "Present") or "Present"
                pdf.cell(0, 5, self._clean_text(f"{start_d} - {end_d}"), new_x="LMARGIN", new_y="NEXT")
                pdf.ln(2)

        # ── Certifications ───────────────────────────────────────────
        if profile.certifications:
            self._section_title(pdf, "Certifications")
            for cert in profile.certifications:
                pdf.set_font("Helvetica", "B", 10)
                name = getattr(cert, "name", "")
                org = getattr(cert, "org", "")
                pdf.cell(0, 6, self._clean_text(f"{name} - {org}"), new_x="LMARGIN", new_y="NEXT")
                desc = getattr(cert, "description", "")
                if desc:
                    pdf.set_font("Helvetica", "", 9)
                    pdf.multi_cell(0, 5, self._clean_text(desc))
                pdf.ln(2)

        # ── Achievements ─────────────────────────────────────────────
        if profile.achievements:
            self._section_title(pdf, "Achievements")
            for ach in profile.achievements:
                pdf.set_font("Helvetica", "B", 10)
                name = getattr(ach, "name", "")
                org = getattr(ach, "org", "")
                pdf.cell(0, 6, self._clean_text(f"{name} ({org})"), new_x="LMARGIN", new_y="NEXT")
                desc = getattr(ach, "description", "")
                if desc:
                    pdf.set_font("Helvetica", "", 9)
                    pdf.multi_cell(0, 5, self._clean_text(desc))
                pdf.ln(2)

        # ── Personal Projects ────────────────────────────────────────
        if profile.personal_projects:
            self._section_title(pdf, "Personal Projects")
            for proj in profile.personal_projects:
                pdf.set_font("Helvetica", "B", 10)
                name = getattr(proj, "name", "")
                pdf.cell(0, 6, self._clean_text(name), new_x="LMARGIN", new_y="NEXT")
                desc = getattr(proj, "description", "")
                if desc:
                    pdf.set_font("Helvetica", "", 9)
                    pdf.multi_cell(0, 5, self._clean_text(desc))
                tech = getattr(proj, "tech_stack", None)
                if tech:
                    pdf.set_font("Helvetica", "I", 9)
                    pdf.cell(0, 5, self._clean_text(f"Tech: {', '.join(tech)}"), new_x="LMARGIN", new_y="NEXT")
                pdf.ln(2)

        # ── Languages ────────────────────────────────────────────────
        if profile.languages:
            self._section_title(pdf, "Languages")
            for lang in profile.languages:
                pdf.set_font("Helvetica", "", 10)
                name = getattr(lang, "name", "")
                speaking = getattr(lang, "speaking_prof", "") or ""
                pdf.cell(0, 5, self._clean_text(f"{name} ({speaking})"), new_x="LMARGIN", new_y="NEXT")
            pdf.ln(2)

        # ── Output PDF bytes ─────────────────────────────────────────
        pdf_bytes = pdf.output()
        pdf_b64 = base64.b64encode(pdf_bytes).decode("utf-8")

        try:
            await self.repo.upsert_one(
                user_id=user_id,
                file_bytes_b64=pdf_b64,
                filename="resume.pdf",
                content_type="application/pdf",
                source="generated",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to save generated resume | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to save generated resume.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Generated resume saved | user_id=%s, duration_ms=%s", user_id, elapsed)

    # ── Retrieve resume for download ─────────────────────────────────

    async def get_resume(self, user_id: str) -> Dict[str, Any]:
        """Retrieve the stored resume. Returns dict with file_data, filename, content_type."""
        start = time.monotonic()
        log.info("Fetching resume | user_id=%s", user_id)

        try:
            doc = await self.repo.find_one_by_user(user_id)
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch resume | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve resume.",
            )

        if doc is None:
            log.warning("No resume found | user_id=%s", user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No resume found. Upload a resume or generate one from your profile.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Resume fetched | user_id=%s, source=%s, duration_ms=%s", user_id, doc.get("source"), elapsed)
        return doc

    # ── Helpers ───────────────────────────────────────────────────────

    @staticmethod
    def _section_title(pdf, title: str):
        """Render a styled section heading."""
        pdf.set_font("Helvetica", "B", 13)
        pdf.set_text_color(30, 80, 160)
        pdf.cell(0, 8, ResumeService._clean_text(title), new_x="LMARGIN", new_y="NEXT")
        pdf.set_draw_color(30, 80, 160)
        pdf.line(pdf.get_x(), pdf.get_y(), pdf.get_x() + 190, pdf.get_y())
        pdf.ln(3)
        pdf.set_text_color(0, 0, 0)

    @staticmethod
    def _clean_text(text: Optional[str]) -> str:
        """Replace common unicode characters and encode to latin-1 for FPDF."""
        if not text:
            return ""
        replacements = {
            "’": "'", "‘": "'",
            "“": '"', "”": '"',
            "–": "-", "—": "-",
            "…": "...",
            "\u2022": "-",
            "\u2013": "-",
            "\u2014": "-",
            "\u2018": "'",
            "\u2019": "'",
            "\u201c": '"',
            "\u201d": '"',
        }
        for k, v in replacements.items():
            text = text.replace(k, v)
        return text.encode("latin-1", "replace").decode("latin-1")
