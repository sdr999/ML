from typing import Any, Dict, List, Optional
from fastapi import HTTPException, status
from hire_pilot.repositories.job_repository import JobRepository
from hire_pilot.repositories.analytics_repository import AnalyticsRepository
from hire_pilot.utils.logger import log


class PublicJobsService:
    def __init__(self):
        self.job_repo = JobRepository()
        self.analytics_repo = AnalyticsRepository()

    async def list_published_jobs(
        self,
        keyword: Optional[str],
        skills: Optional[str],
        location: Optional[str],
        job_type: Optional[str],
        work_mode: Optional[str],
        page: int,
        limit: int,
    ) -> List[Dict[str, Any]]:
        try:
            query: Dict[str, Any] = {"status": "PUBLISHED"}
            if keyword:
                query["$or"] = [
                    {"title": {"$regex": keyword, "$options": "i"}},
                    {"description": {"$regex": keyword, "$options": "i"}},
                ]
            if skills:
                skill_list = [s.strip() for s in skills.split(",") if s.strip()]
                query["skills"] = {"$in": skill_list}
            if location:
                query["location"] = {"$regex": location, "$options": "i"}
            if job_type:
                query["job_type"] = job_type.upper()
            if work_mode:
                query["work_mode"] = work_mode.upper()

            skip = (page - 1) * limit
            docs = await self.job_repo.adapter.find_many(
                "jobs", query, limit=limit, skip=skip, sort=[("created_at", -1)]
            )
            for doc in docs:
                doc["id"] = str(doc["_id"])
                del doc["_id"]
            return docs
        except Exception as exc:
            log.exception("Failed to list published jobs | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve jobs.",
            )

    async def get_published_job(self, job_id: str, viewer_id: Optional[str] = None) -> Dict[str, Any]:
        job = await self.job_repo.find_by_id(job_id)
        if not job:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
        if job.get("status") != "PUBLISHED":
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")

        # Fire JOB_VIEW analytics event (non-blocking, failure does not affect response)
        try:
            await self.analytics_repo.insert_event(
                event_type="JOB_VIEW",
                job_id=job_id,
                employer_id=job.get("employer_id"),
                metadata={"viewer_id": viewer_id},
            )
        except Exception as exc:
            log.warning("Failed to record JOB_VIEW event | job_id=%s, error=%s", job_id, str(exc))

        return job
