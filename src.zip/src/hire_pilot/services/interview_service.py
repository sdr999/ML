from typing import Any, List, Optional, Dict
from fastapi import HTTPException, status

from hire_pilot.repositories.interview_repository import InterviewRepository
from hire_pilot.utils.logger import log

class InterviewService:
    def __init__(self):
        self.repo = InterviewRepository()

    async def list_interviews(self, employer_id: str) -> List[Dict[str, Any]]:
        try:
            return await self.repo.find_by_employer(employer_id)
        except Exception as exc:
            log.exception("Failed to fetch interviews | employer_id=%s, error=%s", employer_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve scheduled interviews."
            )

    async def list_candidate_interviews(self, candidate_id: str) -> List[Dict[str, Any]]:
        try:
            return await self.repo.find_by_candidate(candidate_id)
        except Exception as exc:
            log.exception("Failed to fetch candidate interviews | candidate_id=%s, error=%s", candidate_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve candidate interviews."
            )

    async def schedule_interview(
        self,
        employer_id: str,
        candidate_id: str,
        job_id: str,
        scheduled_at: str,
        duration_minutes: int,
        title: str,
        description: Optional[str] = None
    ) -> Dict[str, Any]:
        try:
            data = {
                "candidate_id": candidate_id,
                "job_id": job_id,
                "scheduled_at": scheduled_at,
                "duration_minutes": duration_minutes,
                "title": title,
                "description": description or "",
                "status": "SCHEDULED"
            }
            inserted_id = await self.repo.insert_interview(employer_id, data)
            
            # Auto-trigger a system notification for the interview
            try:
                from hire_pilot.repositories.messaging_notifications_repository import MessagingNotificationsRepository
                msg_repo = MessagingNotificationsRepository()
                await msg_repo.create_notification(
                    user_id=employer_id,
                    title="Interview Scheduled Successfully",
                    message=f"Your interview for '{title}' is scheduled for {scheduled_at}.",
                    notify_type="interview"
                )
            except Exception as e:
                log.warning("Could not auto-create notification for interview schedule: %s", str(e))
                
            return {
                "id": inserted_id,
                "message": "Interview scheduled successfully.",
                "zoom_link": "https://zoom.us/j/hirepilot-simulated-meeting"
            }
        except Exception as exc:
            log.exception("Failed to schedule interview | employer_id=%s, error=%s", employer_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to schedule interview."
            )

    async def reschedule_interview(
        self,
        employer_id: str,
        interview_id: str,
        scheduled_at: str,
        duration_minutes: Optional[int] = None,
        title: Optional[str] = None,
        description: Optional[str] = None
    ) -> Dict[str, Any]:
        try:
            update_data = {"scheduled_at": scheduled_at}
            if duration_minutes is not None:
                update_data["duration_minutes"] = duration_minutes
            if title is not None:
                update_data["title"] = title
            if description is not None:
                update_data["description"] = description
            
            success = await self.repo.update_interview(employer_id, interview_id, update_data)
            if not success:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Interview record not found or unauthorized."
                )
            return {"message": "Interview rescheduled successfully."}
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to reschedule interview | id=%s, error=%s", interview_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to reschedule interview."
            )

    async def cancel_interview(self, employer_id: str, interview_id: str) -> None:
        try:
            success = await self.repo.delete_interview(employer_id, interview_id)
            if not success:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Interview record not found or unauthorized."
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to cancel interview | id=%s, error=%s", interview_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to cancel interview."
            )

    async def get_slots(self, employer_id: str) -> List[str]:
        try:
            return await self.repo.get_slots(employer_id)
        except Exception as exc:
            log.exception("Failed to fetch slots | employer_id=%s, error=%s", employer_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve slots."
            )

    async def add_slots(self, employer_id: str, slots: List[str]) -> Dict[str, Any]:
        try:
            await self.repo.save_slots(employer_id, slots)
            return {"message": "Availability slots updated successfully."}
        except Exception as exc:
            log.exception("Failed to save slots | employer_id=%s, error=%s", employer_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to save availability slots."
            )

    async def get_feedback(self, interview_id: str) -> Dict[str, Any]:
        try:
            res = await self.repo.get_feedback(interview_id)
            if not res:
                return {}
            return res
        except Exception as exc:
            log.exception("Failed to fetch feedback | interview_id=%s, error=%s", interview_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve interview feedback."
            )

    async def submit_feedback(
        self,
        interview_id: str,
        rating: int,
        comments: str,
        recommendation: str
    ) -> Dict[str, Any]:
        try:
            data = {
                "rating": rating,
                "comments": comments,
                "recommendation": recommendation
            }
            inserted_id = await self.repo.insert_feedback(interview_id, data)
            
            # Update interview status to feedback submitted
            # Try to get employer ID or bypass check since we just update interview document
            # (In standard flow, we can just mark it completed/feedback submitted)
            try:
                from bson import ObjectId
                await self.repo.adapter.update_one(
                    "interviews",
                    {"_id": ObjectId(interview_id)},
                    {"status": "FEEDBACK_SUBMITTED"}
                )
            except:
                pass
                
            return {"id": inserted_id, "message": "Interview feedback submitted successfully."}
        except Exception as exc:
            log.exception("Failed to save feedback | interview_id=%s, error=%s", interview_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to submit feedback."
            )
