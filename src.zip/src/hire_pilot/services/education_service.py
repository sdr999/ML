import time
from typing import List

from bson.errors import InvalidId
from fastapi import HTTPException, status
from hire_pilot.models.education import Education
from hire_pilot.models.education_input import EducationInput
from hire_pilot.repositories.education_repository import EducationRepository
from hire_pilot.utils.logger import log


class EducationService:
    def __init__(self):
        self.repo = EducationRepository()
        log.info("EducationService initialized")

    # ── List all ─────────────────────────────────────────────────────

    async def get_all(self, user_id: str) -> List[Education]:
        start = time.monotonic()
        log.info("Fetching all education | user_id=%s", user_id)

        try:
            docs = await self.repo.find_all_by_user(user_id)
            education_list = [Education(**doc) for doc in docs]
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Fetched education | user_id=%s, count=%d, duration_ms=%s",
                user_id, len(education_list), elapsed,
            )
            return education_list

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch education | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve education records.",
            )

    # ── Get one ──────────────────────────────────────────────────────

    async def get_by_id(self, education_id: str, user_id: str) -> Education:
        start = time.monotonic()
        log.info("Fetching education | id=%s, user_id=%s", education_id, user_id)

        self._validate_object_id(education_id)

        try:
            doc = await self.repo.find_one_by_id(education_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid education ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch education | id=%s, error_type=%s, duration_ms=%s",
                education_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve education record.",
            )

        if doc is None:
            log.warning("Education not found | id=%s, user_id=%s", education_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Education not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Fetched education | id=%s, duration_ms=%s", education_id, elapsed)
        return Education(**doc)

    # ── Create ───────────────────────────────────────────────────────

    async def create(self, user_id: str, education_input: EducationInput) -> str:
        start = time.monotonic()
        log.info("Creating education | user_id=%s", user_id)

        self._validate_input(education_input)

        try:
            # Check for limit of 3 exceeded
            existing = await self.repo.find_all_by_user(user_id)
            if len(existing) >= 3:
                log.warning("Education limit exceeded | user_id=%s", user_id)
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Maximum limit of 3 education records exceeded.",
                )

            data = education_input.to_dict()
            inserted_id = await self.repo.insert_one(user_id, data)

            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Education created | id=%s, user_id=%s, duration_ms=%s",
                inserted_id, user_id, elapsed,
            )
            return inserted_id

        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to create education | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create education record.",
            )

    # ── Update ───────────────────────────────────────────────────────

    async def update(
        self, education_id: str, user_id: str, education_input: EducationInput
    ) -> None:
        start = time.monotonic()
        log.info("Updating education | id=%s, user_id=%s", education_id, user_id)

        self._validate_object_id(education_id)
        self._validate_input(education_input)

        try:
            data = education_input.to_dict()
            modified = await self.repo.update_one(education_id, user_id, data)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid education ID format.",
            )
        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update education | id=%s, error_type=%s, duration_ms=%s",
                education_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update education record.",
            )

        if modified == 0:
            log.warning("Education not found for update | id=%s, user_id=%s", education_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Education not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Education updated | id=%s, duration_ms=%s", education_id, elapsed)

    # ── Delete ───────────────────────────────────────────────────────

    async def delete(self, education_id: str, user_id: str) -> None:
        start = time.monotonic()
        log.info("Deleting education | id=%s, user_id=%s", education_id, user_id)

        self._validate_object_id(education_id)

        try:
            deleted = await self.repo.delete_one(education_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid education ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to delete education | id=%s, error_type=%s, duration_ms=%s",
                education_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete education record.",
            )

        if deleted == 0:
            log.warning("Education not found for deletion | id=%s, user_id=%s", education_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Education not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Education deleted | id=%s, duration_ms=%s", education_id, elapsed)

    # ── Validation helpers ───────────────────────────────────────────

    @staticmethod
    def _validate_input(inp: EducationInput) -> None:
        errors: list[str] = []

        if not inp.org_name or not inp.org_name.strip():
            errors.append("Organization name is required.")
        if not inp.degree_level or not inp.degree_level.strip():
            errors.append("Degree level is required.")
        if not inp.degree_name or not inp.degree_name.strip():
            errors.append("Degree name is required.")
        if not inp.start_date or not inp.start_date.strip():
            errors.append("Start date is required.")

        if errors:
            log.warning("Education validation failed | errors=%s", errors)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=errors[0] if len(errors) == 1 else errors,
            )

    @staticmethod
    def _validate_object_id(oid: str) -> None:
        if not oid or len(oid) != 24:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid education ID format.",
            )
        try:
            int(oid, 16)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid education ID format.",
            )
