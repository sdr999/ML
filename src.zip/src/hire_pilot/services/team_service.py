from typing import List
from fastapi import HTTPException, status
from hire_pilot.models.team_member import TeamMember
from hire_pilot.repositories.team_repository import TeamRepository
from hire_pilot.utils.logger import log

class TeamService:
    def __init__(self):
        self.repo = TeamRepository()
        log.info("TeamService initialized")

    async def list_team(self, employer_id: str) -> List[TeamMember]:
        try:
            data = await self.repo.find_by_employer(employer_id)
            return [TeamMember.from_dict(m) for m in data]
        except Exception as exc:
            log.exception("Failed to list team | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve team members."
            )

    async def invite_member(self, employer_id: str, email: str, name: str, role: str) -> str:
        try:
            member_data = {
                "email": email,
                "name": name,
                "role": role,
                "status": "INVITED"
            }
            return await self.repo.insert_member(employer_id, member_data)
        except Exception as exc:
            log.exception("Failed to invite member | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to invite team member."
            )

    async def update_member_role(self, member_id: str, new_role: str) -> None:
        try:
            count = await self.repo.update_role(member_id, new_role)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Team member not found."
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to update role | id=%s, role=%s, error=%s", member_id, new_role, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update member role."
            )

    async def remove_member(self, member_id: str) -> None:
        try:
            count = await self.repo.delete_member(member_id)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Team member not found."
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to remove member | id=%s, error=%s", member_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to remove team member."
            )
