from typing import Any
from fastapi import HTTPException, status
from hire_pilot.repositories.profile_photo_repository import ProfilePhotoRepository
from hire_pilot.utils.logger import log

class ProfilePhotoService:
    def __init__(self):
        self.repo = ProfilePhotoRepository()
        log.info("ProfilePhotoService initialized")

    async def get_by_user(self, user_id: str) -> str:
        log.info("Fetching profile photo | user_id=%s", user_id)
        doc = await self.repo.find_one_by_user(user_id)
        if not doc or "photo" not in doc:
            return None
        return doc["photo"]

    async def update(self, user_id: str, photo: str) -> None:
        log.info("Updating profile photo | user_id=%s", user_id)
        await self.repo.upsert_one(user_id, photo)

    async def delete(self, user_id: str) -> None:
        log.info("Deleting profile photo | user_id=%s", user_id)
        await self.repo.delete_one(user_id)
