import base64
import json
import os
import io
import logging
from typing import Dict, Any

from fastapi import HTTPException

# Text extraction
try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None

try:
    from docx import Document
except ImportError:
    Document = None

# LLM
try:
    import openai
except ImportError:
    openai = None

logger = logging.getLogger(__name__)

# ── Comprehensive extraction prompt aligned with ProfileDetails schema ──

SYSTEM_PROMPT = """You are an expert resume/CV parsing AI. Your job is to extract EVERY piece of information from the resume text and return it as a strictly valid JSON object.

Extract ALL of the following sections. If a section has no data in the resume, return its default (empty list [] or null). Never omit a key.

{
  "basic_info": {
    "name": "Full name (string, required)",
    "email": "Email address (string, required — use empty string if not found)",
    "mobile": "Phone number (string, required — use empty string if not found)",
    "linkedin": "LinkedIn URL or null",
    "github": "GitHub URL or null",
    "address": "Full address or city/state or null"
  },

  "summary": "Professional summary, objective, or 'About Me' section as a single string. If none exists, synthesize a 2-3 sentence summary from the resume content.",

  "skills": ["Every skill, technology, tool, framework, methodology mentioned anywhere in the resume"],

  "work_experience": [
    {
      "company_name": "string",
      "role": "Job title (string)",
      "start_date": "MM/YY",
      "end_date": "MM/YY or null if currently working",
      "currently_working": false,
      "location": "City, State/Country (string, use 'Unknown' if not listed)",
      "tech_stack": ["technologies", "used", "in", "this", "role"],
      "description": "Bullet points of responsibilities and achievements in markdown format"
    }
  ],

  "education": [
    {
      "org_name": "University/school name (string)",
      "degree_level": "One of: 12TH, BACHELOR, MASTER, PHD",
      "degree_name": "e.g. Computer Science, MBA, etc. (string)",
      "start_date": "MM/YY",
      "end_date": "MM/YY or null if currently pursuing",
      "currently_pursuing": false,
      "tech_stack": ["relevant", "coursework", "or", "skills"],
      "description": "Notable coursework, thesis, honors, etc. or null",
      "score": null
    }
  ],

  "certifications": [
    {
      "name": "Certification name (string)",
      "org": "Issuing organization (string)",
      "end_date": "YYYY-MM-DD or null",
      "description": "Brief description or null",
      "url": "Credential URL or null"
    }
  ],

  "achievements": [
    {
      "name": "Award/achievement name (string)",
      "org": "Issuing organization (string)",
      "time": "YYYY-MM-DD (approximate date)",
      "description": "Details or null"
    }
  ],

  "languages": [
    {
      "name": "Language name (string)",
      "writing_prof": "One of: NATIVE, FLUENT, INTERMEDIATE, BASIC or null",
      "reading_prof": "One of: NATIVE, FLUENT, INTERMEDIATE, BASIC or null",
      "speaking_prof": "One of: NATIVE, FLUENT, INTERMEDIATE, BASIC or null"
    }
  ],

  "personal_projects": [
    {
      "name": "Project name (string)",
      "start": "MM/YY",
      "end": "MM/YY or null if ongoing",
      "tech_stack": ["technologies", "used"],
      "description": "What the project does (string)",
      "url": "Project/repo URL or null"
    }
  ],

  "employment_details": {
    "current_location": "Current city/location or null",
    "preferred_role": "Desired job title if mentioned, or null",
    "preferred_location": ["list of preferred cities/locations"] or null,
    "work_mode": "One of: REMOTE, HYBRID, ONSITE or null"
  }
}

STRICT RULES:
1. Dates with only a year → use "01/YY" for MM/YY fields.
2. `degree_level` MUST be one of: 12TH, BACHELOR, MASTER, PHD. Map "B.Tech/B.Sc/BA/BBA" → BACHELOR, "M.Tech/M.Sc/MA/MBA" → MASTER, "Ph.D/Doctorate" → PHD, "High School/HSC/12th" → 12TH.
3. Proficiency enums MUST be one of: NATIVE, FLUENT, INTERMEDIATE, BASIC.
4. `work_mode` MUST be one of: REMOTE, HYBRID, ONSITE.
5. Output ONLY valid JSON. No markdown fences, no commentary.
6. Extract EVERYTHING. Do not skip sections. If data is missing for a section, return its empty default.
7. For tech_stack in work_experience, infer from the job description if not explicitly listed.
8. For skills, be exhaustive — include technical skills, soft skills, tools, and frameworks.
"""


class ResumeParserService:

    def _detect_and_extract_text(self, file_bytes: bytes) -> str:
        """Detect file type from magic bytes and extract all text."""

        # ── PDF ──────────────────────────────────────────────────────
        if file_bytes.startswith(b"%PDF"):
            if not fitz:
                raise HTTPException(status_code=500, detail="PyMuPDF not installed for PDF parsing.")
            try:
                doc = fitz.open(stream=file_bytes, filetype="pdf")
                text = ""
                for page in doc:
                    text += page.get_text()
                doc.close()
                return text
            except Exception as e:
                logger.error(f"Error parsing PDF: {e}")
                raise HTTPException(status_code=400, detail="Invalid or corrupted PDF file.")

        # ── DOCX (ZIP-based Office Open XML) ─────────────────────────
        elif file_bytes.startswith(b"PK\x03\x04"):
            if not Document:
                raise HTTPException(status_code=500, detail="python-docx not installed for DOCX parsing.")
            try:
                doc = Document(io.BytesIO(file_bytes))
                text = "\n".join([para.text for para in doc.paragraphs])
                return text
            except Exception as e:
                logger.error(f"Error parsing DOCX: {e}")
                raise HTTPException(status_code=400, detail="Invalid or corrupted DOCX file.")

        # ── Plain text fallback (.tex, .txt, .md) ────────────────────
        else:
            try:
                return file_bytes.decode("utf-8")
            except UnicodeDecodeError:
                raise HTTPException(
                    status_code=400,
                    detail="Unsupported file format or encoding. Please upload PDF, DOCX, or plain-text (TXT/TEX).",
                )

    async def _parse_with_llm(self, text: str) -> Dict[str, Any]:
        """Send extracted text to OpenAI and get structured profile JSON."""
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key or not openai:
            logger.error("OPENAI_API_KEY is not configured or openai package is missing.")
            raise HTTPException(status_code=500, detail="LLM parsing is not configured on the server.")

        client = openai.AsyncOpenAI(api_key=api_key)

        try:
            response = await client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": f"Resume Text:\n\n{text}"},
                ],
                response_format={"type": "json_object"},
                temperature=0.0,
            )

            content = response.choices[0].message.content
            return json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(f"LLM returned invalid JSON: {e}")
            raise HTTPException(status_code=500, detail="AI returned malformed data. Please retry.")
        except Exception as e:
            logger.error(f"LLM parsing failed: {e}")
            raise HTTPException(status_code=500, detail="Failed to parse resume with AI.")

    async def parse_resume(self, base64_document: str) -> Dict[str, Any]:
        """Decode → extract text → LLM parse → return structured JSON."""
        try:
            file_bytes = base64.b64decode(base64_document)
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid base64 encoding.")

        if not file_bytes:
            raise HTTPException(status_code=400, detail="Empty document provided.")

        text = self._detect_and_extract_text(file_bytes)

        if not text or not text.strip():
            raise HTTPException(status_code=400, detail="Could not extract any text from the document.")

        parsed_data = await self._parse_with_llm(text)
        return parsed_data
