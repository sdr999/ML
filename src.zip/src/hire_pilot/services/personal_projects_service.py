import time
from typing import List

from bson.errors import InvalidId
from fastapi import HTTPException, status
from hire_pilot.models.personal_project import PersonalProject
from hire_pilot.models.personal_project_input import PersonalProjectInput
from hire_pilot.repositories.personal_projects_repository import PersonalProjectsRepository
from hire_pilot.utils.logger import log


class PersonalProjectsService:
    def __init__(self):
        self.repo = PersonalProjectsRepository()
        log.info("PersonalProjectsService initialized")

    # ── List all ─────────────────────────────────────────────────────

    async def get_all(self, user_id: str) -> List[PersonalProject]:
        start = time.monotonic()
        log.info("Fetching all personal projects | user_id=%s", user_id)

        try:
            docs = await self.repo.find_all_by_user(user_id)
            projects = [PersonalProject(**doc) for doc in docs]
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Fetched personal projects | user_id=%s, count=%d, duration_ms=%s",
                user_id, len(projects), elapsed,
            )
            return projects

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch personal projects | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve personal projects.",
            )

    # ── Get one ──────────────────────────────────────────────────────

    async def get_by_id(self, project_id: str, user_id: str) -> PersonalProject:
        start = time.monotonic()
        log.info("Fetching personal project | id=%s, user_id=%s", project_id, user_id)

        self._validate_object_id(project_id)

        try:
            doc = await self.repo.find_one_by_id(project_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid personal project ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch personal project | id=%s, error_type=%s, duration_ms=%s",
                project_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve personal project.",
            )

        if doc is None:
            log.warning("Personal project not found | id=%s, user_id=%s", project_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Personal project not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Fetched personal project | id=%s, duration_ms=%s", project_id, elapsed)
        return PersonalProject(**doc)

    # ── Create ───────────────────────────────────────────────────────

    async def create(self, user_id: str, project_input: PersonalProjectInput) -> str:
        start = time.monotonic()
        log.info("Creating personal project | user_id=%s", user_id)

        self._validate_input(project_input)

        try:
            data = project_input.to_dict()
            inserted_id = await self.repo.insert_one(user_id, data)

            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Personal project created | id=%s, user_id=%s, duration_ms=%s",
                inserted_id, user_id, elapsed,
            )
            return inserted_id

        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to create personal project | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create personal project.",
            )

    # ── Update ───────────────────────────────────────────────────────

    async def update(
        self, project_id: str, user_id: str, project_input: PersonalProjectInput
    ) -> None:
        start = time.monotonic()
        log.info("Updating personal project | id=%s, user_id=%s", project_id, user_id)

        self._validate_object_id(project_id)
        self._validate_input(project_input)

        try:
            data = project_input.to_dict()
            modified = await self.repo.update_one(project_id, user_id, data)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid personal project ID format.",
            )
        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update personal project | id=%s, error_type=%s, duration_ms=%s",
                project_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update personal project.",
            )

        if modified == 0:
            log.warning("Personal project not found for update | id=%s, user_id=%s", project_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Personal project not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Personal project updated | id=%s, duration_ms=%s", project_id, elapsed)

    # ── Delete ───────────────────────────────────────────────────────

    async def delete(self, project_id: str, user_id: str) -> None:
        start = time.monotonic()
        log.info("Deleting personal project | id=%s, user_id=%s", project_id, user_id)

        self._validate_object_id(project_id)

        try:
            deleted = await self.repo.delete_one(project_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid personal project ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to delete personal project | id=%s, error_type=%s, duration_ms=%s",
                project_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete personal project.",
            )

        if deleted == 0:
            log.warning("Personal project not found for deletion | id=%s, user_id=%s", project_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Personal project not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Personal project deleted | id=%s, duration_ms=%s", project_id, elapsed)

    # ── Validation helpers ───────────────────────────────────────────

    @staticmethod
    def _validate_input(inp: PersonalProjectInput) -> None:
        errors: list[str] = []

        if not inp.name or not inp.name.strip():
            errors.append("Project name is required.")

        if errors:
            log.warning("Personal project validation failed | errors=%s", errors)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=errors[0] if len(errors) == 1 else errors,
            )

    @staticmethod
    def _validate_object_id(oid: str) -> None:
        if not oid or len(oid) != 24:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid personal project ID format.",
            )
        try:
            int(oid, 16)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid personal project ID format.",
            )
