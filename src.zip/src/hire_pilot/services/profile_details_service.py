import asyncio
import time
from fastapi import HTTPException, status
from hire_pilot.models.profile_details import ProfileDetails
from hire_pilot.utils.logger import log

from hire_pilot.services.achievements_service import AchievementsService
from hire_pilot.services.basic_info_service import BasicInfoService
from hire_pilot.services.certifications_service import CertificationsService
from hire_pilot.services.diversity_service import DiversityService
from hire_pilot.services.education_service import EducationService
from hire_pilot.services.employment_details_service import EmploymentDetailsService
from hire_pilot.services.languages_service import LanguagesService
from hire_pilot.services.personal_projects_service import PersonalProjectsService
from hire_pilot.services.skills_service import SkillsService
from hire_pilot.services.summary_service import SummaryService
from hire_pilot.services.work_experience_service import WorkExperienceService

from hire_pilot.repositories.user_repository import UserRepository

class ProfileDetailsService:
    def __init__(self):
        self.user_repo = UserRepository()
        self.achievements_svc = AchievementsService()
        self.basic_info_svc = BasicInfoService()
        self.certifications_svc = CertificationsService()
        self.diversity_svc = DiversityService()
        self.education_svc = EducationService()
        self.employment_details_svc = EmploymentDetailsService()
        self.languages_svc = LanguagesService()
        self.personal_projects_svc = PersonalProjectsService()
        self.skills_svc = SkillsService()
        self.summary_svc = SummaryService()
        self.work_experience_svc = WorkExperienceService()
        log.info("ProfileDetailsService initialized")

    async def get_full_profile(self, user_id: str) -> ProfileDetails:
        start = time.monotonic()
        log.info("Fetching full profile details | user_id=%s", user_id)
        
        try:
            # Gather all requests concurrently for low latency
            results = await asyncio.gather(
                self.achievements_svc.get_all(user_id),
                self.certifications_svc.get_all(user_id),
                self.diversity_svc.get_by_user(user_id),
                self.education_svc.get_all(user_id),
                self.employment_details_svc.get_all(user_id, page=1, limit=100),
                self.languages_svc.get_all(user_id),
                self.personal_projects_svc.get_all(user_id),
                self.skills_svc.get_by_user(user_id),
                self.summary_svc.get_by_user(user_id),
                self.work_experience_svc.get_all(user_id, page=1, limit=100),
                self.basic_info_svc.get_by_user(user_id),
                self.user_repo.get_user_role(user_id),
                return_exceptions=True
            )
            
            # Helper to safely extract results or empty structures if the service threw an error (or 404)
            def safe_extract(idx, default_value):
                result = results[idx]
                if isinstance(result, Exception):
                    log.warning("Service threw exception during full profile aggregation | index=%d, error=%s", idx, result)
                    return default_value
                return result

            achievements = safe_extract(0, [])
            certifications = safe_extract(1, [])
            diversity = safe_extract(2, None)
            education = safe_extract(3, [])
            employment_details = safe_extract(4, [])
            languages = safe_extract(5, [])
            personal_projects = safe_extract(6, [])
            skills = safe_extract(7, [])
            
            # Summary returns a ProfileSummaryGet200Response model, we want just the string
            summary_response = safe_extract(8, None)
            summary_str = None
            if summary_response and hasattr(summary_response, 'summary'):
                summary_str = summary_response.summary

            work_experience = safe_extract(9, [])
            basic_info = safe_extract(10, None)
            role = safe_extract(11, 'employee')
            
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info("Fetched full profile details successfully | user_id=%s, duration_ms=%s", user_id, elapsed)
            
            return ProfileDetails(
                basic_info=basic_info,
                achievements=achievements,
                certifications=certifications,
                diversity=diversity,
                education=education,
                employment_details=employment_details,
                languages=languages,
                personal_projects=personal_projects,
                skills=skills,
                summary=summary_str,
                work_experience=work_experience,
                role=role
            )
            
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception("Failed to aggregate profile details | user_id=%s, error_type=%s, duration_ms=%s", user_id, type(exc).__name__, elapsed)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to aggregate profile details."
            )

    async def get_profile_completion(self, user_id: str) -> dict:
        """Calculate profile completion percentage and list missing sections."""
        log.info("Calculating profile completion | user_id=%s", user_id)

        sections = {
            "basic_info": ("Basic Info", self.basic_info_svc.get_by_user),
            "summary": ("Professional Summary", self.summary_svc.get_by_user),
            "skills": ("Skills", self.skills_svc.get_by_user),
            "education": ("Education", self.education_svc.get_all),
            "work_experience": ("Work Experience", self.work_experience_svc.get_all),
            "employment_details": ("Employment Details", None),
            "certifications": ("Certifications", self.certifications_svc.get_all),
            "languages": ("Languages", self.languages_svc.get_all),
            "achievements": ("Achievements", self.achievements_svc.get_all),
            "personal_projects": ("Projects", self.personal_projects_svc.get_all),
        }

        try:
            results = await asyncio.gather(
                self.basic_info_svc.get_by_user(user_id),
                self.summary_svc.get_by_user(user_id),
                self.skills_svc.get_by_user(user_id),
                self.education_svc.get_all(user_id),
                self.work_experience_svc.get_all(user_id, page=1, limit=100),
                self.employment_details_svc.get_all(user_id, page=1, limit=100),
                self.certifications_svc.get_all(user_id),
                self.languages_svc.get_all(user_id),
                self.achievements_svc.get_all(user_id),
                self.personal_projects_svc.get_all(user_id),
                return_exceptions=True,
            )

            def is_filled(idx, result):
                if isinstance(result, Exception):
                    return False
                if result is None:
                    return False
                if isinstance(result, list):
                    return len(result) > 0
                if hasattr(result, "summary"):
                    return bool(result.summary)
                if hasattr(result, "name"):
                    return bool(result.name)
                return bool(result)

            section_keys = [
                "basic_info", "summary", "skills", "education",
                "work_experience", "employment_details", "certifications",
                "languages", "achievements", "personal_projects",
            ]
            section_labels = [
                "Basic Info", "Professional Summary", "Skills", "Education",
                "Work Experience", "Employment Details", "Certifications",
                "Languages", "Achievements", "Projects",
            ]

            completed = []
            missing = []
            for i, key in enumerate(section_keys):
                if is_filled(i, results[i]):
                    completed.append({"key": key, "label": section_labels[i]})
                else:
                    missing.append({"key": key, "label": section_labels[i]})

            total = len(section_keys)
            pct = round((len(completed) / total) * 100) if total > 0 else 0

            return {
                "percentage": pct,
                "total_sections": total,
                "completed_count": len(completed),
                "completed": completed,
                "missing": missing,
            }
        except Exception as exc:
            log.exception("Failed to calculate profile completion | user_id=%s, error=%s", user_id, str(exc))
            return {"percentage": 0, "total_sections": 10, "completed_count": 0, "completed": [], "missing": []}
