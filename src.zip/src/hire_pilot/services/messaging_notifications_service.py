from typing import Any, List, Optional, Dict
from fastapi import HTTPException, status
from hire_pilot.repositories.messaging_notifications_repository import MessagingNotificationsRepository
from hire_pilot.utils.logger import log

class MessagingNotificationsService:
    def __init__(self):
        self.repo = MessagingNotificationsRepository()

    async def send_message(self, employer_id: str, candidate_id: str, sender: str, text: str) -> Dict[str, Any]:
        try:
            msg_id = await self.repo.insert_message(employer_id, candidate_id, sender, text)
            
            # If the employer is sending, simulate a quick candidate reply after a tiny latency in real usage, 
            # but here we'll just return the message details
            return {
                "id": msg_id,
                "employer_id": employer_id,
                "candidate_id": candidate_id,
                "sender": sender,
                "text": text,
                "message": "Message dispatched successfully."
            }
        except Exception as exc:
            log.exception("Failed to dispatch message | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to send message."
            )

    async def list_conversations(self, employer_id: str) -> List[Dict[str, Any]]:
        try:
            convs = await self.repo.find_conversations(employer_id)
            
            # Seed conversation if empty, to ensure stunning visual demonstration!
            if not convs:
                log.info("No conversations found, seeding premium candidate conversations for employer_id=%s", employer_id)
                # Let's find some candidate users in the DB to associate the seeds with, 
                # or fallback to uuid constants if none found
                cand_ids = ["cand_jane_doe", "cand_john_smith"]
                try:
                    candidates = await self.repo.adapter.find_many("users", {"role": "employee"})
                    if len(candidates) >= 1:
                        cand_ids = [c["user_id"] for c in candidates[:2]]
                except:
                    pass
                
                # Insert mock seed exchange
                await self.repo.insert_message(employer_id, cand_ids[0], "employer", "Hi Jane! We reviewed your profile and loved your React experience. Are you available for a chat tomorrow?")
                await self.repo.insert_message(employer_id, cand_ids[0], "candidate", "Hi! Thank you so much for reaching out. Yes, I am absolutely available! What time works for you?")
                
                if len(cand_ids) > 1:
                    await self.repo.insert_message(employer_id, cand_ids[1], "employer", "Hello John, could you share your updated resume and notice period?")
                    await self.repo.insert_message(employer_id, cand_ids[1], "candidate", "Sure, here is my resume. My notice period is 15 days.")
                
                convs = await self.repo.find_conversations(employer_id)
                
            return convs
        except Exception as exc:
            log.exception("Failed to load conversations | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve conversations list."
            )

    async def list_messages(self, employer_id: str, candidate_id: str) -> List[Dict[str, Any]]:
        try:
            return await self.repo.find_messages(employer_id, candidate_id)
        except Exception as exc:
            log.exception("Failed to fetch messages | candidate_id=%s, error=%s", candidate_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve message logs."
            )

    async def candidate_list_conversations(self, candidate_id: str) -> List[Dict[str, Any]]:
        """Return all conversation threads that include this candidate (from employer side)."""
        try:
            return await self.repo.find_conversations_by_candidate(candidate_id)
        except Exception as exc:
            log.exception("candidate_list_conversations failed | candidate_id=%s, error=%s", candidate_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve candidate inbox."
            )

    async def candidate_list_messages(self, candidate_id: str, employer_id: str) -> List[Dict[str, Any]]:
        """Return messages between this candidate and a specific employer."""
        try:
            return await self.repo.find_messages(employer_id, candidate_id)
        except Exception as exc:
            log.exception("candidate_list_messages failed | candidate_id=%s, error=%s", candidate_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve message thread."
            )

    async def send_email(self, employer_id: str, candidate_ids: List[str], subject: str, body: str) -> Dict[str, Any]:
        try:
            log.info("Simulating dispatch of bulk email | employer=%s, candidates=%s, subject=%s", employer_id, candidate_ids, subject)
            # Create a notification recording this bulk email dispatch
            await self.repo.create_notification(
                user_id=employer_id,
                title="Bulk Email Dispatched",
                message=f"Your email with subject '{subject}' was dispatched to {len(candidate_ids)} candidates.",
                notify_type="email"
            )
            return {
                "message": f"Successfully simulated sending email to {len(candidate_ids)} candidates.",
                "recipient_count": len(candidate_ids)
            }
        except Exception as exc:
            log.exception("Email dispatch simulation failed | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to dispatch bulk email."
            )

    async def send_sms(self, employer_id: str, candidate_id: str, message: str) -> Dict[str, Any]:
        try:
            log.info("Simulating SMS dispatch | employer=%s, candidate=%s", employer_id, candidate_id)
            # Create notification
            await self.repo.create_notification(
                user_id=employer_id,
                title="SMS Dispatch Completed",
                message=f"SMS sent successfully to candidate: '{message[:30]}...'",
                notify_type="sms"
            )
            return {"message": "Successfully simulated SMS sending."}
        except Exception as exc:
            log.exception("SMS dispatch simulation failed | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to dispatch SMS."
            )

    async def list_notifications(self, user_id: str) -> List[Dict[str, Any]]:
        try:
            notes = await self.repo.find_notifications(user_id)
            
            # Seed initial beautiful notifications if empty
            if not notes:
                log.info("No notifications found, seeding welcome notifications for user_id=%s", user_id)
                await self.repo.create_notification(
                    user_id=user_id,
                    title="Welcome to HirePilot!",
                    message="Start creating jobs, scheduling interviews, and exploring the Talent Database with our dynamic, interactive employer workspace.",
                    notify_type="general"
                )
                await self.repo.create_notification(
                    user_id=user_id,
                    title="Unlock Advanced Candidate Pipelines",
                    message="Upgrade to the Pro tier today to unlock infinite talent pools, SMS automation, and detailed candidate pipeline reports.",
                    notify_type="billing"
                )
                notes = await self.repo.find_notifications(user_id)
                
            return notes
        except Exception as exc:
            log.exception("Failed to load notifications | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve notification feed."
            )

    async def read_notification(self, user_id: str, notification_id: str) -> Dict[str, Any]:
        try:
            success = await self.repo.mark_notification_read(user_id, notification_id)
            if not success:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Notification not found or unauthorized."
                )
            return {"message": "Notification marked as read successfully."}
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to read notification | id=%s, error=%s", notification_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update notification."
            )
