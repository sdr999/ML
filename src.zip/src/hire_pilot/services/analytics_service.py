import asyncio
from typing import Any, Dict, List, Optional
from hire_pilot.models.dashboard_metrics import DashboardMetrics
from hire_pilot.models.interview_report import InterviewReport
from hire_pilot.models.job_report import JobReport
from hire_pilot.repositories.analytics_repository import AnalyticsRepository


class AnalyticsService:
    def __init__(self):
        self.repo = AnalyticsRepository()

    async def get_dashboard(self, employer_id: str) -> DashboardMetrics:
        (
            total_apps,
            total_views,
            funnel,
            time_to_hire,
            total_spend,
            hired_count,
        ) = await asyncio.gather(
            self.repo.count_applications_for_employer(employer_id),
            self.repo.count_views_for_employer(employer_id),
            self.repo.get_hiring_funnel(employer_id),
            self.repo.get_time_to_hire(employer_id),
            self.repo.get_total_spend(employer_id),
            self.repo.count_hired(employer_id),
        )

        ctr = round((total_apps / total_views * 100), 2) if total_views > 0 else 0.0
        ctr = min(ctr, 100.0)
        cost_per_hire = round(total_spend / hired_count, 2) if hired_count > 0 else None

        all_statuses = [
            "applied", "screening", "shortlisted", "interview_scheduled",
            "offered", "hired", "rejected", "withdrawn",
        ]
        normalised_funnel = {s: funnel.get(s, 0) for s in all_statuses}

        return DashboardMetrics(
            total_applications=total_apps,
            total_views=total_views,
            ctr=ctr,
            hiring_funnel=normalised_funnel,
            time_to_hire=time_to_hire,
            cost_per_hire=cost_per_hire,
        )

    async def get_job_reports(self, employer_id: str) -> List[JobReport]:
        rows = await self.repo.get_per_job_stats(employer_id)
        return [
            JobReport(
                job_id=r["job_id"],
                title=r.get("title", ""),
                views=r.get("views", 0),
                applications=r.get("applications", 0),
                shortlisted=r.get("shortlisted", 0),
                hired=r.get("hired", 0),
                avg_time_to_fill=None,
            )
            for r in rows
        ]

    async def get_candidate_report(self, employer_id: str) -> Dict[str, Any]:
        funnel = await self.repo.get_hiring_funnel(employer_id)
        all_statuses = [
            "applied", "screening", "shortlisted", "interview_scheduled",
            "offered", "hired", "rejected", "withdrawn",
        ]
        return {s: funnel.get(s, 0) for s in all_statuses}

    async def record_event(
        self,
        event_type: str,
        job_id: str,
        employer_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> str:
        return await self.repo.insert_event(event_type, job_id, employer_id, metadata)

    async def get_interview_report(self, employer_id: str) -> InterviewReport:
        stats = await self.repo.get_interview_stats(employer_id)
        completed = stats["completed"]
        hired_after = stats["hired_after_interview"]
        pass_rate = round(hired_after / completed * 100, 2) if completed > 0 else 0.0
        return InterviewReport(
            total_interviews=stats["total_interviews"],
            completed=completed,
            pass_rate=pass_rate,
            avg_feedback_score=stats["avg_feedback_score"],
        )
