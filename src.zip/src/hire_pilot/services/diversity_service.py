import time

from fastapi import HTTPException, status
from hire_pilot.models.diversity import Diversity
from hire_pilot.repositories.diversity_repository import DiversityRepository
from hire_pilot.utils.logger import log


class DiversityService:
    def __init__(self):
        self.repo = DiversityRepository()
        log.info("DiversityService initialized")

    async def get_by_user(self, user_id: str) -> Diversity:
        start = time.monotonic()
        log.info("Fetching diversity info | user_id=%s", user_id)

        try:
            doc = await self.repo.find_one_by_user(user_id)
            if doc is None:
                # If no diversity record exists, return an empty Diversity model
                doc = {}
                
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info("Fetched diversity info | user_id=%s, duration_ms=%s", user_id, elapsed)
            return Diversity(**doc)

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch diversity info | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve diversity info.",
            )

    async def update(self, user_id: str, diversity: Diversity) -> None:
        start = time.monotonic()
        log.info("Updating diversity info | user_id=%s", user_id)

        try:
            data = diversity.to_dict()
            await self.repo.upsert_one(user_id, data)
            
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info("Diversity info updated | user_id=%s, duration_ms=%s", user_id, elapsed)

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update diversity info | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update diversity info.",
            )
