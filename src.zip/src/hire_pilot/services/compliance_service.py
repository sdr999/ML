from datetime import datetime, timezone
from typing import List
from fastapi import HTTPException
from hire_pilot.models.moderation_report import ModerationReport, ModerationStatus
from hire_pilot.models.policy import Policy
from hire_pilot.repositories.compliance_repository import ComplianceRepository
from hire_pilot.repositories.user_repository import UserRepository

POLICIES = [
    {
        "id": "policy_terms",
        "title": "Terms of Service",
        "content": (
            "By using HirePilot, you agree to our terms of service. "
            "Employers must post accurate job listings and treat candidates fairly. "
            "Any misuse of the platform may result in account suspension."
        ),
        "category": "Legal",
        "effective_date": "2024-01-01",
    },
    {
        "id": "policy_privacy",
        "title": "Privacy Policy",
        "content": (
            "HirePilot collects and processes personal data in accordance with applicable "
            "data protection laws. Candidate data is used solely for recruitment purposes "
            "and is not sold to third parties."
        ),
        "category": "Privacy",
        "effective_date": "2024-01-01",
    },
    {
        "id": "policy_conduct",
        "title": "Candidate Conduct Policy",
        "content": (
            "Candidates must provide accurate information in their profiles and applications. "
            "Fraudulent credentials, spam applications, or harassment of employers will result "
            "in immediate account termination."
        ),
        "category": "Conduct",
        "effective_date": "2024-01-01",
    },
    {
        "id": "policy_data_retention",
        "title": "Data Retention Policy",
        "content": (
            "Application data is retained for 2 years after a job is closed. "
            "Candidates may request deletion of their data at any time via account settings. "
            "Anonymised analytics data may be retained indefinitely."
        ),
        "category": "Data",
        "effective_date": "2024-01-01",
    },
]


class ComplianceService:
    def __init__(self):
        self.repo = ComplianceRepository()
        self.user_repo = UserRepository()

    async def list_policies(self) -> List[Policy]:
        return [Policy(**p) for p in POLICIES]

    async def report_candidate(
        self,
        reporter_id: str,
        reported_candidate_id: str,
        reason: str,
        description: str | None,
    ) -> ModerationReport:
        candidate = await self.user_repo.find_by_user_id(reported_candidate_id)
        if not candidate:
            raise HTTPException(status_code=400, detail="Candidate not found")

        now = datetime.now(timezone.utc)
        data = {
            "reporter_id": reporter_id,
            "reported_candidate_id": reported_candidate_id,
            "reason": reason,
            "description": description,
            "status": ModerationStatus.OPEN.value,
            "created_at": now.isoformat(),
        }
        inserted_id = await self.repo.insert_report(data)
        return ModerationReport(
            id=inserted_id,
            reporter_id=reporter_id,
            reported_candidate_id=reported_candidate_id,
            reason=reason,
            description=description,
            status=ModerationStatus.OPEN,
            created_at=now,
        )
