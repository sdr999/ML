import time
from typing import List

from bson.errors import InvalidId
from fastapi import HTTPException, status
from hire_pilot.models.certification import Certification
from hire_pilot.models.certification_input import CertificationInput
from hire_pilot.repositories.certifications_repository import CertificationsRepository
from hire_pilot.utils.logger import log


class CertificationsService:
    def __init__(self):
        self.repo = CertificationsRepository()
        log.info("CertificationsService initialized")

    # ── List all ─────────────────────────────────────────────────────

    async def get_all(self, user_id: str) -> List[Certification]:
        start = time.monotonic()
        log.info("Fetching all certifications | user_id=%s", user_id)

        try:
            docs = await self.repo.find_all_by_user(user_id)
            certifications = [Certification(**doc) for doc in docs]
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Fetched certifications | user_id=%s, count=%d, duration_ms=%s",
                user_id, len(certifications), elapsed,
            )
            return certifications

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch certifications | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve certifications.",
            )

    # ── Get one ──────────────────────────────────────────────────────

    async def get_by_id(self, certification_id: str, user_id: str) -> Certification:
        start = time.monotonic()
        log.info("Fetching certification | id=%s, user_id=%s", certification_id, user_id)

        self._validate_object_id(certification_id)

        try:
            doc = await self.repo.find_one_by_id(certification_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid certification ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch certification | id=%s, error_type=%s, duration_ms=%s",
                certification_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve certification.",
            )

        if doc is None:
            log.warning("Certification not found | id=%s, user_id=%s", certification_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Certification not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Fetched certification | id=%s, duration_ms=%s", certification_id, elapsed)
        return Certification(**doc)

    # ── Create ───────────────────────────────────────────────────────

    async def create(self, user_id: str, certification_input: CertificationInput) -> str:
        start = time.monotonic()
        log.info("Creating certification | user_id=%s", user_id)

        self._validate_input(certification_input)

        try:
            data = certification_input.to_dict()
            # Convert date to ISO string for MongoDB serialization
            if "end_date" in data and hasattr(data["end_date"], "isoformat"):
                data["end_date"] = data["end_date"].isoformat()
            inserted_id = await self.repo.insert_one(user_id, data)

            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Certification created | id=%s, user_id=%s, duration_ms=%s",
                inserted_id, user_id, elapsed,
            )
            return inserted_id

        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to create certification | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create certification.",
            )

    # ── Update ───────────────────────────────────────────────────────

    async def update(
        self, certification_id: str, user_id: str, certification_input: CertificationInput
    ) -> None:
        start = time.monotonic()
        log.info("Updating certification | id=%s, user_id=%s", certification_id, user_id)

        self._validate_object_id(certification_id)
        self._validate_input(certification_input)

        try:
            data = certification_input.to_dict()
            if "end_date" in data and hasattr(data["end_date"], "isoformat"):
                data["end_date"] = data["end_date"].isoformat()
            modified = await self.repo.update_one(certification_id, user_id, data)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid certification ID format.",
            )
        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update certification | id=%s, error_type=%s, duration_ms=%s",
                certification_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update certification.",
            )

        if modified == 0:
            log.warning("Certification not found for update | id=%s, user_id=%s", certification_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Certification not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Certification updated | id=%s, duration_ms=%s", certification_id, elapsed)

    # ── Delete ───────────────────────────────────────────────────────

    async def delete(self, certification_id: str, user_id: str) -> None:
        start = time.monotonic()
        log.info("Deleting certification | id=%s, user_id=%s", certification_id, user_id)

        self._validate_object_id(certification_id)

        try:
            deleted = await self.repo.delete_one(certification_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid certification ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to delete certification | id=%s, error_type=%s, duration_ms=%s",
                certification_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete certification.",
            )

        if deleted == 0:
            log.warning("Certification not found for deletion | id=%s, user_id=%s", certification_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Certification not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Certification deleted | id=%s, duration_ms=%s", certification_id, elapsed)

    # ── Validation helpers ───────────────────────────────────────────

    @staticmethod
    def _validate_input(inp: CertificationInput) -> None:
        errors: list[str] = []

        if not inp.name or not inp.name.strip():
            errors.append("Certification name is required.")
        if not inp.org or not inp.org.strip():
            errors.append("Organization is required.")

        if errors:
            log.warning("Certification validation failed | errors=%s", errors)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=errors[0] if len(errors) == 1 else errors,
            )

    @staticmethod
    def _validate_object_id(oid: str) -> None:
        """Fail fast if the ID is clearly not a valid 24-hex ObjectId."""
        if not oid or len(oid) != 24:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid certification ID format.",
            )
        try:
            int(oid, 16)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid certification ID format.",
            )
