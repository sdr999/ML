import time

from fastapi import HTTPException, status
from hire_pilot.models.profile_summary_get200_response import ProfileSummaryGet200Response
from hire_pilot.models.profile_summary_put_request import ProfileSummaryPutRequest
from hire_pilot.repositories.summary_repository import SummaryRepository
from hire_pilot.utils.logger import log


class SummaryService:
    def __init__(self):
        self.repo = SummaryRepository()
        log.info("SummaryService initialized")

    # ── Get one ──────────────────────────────────────────────────────

    async def get_by_user(self, user_id: str) -> ProfileSummaryGet200Response:
        start = time.monotonic()
        log.info("Fetching summary | user_id=%s", user_id)

        try:
            doc = await self.repo.find_one_by_user(user_id)
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch summary | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve summary.",
            )

        if doc is None:
            log.warning("Summary not found, returning empty | user_id=%s", user_id)
            return ProfileSummaryGet200Response(summary=None)

        elapsed = round((time.monotonic() - start) * 1000, 2)
        summary_text = doc.get("summary", None)
        log.info("Fetched summary | user_id=%s, duration_ms=%s", user_id, elapsed)
        return ProfileSummaryGet200Response(summary=summary_text)

    # ── Update ───────────────────────────────────────────────────────

    async def update(self, user_id: str, request: ProfileSummaryPutRequest) -> None:
        start = time.monotonic()
        log.info("Updating summary | user_id=%s", user_id)

        summary_text = request.summary if request.summary else ""
        summary_text = summary_text.strip()

        try:
            await self.repo.upsert_one(user_id, summary_text)

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update summary | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update summary.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Summary updated | user_id=%s, duration_ms=%s", user_id, elapsed)
