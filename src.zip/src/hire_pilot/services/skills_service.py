import time
from typing import List

from fastapi import HTTPException, status
from hire_pilot.repositories.skills_repository import SkillsRepository
from hire_pilot.utils.logger import log


class SkillsService:
    def __init__(self):
        self.repo = SkillsRepository()
        log.info("SkillsService initialized")

    # ── Get one ──────────────────────────────────────────────────────

    async def get_by_user(self, user_id: str) -> List[str]:
        start = time.monotonic()
        log.info("Fetching skills | user_id=%s", user_id)

        try:
            doc = await self.repo.find_one_by_user(user_id)
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch skills | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve skills.",
            )

        if doc is None:
            log.warning("Skills not found, returning empty | user_id=%s", user_id)
            return []

        elapsed = round((time.monotonic() - start) * 1000, 2)
        skills = doc.get("skills", [])
        log.info("Fetched skills | user_id=%s, count=%d, duration_ms=%s", user_id, len(skills), elapsed)
        return skills

    # ── Update ───────────────────────────────────────────────────────

    async def update(self, user_id: str, skills: List[str]) -> None:
        start = time.monotonic()
        log.info("Updating skills | user_id=%s", user_id)

        self._validate_input(skills)

        # Sanitize skills (strip whitespace, remove empty, remove duplicates preserving order)
        cleaned_skills = []
        seen = set()
        for skill in skills:
            if not skill:
                continue
            cleaned = str(skill).strip()
            if cleaned and cleaned not in seen:
                seen.add(cleaned)
                cleaned_skills.append(cleaned)

        try:
            await self.repo.upsert_one(user_id, cleaned_skills)

        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update skills | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update skills.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Skills updated | user_id=%s, count=%d, duration_ms=%s", user_id, len(cleaned_skills), elapsed)

    # ── Validation helpers ───────────────────────────────────────────

    @staticmethod
    def _validate_input(skills: List[str]) -> None:
        if skills is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Skills list cannot be null.",
            )
        
        if not isinstance(skills, list):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Skills must be a list of strings.",
            )
