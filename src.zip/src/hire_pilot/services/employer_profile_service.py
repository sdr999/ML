from fastapi import HTTPException, status
from hire_pilot.models.company_profile import CompanyProfile
from hire_pilot.repositories.company_repository import CompanyRepository
from hire_pilot.repositories.user_repository import UserRepository
from hire_pilot.utils.logger import log

class EmployerProfileService:
    def __init__(self):
        self.company_repo = CompanyRepository()
        self.user_repo = UserRepository()
        log.info("EmployerProfileService initialized")

    async def get_employer_profile(self, user_id: str) -> dict:
        log.info("Fetching employer profile | user_id=%s", user_id)
        try:
            user_doc = await self.user_repo.find_by_user_id(user_id)
            if not user_doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Employer profile not found."
                )
            # Return personal info
            return {
                "first_name": user_doc.get("first_name"),
                "middle_name": user_doc.get("middle_name"),
                "last_name": user_doc.get("last_name"),
                "email": user_doc.get("email"),
                "mobile_no": user_doc.get("mobile_no"),
                "designation": user_doc.get("designation"),
            }
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to fetch employer profile | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error while fetching employer profile."
            )

    async def update_employer_profile(self, user_id: str, data: dict) -> None:
        log.info("Updating employer profile | user_id=%s", user_id)
        try:
            # For simplicity, we just update the user document in UserRepository
            # We might need a proper update method in UserRepository
            existing = await self.user_repo.find_by_user_id(user_id)
            if not existing:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Employer profile not found."
                )
            
            # Update user fields. Since UserRepository doesn't have a generic update, 
            # and it uses MongoAdapter, we can directly use the adapter or add a method.
            # For now, let's assume we can update via a new method or use the adapter if accessible.
            # Looking at UserRepository, it has update_role. Let's add update_user to it later if needed.
            # Actually, I'll just use the adapter from company_repo or similar if I can't modify UserRepository easily.
            # Wait, I can modify UserRepository. Let's do that in a separate step if needed.
            
            # For now, I'll just use the MongoAdapter directly if possible or add a method.
            await self.user_repo.update_user(user_id, data)
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to update employer profile | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error while updating employer profile."
            )

    async def get_company_profile(self, user_id: str) -> CompanyProfile:
        log.info("Fetching company profile | user_id=%s", user_id)
        try:
            doc = await self.company_repo.find_one_by_user(user_id)
            if not doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Company profile not found."
                )
            return CompanyProfile.from_dict(doc)
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to fetch company profile | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error while fetching company profile."
            )

    async def update_company_profile(self, user_id: str, company_profile: CompanyProfile) -> None:
        log.info("Updating company profile | user_id=%s", user_id)
        try:
            data = company_profile.model_dump(exclude_none=True, by_alias=True)
            existing = await self.company_repo.find_one_by_user(user_id)
            if existing:
                await self.company_repo.update_one_by_user(user_id, data)
            else:
                await self.company_repo.insert_one(user_id, data)
        except Exception as exc:
            log.exception("Failed to update company profile | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error while updating company profile."
            )
