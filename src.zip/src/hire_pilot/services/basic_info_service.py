from fastapi import HTTPException, status
from hire_pilot.models.basic_info import BasicInfo
from hire_pilot.repositories.basic_info_repository import BasicInfoRepository
from hire_pilot.utils.logger import log

class BasicInfoService:
    def __init__(self):
        self.repo = BasicInfoRepository()
        log.info("BasicInfoService initialized")

    async def get_by_user(self, user_id: str) -> BasicInfo:
        log.info("Fetching basic info | user_id=%s", user_id)
        try:
            doc = await self.repo.find_one_by_user(user_id)
            if not doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Basic info not found."
                )
            return BasicInfo.from_dict(doc)
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to fetch basic info | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error while fetching basic info."
            )

    async def update(self, user_id: str, basic_info: BasicInfo) -> None:
        log.info("Updating basic info | user_id=%s", user_id)
        try:
            data = basic_info.model_dump(exclude_none=True, by_alias=True)
            existing = await self.repo.find_one_by_user(user_id)
            if existing:
                await self.repo.update_one_by_user(user_id, data)
            else:
                await self.repo.insert_one(user_id, data)
        except Exception as exc:
            log.exception("Failed to update basic info | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error while updating basic info."
            )
