import time
from typing import List

from bson.errors import InvalidId
from fastapi import HTTPException, status
from hire_pilot.models.achievement import Achievement
from hire_pilot.models.achievement_input import AchievementInput
from hire_pilot.repositories.achievements_repository import AchievementsRepository
from hire_pilot.utils.logger import log


class AchievementsService:
    def __init__(self):
        self.repo = AchievementsRepository()
        log.info("AchievementsService initialized")

    # ── List all ─────────────────────────────────────────────────────

    async def get_all(self, user_id: str) -> List[Achievement]:
        start = time.monotonic()
        log.info("Fetching all achievements | user_id=%s", user_id)

        try:
            docs = await self.repo.find_all_by_user(user_id)
            achievements = [Achievement(**doc) for doc in docs]
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Fetched achievements | user_id=%s, count=%d, duration_ms=%s",
                user_id, len(achievements), elapsed,
            )
            return achievements

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch achievements | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve achievements.",
            )

    # ── Get one ──────────────────────────────────────────────────────

    async def get_by_id(self, achievement_id: str, user_id: str) -> Achievement:
        start = time.monotonic()
        log.info("Fetching achievement | id=%s, user_id=%s", achievement_id, user_id)

        self._validate_object_id(achievement_id)

        try:
            doc = await self.repo.find_one_by_id(achievement_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid achievement ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch achievement | id=%s, error_type=%s, duration_ms=%s",
                achievement_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve achievement.",
            )

        if doc is None:
            log.warning("Achievement not found | id=%s, user_id=%s", achievement_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Achievement not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Fetched achievement | id=%s, duration_ms=%s", achievement_id, elapsed)
        return Achievement(**doc)

    # ── Create ───────────────────────────────────────────────────────

    async def create(self, user_id: str, achievement_input: AchievementInput) -> str:
        start = time.monotonic()
        log.info("Creating achievement | user_id=%s", user_id)

        self._validate_input(achievement_input)

        try:
            data = achievement_input.to_dict()
            # Convert date to ISO string for MongoDB serialization
            if "time" in data and hasattr(data["time"], "isoformat"):
                data["time"] = data["time"].isoformat()
            inserted_id = await self.repo.insert_one(user_id, data)

            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Achievement created | id=%s, user_id=%s, duration_ms=%s",
                inserted_id, user_id, elapsed,
            )
            return inserted_id

        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to create achievement | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create achievement.",
            )

    # ── Update ───────────────────────────────────────────────────────

    async def update(
        self, achievement_id: str, user_id: str, achievement_input: AchievementInput
    ) -> None:
        start = time.monotonic()
        log.info("Updating achievement | id=%s, user_id=%s", achievement_id, user_id)

        self._validate_object_id(achievement_id)
        self._validate_input(achievement_input)

        try:
            data = achievement_input.to_dict()
            if "time" in data and hasattr(data["time"], "isoformat"):
                data["time"] = data["time"].isoformat()
            modified = await self.repo.update_one(achievement_id, user_id, data)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid achievement ID format.",
            )
        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update achievement | id=%s, error_type=%s, duration_ms=%s",
                achievement_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update achievement.",
            )

        if modified == 0:
            log.warning("Achievement not found for update | id=%s, user_id=%s", achievement_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Achievement not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Achievement updated | id=%s, duration_ms=%s", achievement_id, elapsed)

    # ── Delete ───────────────────────────────────────────────────────

    async def delete(self, achievement_id: str, user_id: str) -> None:
        start = time.monotonic()
        log.info("Deleting achievement | id=%s, user_id=%s", achievement_id, user_id)

        self._validate_object_id(achievement_id)

        try:
            deleted = await self.repo.delete_one(achievement_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid achievement ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to delete achievement | id=%s, error_type=%s, duration_ms=%s",
                achievement_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete achievement.",
            )

        if deleted == 0:
            log.warning("Achievement not found for deletion | id=%s, user_id=%s", achievement_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Achievement not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Achievement deleted | id=%s, duration_ms=%s", achievement_id, elapsed)

    # ── Validation helpers ───────────────────────────────────────────

    @staticmethod
    def _validate_input(inp: AchievementInput) -> None:
        errors: list[str] = []

        if not inp.name or not inp.name.strip():
            errors.append("Achievement name is required.")
        if not inp.org or not inp.org.strip():
            errors.append("Organization is required.")
        if inp.time is None:
            errors.append("Achievement date is required.")

        if errors:
            log.warning("Achievement validation failed | errors=%s", errors)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=errors[0] if len(errors) == 1 else errors,
            )

    @staticmethod
    def _validate_object_id(oid: str) -> None:
        """Fail fast if the ID is clearly not a valid 24-hex ObjectId."""
        if not oid or len(oid) != 24:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid achievement ID format.",
            )
        try:
            int(oid, 16)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid achievement ID format.",
            )
