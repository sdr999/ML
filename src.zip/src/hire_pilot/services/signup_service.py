import re
import time

from hire_pilot.models.sign_up_request import SignUpRequest
from hire_pilot.models.sign_in_request import SignInRequest
from hire_pilot.models.auth_response import AuthResponse
from hire_pilot.repositories.signup_repository import SignupRepository
from hire_pilot.repositories.user_repository import UserRepository
from hire_pilot.repositories.company_repository import CompanyRepository
from hire_pilot.models.employer_register_request import EmployerRegisterRequest
from hire_pilot.utils.logger import log
from fastapi import HTTPException, status
from supabase import AuthApiError


# ── helpers ──────────────────────────────────────────────────────────

_EMAIL_RE = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")


def _mask_email(email: str) -> str:
    """Mask PII for safe logging: 'john@example.com' → 'j***@e***.com'."""
    if not email or "@" not in email:
        return "***"
    local, domain = email.rsplit("@", 1)
    parts = domain.split(".")
    masked_local = local[0] + "***" if local else "***"
    masked_domain = parts[0][0] + "***" if parts[0] else "***"
    return f"{masked_local}@{masked_domain}.{parts[-1]}"


def _supabase_error_detail(exc: AuthApiError) -> str:
    """Extract a safe, user-facing message from a Supabase AuthApiError."""
    msg = str(exc).lower()
    if "already registered" in msg or "duplicate" in msg:
        return "An account with this email already exists."
    if "invalid" in msg and "password" in msg:
        return "Invalid email or password."
    if "email" in msg and "not confirmed" in msg:
        return "Email address has not been confirmed."
    if "rate" in msg or "too many" in msg:
        return "Too many attempts. Please try again later."
    # Fallback — never leak raw Supabase message
    return "Authentication service error. Please try again."


# ── service ──────────────────────────────────────────────────────────


class SignupService:
    def __init__(self):
        self.signup_repo = SignupRepository()
        self.user_repo = UserRepository()
        log.info("SignupService initialized")

    # ── Sign Up ──────────────────────────────────────────────────────

    async def auth_signup_post(self, sign_up_request: SignUpRequest) -> None:
        start_time = time.monotonic()
        masked = _mask_email(sign_up_request.email)
        log.info("Signup request received | email=%s", masked)

        # --- validation ---
        self._validate_signup(sign_up_request)

        try:
            response = await self.signup_repo.sign_up_user(
                sign_up_request.email,
                sign_up_request.password
            )

            if response.user is None:
                log.error("Signup returned null user | email=%s", masked)
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail="Signup could not be completed. Please try again."
                )

            # ── Save user details to MongoDB ────────────────────────────
            user_data = {
                "user_id": response.user.id,
                "first_name": sign_up_request.first_name,
                "middle_name": sign_up_request.middle_name,
                "last_name": sign_up_request.last_name,
                "email": sign_up_request.email,
                "mobile_no": sign_up_request.mobile_no,
                "dob": sign_up_request.dob.isoformat() if sign_up_request.dob else None,
                "role": sign_up_request.role.value if sign_up_request.role else "employee",
            }
            try:
                await self.user_repo.insert_user(user_data)
                log.info("User saved to DB | user_id=%s, role=%s", response.user.id, user_data["role"])
            except Exception as db_exc:
                # Log but don't fail signup — Supabase auth already succeeded
                log.error(
                    "Failed to save user to DB | user_id=%s, error_type=%s, error=%s",
                    response.user.id, type(db_exc).__name__, str(db_exc),
                )

            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.info("Signup successful | email=%s, duration_ms=%s", masked, elapsed)

        except HTTPException:
            raise
        except AuthApiError as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.warning(
                "Signup rejected by auth provider | email=%s, error=%s, duration_ms=%s",
                masked, str(e), elapsed
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=_supabase_error_detail(e)
            )
        except Exception as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.exception(
                "Unexpected error during signup | email=%s, error_type=%s, duration_ms=%s",
                masked, type(e).__name__, elapsed
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )

    async def employer_auth_register_post(self, req: EmployerRegisterRequest) -> None:
        start_time = time.monotonic()
        masked = _mask_email(req.email)
        log.info("Employer signup request received | email=%s", masked)

        # --- validation (basic) ---
        if req.password.get_secret_value() != req.confirm_password.get_secret_value():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Passwords do not match."
            )

        try:
            response = await self.signup_repo.sign_up_user(
                req.email,
                req.password.get_secret_value()
            )

            if response.user is None:
                log.error("Employer signup returned null user | email=%s", masked)
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail="Signup could not be completed. Please try again."
                )

            # ── Save employer details to MongoDB ────────────────────────
            user_data = {
                "user_id": response.user.id,
                "first_name": req.first_name,
                "middle_name": req.middle_name,
                "last_name": req.last_name,
                "email": req.email,
                "mobile_no": req.mobile_no,
                "dob": req.dob.isoformat() if req.dob else None,
                "role": "employer",
                "designation": req.designation,
            }
            try:
                await self.user_repo.insert_user(user_data)
                log.info("Employer saved to DB | user_id=%s", response.user.id)
            except Exception as db_exc:
                log.error("Failed to save employer to DB | user_id=%s, error=%s", response.user.id, str(db_exc))

            # ── Create Company document ─────────────────────────────────
            if req.company_name:
                company_data = {
                    "name": req.company_name,
                    "user_id": response.user.id,
                }
                try:
                    await CompanyRepository().insert_one(response.user.id, company_data)
                    log.info("Company created | name=%s, user_id=%s", req.company_name, response.user.id)
                except Exception as comp_exc:
                    log.error("Failed to create company | user_id=%s, error=%s", response.user.id, str(comp_exc))

            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.info("Employer signup successful | email=%s, duration_ms=%s", masked, elapsed)

        except HTTPException:
            raise
        except AuthApiError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=_supabase_error_detail(e)
            )
        except Exception as e:
            log.exception("Unexpected error during employer signup | email=%s", masked)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )

    # ── Sign In ──────────────────────────────────────────────────────

    async def auth_signin_post(self, sign_in_request: SignInRequest) -> AuthResponse:
        start_time = time.monotonic()
        masked = _mask_email(sign_in_request.username)
        log.info("Signin request received | email=%s", masked)

        # --- validation ---
        self._validate_signin(sign_in_request)

        try:
            response = await self.signup_repo.sign_in_user(
                sign_in_request.username,
                sign_in_request.password.get_secret_value()
            )

            if response.session is None:
                log.warning("Signin returned null session | email=%s", masked)
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid username or password"
                )

            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.info("Signin successful | email=%s, duration_ms=%s", masked, elapsed)

            return AuthResponse(
                access_token=response.session.access_token,
                refresh_token=response.session.refresh_token,
                user_id=response.user.id
            )

        except HTTPException:
            raise
        except AuthApiError as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.warning(
                "Signin rejected by auth provider | email=%s, error=%s, duration_ms=%s",
                masked, str(e), elapsed
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid username or password"
            )
        except Exception as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.exception(
                "Unexpected error during signin | email=%s, error_type=%s, duration_ms=%s",
                masked, type(e).__name__, elapsed
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )

    # ── Validation helpers ───────────────────────────────────────────

    @staticmethod
    def _validate_signup(req: SignUpRequest) -> None:
        errors: list[str] = []

        if not req.email or not req.email.strip():
            errors.append("Email is required.")
        elif not _EMAIL_RE.match(req.email):
            errors.append("Invalid email format.")

        if not req.password or len(req.password) < 8:
            errors.append("Password must be at least 8 characters.")

        if not req.confirm_password:
            errors.append("Password confirmation is required.")
        elif req.password != req.confirm_password:
            errors.append("Password and confirmation do not match.")

        if not req.first_name or not req.first_name.strip():
            errors.append("First name is required.")
        if not req.last_name or not req.last_name.strip():
            errors.append("Last name is required.")
        if not req.mobile_no or not req.mobile_no.strip():
            errors.append("Mobile number is required.")

        if errors:
            log.warning("Signup validation failed | errors=%s", errors)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=errors[0] if len(errors) == 1 else errors
            )

    @staticmethod
    def _validate_signin(req: SignInRequest) -> None:
        errors: list[str] = []

        if not req.username or not req.username.strip():
            errors.append("Username is required.")

        # SecretStr is always truthy — check the actual value
        if not req.password or not req.password.get_secret_value():
            errors.append("Password is required.")

        # if not req.captcha or not req.captcha.strip():
        #     errors.append("Captcha is required.")

        if errors:
            log.warning("Signin validation failed | errors=%s", errors)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=errors[0] if len(errors) == 1 else errors
            )

    # ── Refresh Token ────────────────────────────────────────────────

    async def auth_refresh_post(self, refresh_token: str) -> AuthResponse:
        start_time = time.monotonic()
        log.info("Token refresh request received")

        if not refresh_token or not refresh_token.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Refresh token is required."
            )

        try:
            response = await self.signup_repo.refresh_session(refresh_token)

            if response.session is None:
                log.warning("Token refresh returned null session")
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid or expired refresh token."
                )

            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.info("Token refresh successful | duration_ms=%s", elapsed)

            return AuthResponse(
                access_token=response.session.access_token,
                refresh_token=response.session.refresh_token,
                user_id=response.user.id
            )

        except HTTPException:
            raise
        except AuthApiError as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.warning(
                "Token refresh rejected | error=%s, duration_ms=%s",
                str(e), elapsed
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired refresh token."
            )
        except Exception as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.exception(
                "Unexpected error during token refresh | error_type=%s, duration_ms=%s",
                type(e).__name__, elapsed
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )

    # ── Forgot Password ──────────────────────────────────────────────

    async def auth_forgot_password_post(self, email: str, redirect_to: str | None = None) -> None:
        start_time = time.monotonic()
        masked = _mask_email(email)
        log.info("Forgot password request received | email=%s", masked)

        if not email or not email.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email is required."
            )
        if not _EMAIL_RE.match(email):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid email format."
            )

        try:
            await self.signup_repo.reset_password_for_email(email, redirect_to)
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.info("Password reset email sent | email=%s, duration_ms=%s", masked, elapsed)

        except HTTPException:
            raise
        except AuthApiError as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.warning(
                "Forgot password rejected | email=%s, error=%s, duration_ms=%s",
                masked, str(e), elapsed
            )
            # Don't reveal whether the email exists — always return success
            log.info("Returning success despite error to prevent email enumeration")
        except Exception as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.exception(
                "Unexpected error during forgot password | email=%s, error_type=%s, duration_ms=%s",
                masked, type(e).__name__, elapsed
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )

    # ── Reset Password ───────────────────────────────────────────────

    async def auth_reset_password_post(self, access_token: str, new_password: str) -> None:
        start_time = time.monotonic()
        log.info("Reset password request received")

        if not new_password or len(new_password) < 8:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Password must be at least 8 characters."
            )

        if not access_token or not access_token.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Access token is required."
            )

        try:
            await self.signup_repo.update_user_password(access_token, new_password)
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.info("Password reset successful | duration_ms=%s", elapsed)

        except HTTPException:
            raise
        except AuthApiError as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.warning(
                "Password reset rejected | error=%s, duration_ms=%s",
                str(e), elapsed
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to reset password. The link may have expired."
            )
        except Exception as e:
            elapsed = round((time.monotonic() - start_time) * 1000, 2)
            log.exception(
                "Unexpected error during password reset | error_type=%s, duration_ms=%s",
                type(e).__name__, elapsed
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )