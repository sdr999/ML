import time
from typing import List

from bson.errors import InvalidId
from fastapi import HTTPException, status
from hire_pilot.models.language import Language
from hire_pilot.models.language_input import LanguageInput
from hire_pilot.repositories.languages_repository import LanguagesRepository
from hire_pilot.utils.logger import log


class LanguagesService:
    def __init__(self):
        self.repo = LanguagesRepository()
        log.info("LanguagesService initialized")

    # ── List all ─────────────────────────────────────────────────────

    async def get_all(self, user_id: str) -> List[Language]:
        start = time.monotonic()
        log.info("Fetching all languages | user_id=%s", user_id)

        try:
            docs = await self.repo.find_all_by_user(user_id)
            languages = [Language(**doc) for doc in docs]
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Fetched languages | user_id=%s, count=%d, duration_ms=%s",
                user_id, len(languages), elapsed,
            )
            return languages

        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch languages | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve languages.",
            )

    # ── Get one ──────────────────────────────────────────────────────

    async def get_by_id(self, language_id: str, user_id: str) -> Language:
        start = time.monotonic()
        log.info("Fetching language | id=%s, user_id=%s", language_id, user_id)

        self._validate_object_id(language_id)

        try:
            doc = await self.repo.find_one_by_id(language_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid language ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to fetch language | id=%s, error_type=%s, duration_ms=%s",
                language_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve language.",
            )

        if doc is None:
            log.warning("Language not found | id=%s, user_id=%s", language_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Language not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Fetched language | id=%s, duration_ms=%s", language_id, elapsed)
        return Language(**doc)

    # ── Create ───────────────────────────────────────────────────────

    async def create(self, user_id: str, language_input: LanguageInput) -> str:
        start = time.monotonic()
        log.info("Creating language | user_id=%s", user_id)

        self._validate_input(language_input)

        try:
            data = language_input.to_dict()
            inserted_id = await self.repo.insert_one(user_id, data)

            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.info(
                "Language created | id=%s, user_id=%s, duration_ms=%s",
                inserted_id, user_id, elapsed,
            )
            return inserted_id

        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to create language | user_id=%s, error_type=%s, duration_ms=%s",
                user_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create language.",
            )

    # ── Update ───────────────────────────────────────────────────────

    async def update(
        self, language_id: str, user_id: str, language_input: LanguageInput
    ) -> None:
        start = time.monotonic()
        log.info("Updating language | id=%s, user_id=%s", language_id, user_id)

        self._validate_object_id(language_id)
        self._validate_input(language_input)

        try:
            data = language_input.to_dict()
            modified = await self.repo.update_one(language_id, user_id, data)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid language ID format.",
            )
        except HTTPException:
            raise
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to update language | id=%s, error_type=%s, duration_ms=%s",
                language_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update language.",
            )

        if modified == 0:
            log.warning("Language not found for update | id=%s, user_id=%s", language_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Language not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Language updated | id=%s, duration_ms=%s", language_id, elapsed)

    # ── Delete ───────────────────────────────────────────────────────

    async def delete(self, language_id: str, user_id: str) -> None:
        start = time.monotonic()
        log.info("Deleting language | id=%s, user_id=%s", language_id, user_id)

        self._validate_object_id(language_id)

        try:
            deleted = await self.repo.delete_one(language_id, user_id)
        except InvalidId:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid language ID format.",
            )
        except Exception as exc:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            log.exception(
                "Failed to delete language | id=%s, error_type=%s, duration_ms=%s",
                language_id, type(exc).__name__, elapsed,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete language.",
            )

        if deleted == 0:
            log.warning("Language not found for deletion | id=%s, user_id=%s", language_id, user_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Language not found.",
            )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        log.info("Language deleted | id=%s, duration_ms=%s", language_id, elapsed)

    # ── Validation helpers ───────────────────────────────────────────

    @staticmethod
    def _validate_input(inp: LanguageInput) -> None:
        errors: list[str] = []

        if not inp.name or not inp.name.strip():
            errors.append("Language name is required.")

        if errors:
            log.warning("Language validation failed | errors=%s", errors)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=errors[0] if len(errors) == 1 else errors,
            )

    @staticmethod
    def _validate_object_id(oid: str) -> None:
        if not oid or len(oid) != 24:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid language ID format.",
            )
        try:
            int(oid, 16)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid language ID format.",
            )
