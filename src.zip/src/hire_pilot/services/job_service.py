from typing import Any, List, Optional
from fastapi import HTTPException, status
from hire_pilot.models.job import Job
from hire_pilot.models.job_input import JobInput
from hire_pilot.repositories.job_repository import JobRepository
from hire_pilot.utils.logger import log

from hire_pilot.services.profile_details_service import ProfileDetailsService
from hire_pilot.repositories.company_repository import CompanyRepository

class JobService:
    def __init__(self):
        self.repo = JobRepository()
        self.profile_svc = ProfileDetailsService()
        self.company_repo = CompanyRepository()
        log.info("JobService initialized")

    async def get_recommended_jobs(self, user_id: str, page: int = 1, limit: int = 20) -> List[Job]:
        try:
            # Get candidate profile info
            profile = await self.profile_svc.get_full_profile(user_id)
            
            skills = profile.skills or []
            locations = []
            
            if profile.basic_info and profile.basic_info.address:
                locations.append(profile.basic_info.address)
            
            # Add preferred locations from employment details
            for detail in (profile.employment_details or []):
                if detail.preferred_location:
                    locations.append(detail.preferred_location)

            # Deduplicate locations
            locations = list(set(locations))

            jobs_data = await self.repo.find_recommended(skills, locations, page, limit)
            return [Job.from_dict(j) for j in jobs_data]
            
        except Exception as exc:
            log.exception("Failed to get recommended jobs | user_id=%s, error=%s", user_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve recommended jobs."
            )

    async def list_jobs(self, employer_id: str, page: int = 1, limit: int = 20) -> List[Job]:
        try:
            # Simple list for now
            jobs_data = await self.repo.find_by_employer(employer_id)
            return [Job.from_dict(j) for j in jobs_data]
        except Exception as exc:
            log.exception("Failed to list jobs | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve jobs."
            )

    async def create_job(self, employer_id: str, job_input: JobInput) -> str:
        try:
            data = job_input.model_dump(exclude_none=True)
            
            # Fetch company name
            company = await self.company_repo.find_one_by_user(employer_id)
            if company and company.get("name"):
                data["company_name"] = company["name"]
            
            return await self.repo.insert_job(employer_id, data)
        except Exception as exc:
            log.exception("Failed to create job | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create job."
            )

    async def get_job(self, job_id: str) -> Job:
        try:
            doc = await self.repo.find_by_id(job_id)
            if not doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Job not found."
                )
            return Job.from_dict(doc)
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to get job | id=%s, error=%s", job_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error while fetching job."
            )

    async def update_job(self, job_id: str, job_input: JobInput) -> None:
        try:
            data = job_input.model_dump(exclude_none=True)
            count = await self.repo.update_job(job_id, data)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Job not found or no changes made."
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to update job | id=%s, error=%s", job_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update job."
            )

    async def delete_job(self, job_id: str) -> None:
        try:
            count = await self.repo.delete_job(job_id)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Job not found."
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to delete job | id=%s, error=%s", job_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete job."
            )

    async def update_job_status(self, job_id: str, new_status: str) -> None:
        try:
            count = await self.repo.update_status(job_id, new_status)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Job not found."
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to update job status | id=%s, status=%s, error=%s", job_id, new_status, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to set job status to {new_status}."
            )

    async def duplicate_job(self, job_id: str, employer_id: str) -> str:
        """Clone an existing job as a new DRAFT posting."""
        try:
            doc = await self.repo.find_by_id(job_id)
            if not doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Original job not found.",
                )
            # Strip fields that should not be copied
            for key in ["id", "_id", "created_at", "updated_at", "status"]:
                doc.pop(key, None)
            doc["title"] = f"{doc.get('title', 'Untitled')} (Copy)"
            return await self.repo.insert_job(employer_id, doc)
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to duplicate job | id=%s, error=%s", job_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to duplicate job.",
            )
