from typing import Any, List, Optional, Dict
from datetime import datetime, timezone
import random
from fastapi import HTTPException, status

from hire_pilot.repositories.subscription_billing_repository import SubscriptionBillingRepository
from hire_pilot.utils.logger import log

PLANS = [
    {
        "id": "plan_standard",
        "name": "Standard Plan",
        "price": 0,
        "currency": "USD",
        "billing_cycle": "monthly",
        "features": [
            "Up to 3 Active Job Postings",
            "Basic Candidate Search (Skills & Location)",
            "Email-only Communications",
            "Community Support"
        ]
    },
    {
        "id": "plan_professional",
        "name": "Professional Plan",
        "price": 49,
        "currency": "USD",
        "billing_cycle": "monthly",
        "features": [
            "Infinite Active Job Postings",
            "Advanced Candidate Database filters",
            "Interviews scheduling & feedback slots",
            "Conversations, SMS, and Notification Center",
            "Priority Email/Chat Support"
        ]
    },
    {
        "id": "plan_enterprise",
        "name": "Enterprise Plan",
        "price": 199,
        "currency": "USD",
        "billing_cycle": "monthly",
        "features": [
            "All Professional Features",
            "Multi-member recruiter seats",
            "Unlimited Talent Pools",
            "Dedicated Account Manager",
            "Custom ATS API integration"
        ]
    }
]


class SubscriptionBillingService:
    def __init__(self):
        self.repo = SubscriptionBillingRepository()

    async def list_plans(self) -> List[Dict[str, Any]]:
        return PLANS

    async def get_subscription(self, employer_id: str) -> Dict[str, Any]:
        try:
            sub = await self.repo.find_subscription(employer_id)
            if not sub:
                log.info("No active subscription for employer_id=%s, auto-seeding Standard plan", employer_id)
                sub = await self.repo.upsert_subscription(employer_id, "plan_standard", "active", "monthly")
                
            # Attach details of the plan
            plan_details = next((p for p in PLANS if p["id"] == sub["plan_id"]), PLANS[0])
            sub["plan_details"] = plan_details
            return sub
        except Exception as exc:
            log.exception("Failed to load subscription | employer_id=%s, error=%s", employer_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve active subscription details."
            )

    async def update_subscription(self, employer_id: str, plan_id: str) -> Dict[str, Any]:
        try:
            plan = next((p for p in PLANS if p["id"] == plan_id), None)
            if not plan:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid plan ID specified."
                )
                
            sub = await self.repo.upsert_subscription(employer_id, plan_id, "active", plan["billing_cycle"])
            
            # Create a receipt invoice
            invoice_num = f"INV-HP-{random.randint(100000, 999999)}"
            invoice_data = {
                "invoice_number": invoice_num,
                "amount": plan["price"],
                "currency": plan["currency"],
                "status": "PAID" if plan["price"] > 0 else "FREE",
                "plan_id": plan_id,
                "description": f"Subscription Upgrade to {plan['name']}",
                "issued_at": datetime.now(timezone.utc).isoformat()
            }
            await self.repo.insert_invoice(employer_id, invoice_data)
            
            # Fire standard system notification
            try:
                from hire_pilot.repositories.messaging_notifications_repository import MessagingNotificationsRepository
                msg_repo = MessagingNotificationsRepository()
                await msg_repo.create_notification(
                    user_id=employer_id,
                    title="Subscription Upgraded",
                    message=f"Thank you! Your account has successfully upgraded to the '{plan['name']}'.",
                    notify_type="billing"
                )
            except Exception as e:
                log.warning("Could not auto-trigger subscription notification: %s", str(e))
                
            return {
                "message": "Subscription updated successfully.",
                "subscription": sub
            }
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to update subscription | plan_id=%s, error=%s", plan_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update subscription."
            )

    async def create_checkout_session(self, employer_id: str, plan_id: str) -> Dict[str, Any]:
        try:
            plan = next((p for p in PLANS if p["id"] == plan_id), None)
            if not plan:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid plan ID."
                )
            
            # Return a mock checkout URL for our frontend simulator!
            mock_checkout_url = f"http://localhost:3000/dashboard/billing?checkout_session=hp_sim_{random.randint(1000, 9999)}&plan_id={plan_id}"
            
            return {
                "checkout_url": mock_checkout_url,
                "plan_id": plan_id,
                "message": "Simulated Stripe checkout session created."
            }
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Checkout session creation failed | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Checkout creation failed."
            )

    async def process_webhook(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        try:
            event_type = payload.get("type", "checkout.session.completed")
            data = payload.get("data", {})
            employer_id = data.get("employer_id")
            plan_id = data.get("plan_id")
            
            if not employer_id or not plan_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Missing employer_id or plan_id in webhook payload."
                )
                
            log.info("Processing billing webhook | event=%s, employer=%s, plan=%s", event_type, employer_id, plan_id)
            
            if event_type == "checkout.session.completed":
                await self.update_subscription(employer_id, plan_id)
                
            return {"status": "success", "message": "Webhook processed successfully."}
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Webhook processing failed | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Webhook handler failed."
            )

    async def list_invoices(self, employer_id: str) -> List[Dict[str, Any]]:
        try:
            invs = await self.repo.find_invoices(employer_id)
            if not invs:
                log.info("No invoices found for employer_id=%s, auto-seeding initial invoice", employer_id)
                # Seed an initial $0 Setup invoice
                invoice_data = {
                    "invoice_number": f"INV-HP-{random.randint(100000, 999999)}",
                    "amount": 0,
                    "currency": "USD",
                    "status": "FREE",
                    "plan_id": "plan_standard",
                    "description": "Initial account registration & free tier activation",
                    "issued_at": datetime.now(timezone.utc).isoformat()
                }
                await self.repo.insert_invoice(employer_id, invoice_data)
                invs = await self.repo.find_invoices(employer_id)
                
            return invs
        except Exception as exc:
            log.exception("Failed to retrieve invoices | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve invoice logs."
            )
