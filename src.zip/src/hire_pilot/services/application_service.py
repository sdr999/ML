from typing import Any, Dict, List, Optional
from fastapi import HTTPException, status
from hire_pilot.models.application import Application
from hire_pilot.repositories.application_repository import ApplicationRepository
from hire_pilot.repositories.user_repository import UserRepository
from hire_pilot.repositories.resume_repository import ResumeRepository
from hire_pilot.utils.logger import log


class ApplicationService:
    def __init__(self):
        self.repo = ApplicationRepository()
        self.user_repo = UserRepository()
        self.resume_repo = ResumeRepository()
        log.info("ApplicationService initialized")

    # ── Candidate Actions ───────────────────────────────────

    async def apply_to_job(self, job_id: str, candidate_id: str) -> str:
        """Submit a new application. Returns the new application ID."""
        try:
            # Prevent duplicate applications
            already = await self.repo.exists(job_id, candidate_id)
            if already:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="You have already applied to this job.",
                )
            app_id = await self.repo.insert_one({
                "job_id": job_id,
                "candidate_id": candidate_id,
            })
            return app_id
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to create application | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to submit application.",
            )

    async def list_candidate_applications(self, candidate_id: str) -> List[Application]:
        """List all applications by a specific candidate."""
        try:
            docs = await self.repo.find_by_candidate(candidate_id)
            return [Application.from_dict(d) for d in docs]
        except Exception as exc:
            log.exception("Failed to list candidate applications | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve your applications.",
            )

    # ── Employer Actions ────────────────────────────────────

    async def list_job_applications(self, job_id: str) -> List[Application]:
        try:
            docs = await self.repo.find_by_job(job_id)
            return [Application.from_dict(d) for d in docs]
        except Exception as exc:
            log.exception("Failed to list applications | job_id=%s, error=%s", job_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve applications.",
            )

    async def get_application(self, application_id: str) -> Application:
        try:
            doc = await self.repo.find_by_id(application_id)
            if not doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Application not found.",
                )
            return Application.from_dict(doc)
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to get application | id=%s, error=%s", application_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error while fetching application.",
            )

    async def update_status(self, application_id: str, new_status: str) -> None:
        try:
            count = await self.repo.update_status(application_id, new_status)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Application not found.",
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to update status | id=%s, status=%s, error=%s", application_id, new_status, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update application status.",
            )

    async def move_stage(self, application_id: str, stage: str) -> None:
        """Move an application to a new pipeline stage."""
        try:
            count = await self.repo.update_stage(application_id, stage)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Application not found.",
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to move stage | id=%s, stage=%s, error=%s", application_id, stage, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to move application stage.",
            )

    async def add_application_note(self, application_id: str, note: str) -> None:
        try:
            count = await self.repo.add_note(application_id, note)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Application not found.",
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to add note | id=%s, error=%s", application_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to add note.",
            )

    async def update_application_rating(self, application_id: str, rating: int) -> None:
        try:
            if not 1 <= rating <= 5:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Rating must be between 1 and 5.",
                )
            count = await self.repo.update_rating(application_id, rating)
            if count == 0:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Application not found.",
                )
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to update rating | id=%s, error=%s", application_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update rating.",
            )

    # ── KPI / Analytics ─────────────────────────────────────

    async def get_dashboard_kpis(self, employer_id: Optional[str] = None) -> Dict[str, Any]:
        """Return hiring pipeline KPIs for the employer dashboard — all fields at top level."""
        try:
            stats = await self.repo.get_pipeline_stats(employer_id)

            total      = stats.get("total_applications", 0)
            shortlisted= stats.get("shortlisted", 0)
            interviews = stats.get("interview_scheduled", 0)
            hired      = stats.get("hired", 0)
            rejected   = stats.get("rejected", 0)

            # Count active (PUBLISHED) jobs for this employer
            total_jobs = 0
            try:
                from hire_pilot.repositories.job_repository import JobRepository
                job_repo = JobRepository()
                jobs = await job_repo.find_by_employer(employer_id)
                total_jobs = sum(1 for j in jobs if j.get("status") == "PUBLISHED")
            except Exception as je:
                log.warning("Could not count active jobs for KPI | %s", je)

            return {
                # ── Flat top-level fields (consumed directly by frontend) ──
                "total_jobs":            total_jobs,
                "total_applications":    total,
                "shortlisted":           shortlisted,
                "interviews_scheduled":  interviews,
                "hired":                 hired,
                "rejected":              rejected,
                # ── Convenience nested copy (backward compat) ──
                "hiring_funnel": {
                    "applied":              stats.get("applied", 0),
                    "screening":            stats.get("screening", 0),
                    "shortlisted":          shortlisted,
                    "interview_scheduled":  interviews,
                    "offered":              stats.get("offered", 0),
                    "hired":                hired,
                    "rejected":             rejected,
                },
                "conversion_rate": round((hired / total * 100), 1) if total > 0 else 0,
                "rejection_rate":  round((rejected / total * 100), 1) if total > 0 else 0,
                "status_breakdown": stats.get("status_breakdown", {}),
            }
        except Exception as exc:
            log.exception("Failed to get dashboard KPIs | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve dashboard KPIs.",
            )

    async def get_job_kpis(self, job_id: str) -> Dict[str, Any]:
        """Return KPIs for a specific job posting."""
        try:
            status_counts = await self.repo.count_by_status(job_id)
            total = sum(status_counts.values())

            return {
                "job_id": job_id,
                "total_applications": total,
                "status_breakdown": status_counts,
                "shortlisted": status_counts.get("SHORTLISTED", 0),
                "interview_scheduled": status_counts.get("INTERVIEW_SCHEDULED", 0),
                "hired": status_counts.get("HIRED", 0),
                "rejected": status_counts.get("REJECTED", 0),
            }
        except Exception as exc:
            log.exception("Failed to get job KPIs | job_id=%s, error=%s", job_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve job KPIs.",
            )

    # ── Enriched Listing (with candidate profile) ───────────

    async def list_job_applications_enriched(self, job_id: str) -> List[Dict[str, Any]]:
        """List applications for a job with candidate profile + resume info."""
        try:
            docs = await self.repo.find_by_job(job_id)
            enriched = []
            for d in docs:
                candidate_id = d.get("candidate_id", "")
                
                # Fetch user profile (name, email)
                user = await self.user_repo.find_by_user_id(candidate_id) if candidate_id else None
                
                # Fetch resume availability
                resume_doc = await self.resume_repo.find_one_by_user(candidate_id) if candidate_id else None
                
                entry = {
                    "id": d.get("id"),
                    "job_id": d.get("job_id"),
                    "candidate_id": candidate_id,
                    "status": d.get("status", "APPLIED"),
                    "applied_at": d.get("applied_at"),
                    "rating": d.get("rating"),
                    "notes": d.get("notes", []),
                    "stage": d.get("stage"),
                    # Enriched candidate info
                    "candidate_name": f"{user.get('first_name', '')} {user.get('last_name', '')}".strip() if user else "Unknown",
                    "candidate_email": user.get("email", "") if user else "",
                    "candidate_skills": user.get("skills", []) if user else [],
                    "candidate_location": user.get("current_location", "") if user else "",
                    "candidate_designation": user.get("designation", "") if user else "",
                    "has_resume": resume_doc is not None,
                    "resume_filename": resume_doc.get("filename", "") if resume_doc else "",
                }
                enriched.append(entry)
            return enriched
        except Exception as exc:
            log.exception("Failed to list enriched applications | job_id=%s, error=%s", job_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve applications.",
            )

    # ── Resume Retrieval ────────────────────────────────────

    async def get_candidate_resume(self, application_id: str) -> Dict[str, Any]:
        """Fetch the resume file for a candidate linked to an application."""
        try:
            doc = await self.repo.find_by_id(application_id)
            if not doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Application not found.",
                )
            candidate_id = doc.get("candidate_id", "")
            resume = await self.resume_repo.find_one_by_user(candidate_id)
            if not resume:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="No resume found for this candidate.",
                )
            return {
                "filename": resume.get("filename", "resume.pdf"),
                "content_type": resume.get("content_type", "application/pdf"),
                "file_data": resume.get("file_data", ""),
            }
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to get resume | app_id=%s, error=%s", application_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve resume.",
            )

    # ── New: Withdraw, Bulk Update, Timeline ────────────────

    async def withdraw_application(self, application_id: str, candidate_id: str) -> None:
        """Allow a candidate to withdraw their own application."""
        try:
            doc = await self.repo.find_by_id(application_id)
            if not doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Application not found.",
                )
            if doc.get("candidate_id") != candidate_id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You can only withdraw your own applications.",
                )
            if doc.get("status") in ("WITHDRAWN", "REJECTED", "HIRED"):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Cannot withdraw an application with status '{doc.get('status')}'.",
                )
            await self.repo.update_status(application_id, "WITHDRAWN")
            log.info("Application withdrawn | app_id=%s, candidate=%s", application_id, candidate_id)
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to withdraw application | app_id=%s, error=%s", application_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to withdraw application.",
            )

    async def bulk_update_status(self, application_ids: List[str], new_status: str) -> Dict[str, Any]:
        """Update the status of multiple applications at once."""
        try:
            if not application_ids:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="No application IDs provided.",
                )
            if len(application_ids) > 100:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Maximum 100 applications per bulk operation.",
                )
            success_count = 0
            failed_ids = []
            for app_id in application_ids:
                try:
                    count = await self.repo.update_status(app_id, new_status)
                    if count > 0:
                        success_count += 1
                    else:
                        failed_ids.append(app_id)
                except Exception:
                    failed_ids.append(app_id)

            log.info(
                "Bulk status update | total=%d, success=%d, failed=%d, new_status=%s",
                len(application_ids), success_count, len(failed_ids), new_status,
            )
            return {
                "total": len(application_ids),
                "success_count": success_count,
                "failed_count": len(failed_ids),
                "failed_ids": failed_ids,
            }
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Bulk update failed | error=%s", str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to perform bulk status update.",
            )

    async def get_application_timeline(self, application_id: str) -> List[Dict[str, Any]]:
        """Get the status change history / timeline of an application."""
        try:
            doc = await self.repo.find_by_id(application_id)
            if not doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Application not found.",
                )
            # status_history is stored as an array of {status, timestamp} dicts
            history = doc.get("status_history", [])
            # If no history tracked yet, synthesize from current data
            if not history:
                timeline = []
                if doc.get("applied_at"):
                    timeline.append({
                        "status": "APPLIED",
                        "timestamp": doc["applied_at"],
                        "label": "Application submitted",
                    })
                if doc.get("status") and doc.get("status") != "APPLIED":
                    timeline.append({
                        "status": doc["status"],
                        "timestamp": doc.get("updated_at", doc.get("applied_at", "")),
                        "label": f"Status changed to {doc['status']}",
                    })
                return timeline
            return history
        except HTTPException:
            raise
        except Exception as exc:
            log.exception("Failed to get timeline | app_id=%s, error=%s", application_id, str(exc))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve application timeline.",
            )
