from typing import List
from hire_pilot.models.verification_request import VerificationType, VerificationSubmitRequest
from hire_pilot.models.verification_status import VerificationStatus, VerificationStatusEnum
from hire_pilot.repositories.verification_repository import VerificationRepository


class VerificationService:
    def __init__(self):
        self.repo = VerificationRepository()

    async def _submit(
        self,
        employer_id: str,
        verification_type: VerificationType,
        body: VerificationSubmitRequest,
    ) -> VerificationStatus:
        await self.repo.upsert_verification(
            employer_id=employer_id,
            verification_type=verification_type.value,
            document_url=body.document_url,
            document_number=body.document_number,
            notes=body.notes,
        )
        doc = await self.repo.find_by_employer_and_type(employer_id, verification_type.value)
        return _doc_to_status(doc)

    async def submit_pan(self, employer_id: str, body: VerificationSubmitRequest) -> VerificationStatus:
        return await self._submit(employer_id, VerificationType.PAN, body)

    async def submit_gst(self, employer_id: str, body: VerificationSubmitRequest) -> VerificationStatus:
        return await self._submit(employer_id, VerificationType.GST, body)

    async def submit_company_docs(self, employer_id: str, body: VerificationSubmitRequest) -> VerificationStatus:
        return await self._submit(employer_id, VerificationType.COMPANY_DOCS, body)

    async def get_verification_status(self, employer_id: str) -> List[VerificationStatus]:
        docs = await self.repo.find_all_for_employer(employer_id)
        existing = {d["type"]: d for d in docs}
        result = []
        for vtype in VerificationType:
            if vtype.value in existing:
                result.append(_doc_to_status(existing[vtype.value]))
            else:
                result.append(
                    VerificationStatus(
                        employer_id=employer_id,
                        type=vtype,
                        status=VerificationStatusEnum.NOT_SUBMITTED,
                    )
                )
        return result


def _doc_to_status(doc: dict) -> VerificationStatus:
    return VerificationStatus(
        id=doc.get("id"),
        employer_id=doc["employer_id"],
        type=doc["type"],
        document_number=doc.get("document_number"),
        document_url=doc.get("document_url"),
        status=doc.get("status", "PENDING"),
        submitted_at=doc.get("submitted_at"),
        reviewed_at=doc.get("reviewed_at"),
        reviewer_notes=doc.get("reviewer_notes"),
    )
