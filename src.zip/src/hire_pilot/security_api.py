# coding: utf-8
"""
security_api.py — JWT verification + RBAC for HirePilot.

PERFORMANCE STRATEGY
--------------------
Two-tier token verification:

  Tier 1 — Local HS256 decode (sub-millisecond, no network)
    If SUPABASE_JWT_SECRET is configured and the token is valid HS256,
    we verify in-process. Zero network overhead.

  Tier 2 — Supabase HTTP fallback (~200-300 ms, 1 network call)
    If local decode fails (wrong secret, RS256, expired, etc.) we fall
    back to supabase.auth.get_user(token). This is the original behaviour
    and is always correct.

  LRU cache (1000 entries, 5-min TTL)
    On *any* successful verification the sub is cached keyed by token.
    Every subsequent request with that token is served from the cache in
    < 1 µs — regardless of which tier originally verified it.

Net result: first request per session ≤ Supabase latency (same as before),
every subsequent request for 5 minutes is essentially free.
"""

import asyncio
import contextvars
import os
import time
import threading
from collections import OrderedDict
from typing import Optional

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

import jwt
from jwt.exceptions import DecodeError, ExpiredSignatureError, InvalidTokenError
from dotenv import dotenv_values, load_dotenv

from hire_pilot.models.extra_models import TokenModel
from hire_pilot.utils.logger import log

# ── Configuration ─────────────────────────────────────────────────────────────

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

SUPABASE_JWT_SECRET: str = env.get("SUPABASE_JWT_SECRET", "")
SUPABASE_URL: str = env.get("SUPABASE_URL", "")
SUPABASE_KEY: str = env.get("SUPABASE_KEY", "")
_ALGORITHMS = ["HS256"]

if not SUPABASE_JWT_SECRET:
    log.warning("SUPABASE_JWT_SECRET not set — local JWT decode disabled, using Supabase HTTP only.")

# ── Supabase client (fallback) ────────────────────────────────────────────────

from supabase import create_client, Client, AuthApiError  # noqa: E402

supabase_client: Optional[Client] = None
if SUPABASE_URL and SUPABASE_KEY:
    supabase_client = create_client(SUPABASE_URL, SUPABASE_KEY)
    log.info("Supabase fallback client initialised.")
else:
    log.warning("Supabase credentials missing — HTTP fallback will be unavailable.")

# ── Token LRU cache ────────────────────────────────────────────────────────────
# {token: (sub, expiry_monotonic)}
# Thread-safe; shared within a single process (one entry per uvicorn worker).

_CACHE_TTL   = 300        # seconds (5 min)
_CACHE_MAX   = 1_000      # max cached tokens per process
_cache: OrderedDict[str, tuple] = OrderedDict()
_cache_lock = threading.Lock()


def _cache_get(token: str) -> Optional[str]:
    with _cache_lock:
        entry = _cache.get(token)
        if not entry:
            return None
        sub, expiry = entry
        if time.monotonic() > expiry:
            del _cache[token]
            return None
        _cache.move_to_end(token)
        return sub


def _cache_set(token: str, sub: str) -> None:
    with _cache_lock:
        _cache[token] = (sub, time.monotonic() + _CACHE_TTL)
        _cache.move_to_end(token)
        while len(_cache) > _CACHE_MAX:
            _cache.popitem(last=False)


# ── Security scheme ────────────────────────────────────────────────────────────

bearer_auth = HTTPBearer(
    scheme_name="bearerAuth",
    description="Supabase JWT — verified locally when possible, cached for 5 min.",
)

# ── Request-scoped user context ────────────────────────────────────────────────

current_user_var: contextvars.ContextVar[str] = contextvars.ContextVar(
    "current_user", default=""
)


def get_current_user_id() -> str:
    user_id = current_user_var.get()
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user_id


# ── Tier-1: local JWT decode ───────────────────────────────────────────────────

def _try_local_verify(token: str) -> Optional[str]:
    """
    Attempt local HS256 decode. Returns sub on success, None if the secret
    is wrong / algorithm mismatch / token is structurally invalid.
    Raises HTTPException 401 only for *expired* tokens (no need to hit network).
    """
    if not SUPABASE_JWT_SECRET:
        return None
    try:
        payload = jwt.decode(
            token,
            SUPABASE_JWT_SECRET,
            algorithms=_ALGORITHMS,
            options={"verify_aud": False},
        )
        sub: str = payload.get("sub", "")
        return sub if sub else None
    except ExpiredSignatureError:
        log.debug("Local verify: token expired")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired. Please sign in again.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except (DecodeError, InvalidTokenError) as exc:
        # Wrong secret or RS256 — fall through to Supabase HTTP
        log.debug("Local verify failed (%s) — using Supabase HTTP fallback.", type(exc).__name__)
        return None


# ── Tier-2: Supabase HTTP fallback ────────────────────────────────────────────

async def _supabase_verify(token: str) -> str:
    """
    Verify token via Supabase Auth API. Always correct; ~200-300 ms network cost.
    Runs in a thread to avoid blocking the async event loop.
    """
    if not supabase_client:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Authentication service is misconfigured.",
        )
    try:
        user_response = await asyncio.to_thread(supabase_client.auth.get_user, token)
        if not user_response or not user_response.user:
            raise ValueError("No user returned from Supabase")
        return user_response.user.id
    except AuthApiError as exc:
        log.warning("Supabase rejected JWT | reason=%s", exc)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except HTTPException:
        raise
    except Exception as exc:
        log.warning("Supabase verify error | type=%s, msg=%s", type(exc).__name__, exc)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token.",
            headers={"WWW-Authenticate": "Bearer"},
        )


# ── Main dependency ────────────────────────────────────────────────────────────

async def get_token_bearerAuth(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_auth),
) -> TokenModel:
    """
    FastAPI dependency: verify Bearer JWT and set request-scoped user context.

    Flow:
      1. Cache hit        →  < 1 µs, no compute
      2. Local HS256      →  < 1 ms, no network
      3. Supabase HTTP    →  ~200-300 ms (first request per session only)
      4. Cache the result
    """
    token = credentials.credentials

    # ── 1. Cache ────────────────────────────────────────────────────────────
    cached_sub = _cache_get(token)
    if cached_sub:
        current_user_var.set(cached_sub)
        return TokenModel(sub=cached_sub)

    # ── 2. Local decode (fast, no network) ──────────────────────────────────
    sub = _try_local_verify(token)

    # ── 3. Supabase HTTP fallback ────────────────────────────────────────────
    if sub is None:
        sub = await _supabase_verify(token)
        log.debug("JWT verified via Supabase HTTP | sub=%s", sub)
    else:
        log.debug("JWT verified locally | sub=%s", sub)

    # ── 4. Cache + context ───────────────────────────────────────────────────
    _cache_set(token, sub)
    current_user_var.set(sub)
    return TokenModel(sub=sub)


# ── Role-Based Access Control ──────────────────────────────────────────────────

from hire_pilot.repositories.user_repository import UserRepository  # noqa: E402

_user_repo: Optional[UserRepository] = None


def _get_user_repo() -> UserRepository:
    global _user_repo
    if _user_repo is None:
        _user_repo = UserRepository()
    return _user_repo


class RoleChecker:
    """
    FastAPI dependency that enforces role-based access control.

    Example::

        @router.get(\"/admin/dashboard\")
        async def admin_dashboard(
            token: TokenModel = Security(get_token_bearerAuth),
            _: bool = Depends(RoleChecker([\"admin\"])),
        ):
            ...
    """

    def __init__(self, allowed_roles: list[str]):
        self.allowed_roles = allowed_roles

    async def __call__(self) -> bool:
        user_id = get_current_user_id()
        repo = _get_user_repo()
        role = await repo.get_user_role(user_id)

        if role is None:
            log.warning("Role check failed — user not found | user_id=%s", user_id)
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied. User record not found.",
            )

        if role not in self.allowed_roles:
            log.warning(
                "Role check failed | user_id=%s, role=%s, allowed=%s",
                user_id, role, self.allowed_roles,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to access this resource.",
            )

        log.debug("Role check passed | user_id=%s, role=%s", user_id, role)
        return True
