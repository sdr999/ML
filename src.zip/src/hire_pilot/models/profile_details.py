from pydantic import BaseModel
from typing import List, Optional

from hire_pilot.models.achievement import Achievement
from hire_pilot.models.basic_info import BasicInfo
from hire_pilot.models.certification import Certification
from hire_pilot.models.diversity import Diversity
from hire_pilot.models.education import Education
from hire_pilot.models.employment_detail import EmploymentDetail
from hire_pilot.models.language import Language
from hire_pilot.models.personal_project import PersonalProject
from hire_pilot.models.work_experience import WorkExperience

class ProfileDetails(BaseModel):
    basic_info: Optional[BasicInfo] = None
    achievements: List[Achievement] = []
    certifications: List[Certification] = []
    diversity: Optional[Diversity] = None
    education: List[Education] = []
    employment_details: List[EmploymentDetail] = []
    languages: List[Language] = []
    personal_projects: List[PersonalProject] = []
    skills: List[str] = []
    summary: Optional[str] = None
    work_experience: List[WorkExperience] = []
    role: Optional[str] = None
