from __future__ import annotations
from typing import Optional
from datetime import datetime
from enum import Enum
from pydantic import BaseModel


class ModerationStatus(str, Enum):
    OPEN = "OPEN"
    UNDER_REVIEW = "UNDER_REVIEW"
    RESOLVED = "RESOLVED"
    DISMISSED = "DISMISSED"


class ReportCandidateRequest(BaseModel):
    reported_candidate_id: str
    reason: str
    description: Optional[str] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}


class ModerationReport(BaseModel):
    id: Optional[str] = None
    reporter_id: str
    reported_candidate_id: str
    reason: str
    description: Optional[str] = None
    status: ModerationStatus = ModerationStatus.OPEN
    created_at: Optional[datetime] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
