from __future__ import annotations
from typing import Any, Dict, Optional
from pydantic import BaseModel


class AnalyticsEventInput(BaseModel):
    event_type: str  # JOB_VIEW | JOB_CLICK | JOB_APPLY_START
    job_id: str
    employer_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
