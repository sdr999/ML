from __future__ import annotations
from typing import Optional
from datetime import datetime
from enum import Enum
from pydantic import BaseModel
from hire_pilot.models.verification_request import VerificationType


class VerificationStatusEnum(str, Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    NOT_SUBMITTED = "NOT_SUBMITTED"


class VerificationStatus(BaseModel):
    id: Optional[str] = None
    employer_id: str
    type: VerificationType
    document_number: Optional[str] = None
    document_url: Optional[str] = None
    status: VerificationStatusEnum = VerificationStatusEnum.NOT_SUBMITTED
    submitted_at: Optional[datetime] = None
    reviewed_at: Optional[datetime] = None
    reviewer_notes: Optional[str] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
