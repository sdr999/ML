from __future__ import annotations
from typing import Optional
from datetime import datetime
from enum import Enum
from pydantic import BaseModel


class InterviewResponseStatus(str, Enum):
    CONFIRMED = "CONFIRMED"
    DECLINED = "DECLINED"


class InterviewResponseInput(BaseModel):
    status: InterviewResponseStatus
    notes: Optional[str] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}


class InterviewResponse(BaseModel):
    interview_id: str
    candidate_id: str
    status: InterviewResponseStatus
    notes: Optional[str] = None
    responded_at: datetime

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
