from __future__ import annotations
from typing import Dict, Optional
from pydantic import BaseModel


class DashboardMetrics(BaseModel):
    total_applications: int
    total_views: int
    ctr: float
    hiring_funnel: Dict[str, int]
    time_to_hire: Optional[float] = None
    cost_per_hire: Optional[float] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
