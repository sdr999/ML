from __future__ import annotations
from typing import Optional
from pydantic import BaseModel


class JobReport(BaseModel):
    job_id: str
    title: str
    views: int
    applications: int
    shortlisted: int
    hired: int
    avg_time_to_fill: Optional[float] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
