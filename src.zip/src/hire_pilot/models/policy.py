from __future__ import annotations
from typing import Optional
from datetime import date
from pydantic import BaseModel


class Policy(BaseModel):
    id: str
    title: str
    content: str
    category: str
    effective_date: Optional[date] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
