from __future__ import annotations
from typing import Optional
from datetime import date, datetime
from enum import Enum
from pydantic import BaseModel


class OfferStatus(str, Enum):
    PENDING = "PENDING"
    ACCEPTED = "ACCEPTED"
    DECLINED = "DECLINED"
    EXPIRED = "EXPIRED"
    WITHDRAWN = "WITHDRAWN"


class OfferInput(BaseModel):
    salary_min: Optional[float] = None
    salary_max: Optional[float] = None
    currency: Optional[str] = "INR"
    start_date: Optional[date] = None
    expiry_date: Optional[date] = None
    notes: Optional[str] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}


class OfferResponseInput(BaseModel):
    status: OfferStatus  # ACCEPTED or DECLINED
    notes: Optional[str] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}


class Offer(BaseModel):
    id: Optional[str] = None
    application_id: str
    employer_id: str
    candidate_id: str
    salary_min: Optional[float] = None
    salary_max: Optional[float] = None
    currency: str = "INR"
    start_date: Optional[date] = None
    expiry_date: Optional[date] = None
    notes: Optional[str] = None
    status: OfferStatus = OfferStatus.PENDING
    created_at: Optional[datetime] = None
    responded_at: Optional[datetime] = None
    candidate_notes: Optional[str] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
