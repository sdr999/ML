from __future__ import annotations
from typing import Optional
from enum import Enum
from pydantic import BaseModel


class VerificationType(str, Enum):
    PAN = "PAN"
    GST = "GST"
    COMPANY_DOCS = "COMPANY_DOCS"


class VerificationSubmitRequest(BaseModel):
    document_number: Optional[str] = None
    document_url: str
    notes: Optional[str] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
