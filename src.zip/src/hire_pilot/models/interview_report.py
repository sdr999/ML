from __future__ import annotations
from typing import Optional
from pydantic import BaseModel


class InterviewReport(BaseModel):
    total_interviews: int
    completed: int
    pass_rate: float
    avg_feedback_score: Optional[float] = None

    model_config = {"populate_by_name": True, "validate_assignment": True, "protected_namespaces": ()}
