from hire_pilot.apis.offer_management_api_base import BaseOfferManagementApi
from hire_pilot.models.offer import Offer, OfferInput, OfferResponseInput
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.offer_service import OfferService


class OfferManagementImpl(BaseOfferManagementApi):
    def __init__(self):
        self.service = OfferService()

    async def employer_applications_offer_post(
        self, application_id: str, body: OfferInput
    ) -> Offer:
        employer_id = get_current_user_id()
        return await self.service.make_offer(employer_id, application_id, body)

    async def candidate_applications_offer_respond_patch(
        self, application_id: str, body: OfferResponseInput
    ) -> Offer:
        candidate_id = get_current_user_id()
        return await self.service.respond_to_offer(candidate_id, application_id, body)
