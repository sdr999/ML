from typing import Any, List, Optional
from uuid import UUID
from hire_pilot.apis.job_management_api_base import BaseJobManagementApi
from hire_pilot.models.job import Job
from hire_pilot.models.job_input import JobInput
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.job_service import JobService


class JobManagementImpl(BaseJobManagementApi):
    def __init__(self):
        self.service = JobService()

    async def employer_jobs_recommendations_get(
        self,
        page: Optional[int],
        limit: Optional[int],
    ) -> List[Job]:
        user_id = get_current_user_id()
        return await self.service.get_recommended_jobs(user_id, page or 1, limit or 20)

    async def employer_jobs_get(
        self,
        page: Optional[int],
        limit: Optional[int],
    ) -> List[Job]:
        user_id = get_current_user_id()
        return await self.service.list_jobs(user_id, page or 1, limit or 20)

    async def employer_jobs_post(
        self,
        job_input: JobInput,
    ) -> Any:
        user_id = get_current_user_id()
        job_id = await self.service.create_job(user_id, job_input)
        return {"id": job_id, "message": "Job created successfully"}

    async def employer_jobs_job_id_get(
        self,
        jobId: str,
    ) -> Job:
        return await self.service.get_job(jobId)

    async def employer_jobs_job_id_put(
        self,
        jobId: str,
        job_input: JobInput,
    ) -> Any:
        await self.service.update_job(jobId, job_input)
        return {"message": "Job updated successfully"}

    async def employer_jobs_job_id_delete(
        self,
        jobId: str,
    ) -> Any:
        await self.service.delete_job(jobId)
        return {"message": "Job deleted successfully"}

    async def employer_jobs_job_id_publish_patch(
        self,
        jobId: str,
    ) -> Any:
        await self.service.update_job_status(jobId, "PUBLISHED")
        return {"message": "Job published"}

    async def employer_jobs_job_id_pause_patch(
        self,
        jobId: str,
    ) -> Any:
        await self.service.update_job_status(jobId, "PAUSED")
        return {"message": "Job paused"}

    async def employer_jobs_job_id_close_patch(
        self,
        jobId: str,
    ) -> Any:
        await self.service.update_job_status(jobId, "CLOSED")
        return {"message": "Job closed"}

    async def employer_jobs_job_id_archive_patch(
        self,
        jobId: str,
    ) -> Any:
        await self.service.update_job_status(jobId, "ARCHIVED")
        return {"message": "Job archived"}

    async def employer_jobs_job_id_duplicate_post(
        self,
        jobId: str,
    ) -> Any:
        # Simple duplication: get and re-insert
        job = await self.service.get_job(jobId)
        user_id = get_current_user_id()
        # Create JobInput from job data
        new_job_data = job.model_dump(exclude={"id", "created_at"})
        new_id = await self.service.create_job(user_id, JobInput(**new_job_data))
        return {"id": new_id, "message": "Job duplicated"}

    # Templates and other advanced features can be placeholders for now
    async def employer_job_templates_get(self) -> List[Any]:
        return []

    async def employer_job_templates_post(self) -> Any:
        return {"message": "Template created"}
