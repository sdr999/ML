from typing import List, Any, Optional

from pydantic import StrictStr
from typing_extensions import Annotated
from pydantic import Field

from hire_pilot.apis.employment_details_api_base import BaseEmploymentDetailsApi
from hire_pilot.models.employment_detail import EmploymentDetail
from hire_pilot.models.employment_detail_input import EmploymentDetailInput
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.employment_details_service import EmploymentDetailsService


class EmploymentDetailsImpl(BaseEmploymentDetailsApi):
    def __init__(self):
        self.service = EmploymentDetailsService()

    async def profile_employment_details_get(
        self,
        page: Annotated[Optional[Annotated[int, Field(ge=1)]], Field(description="Page number for pagination")],
        limit: Annotated[Optional[Annotated[int, Field(le=100, ge=1)]], Field(description="Number of items to return per page")],
    ) -> List[EmploymentDetail]:
        user_id = get_current_user_id()
        # Fallback to default 1, 20 if passed None
        page = page or 1
        limit = limit or 20
        return await self.service.get_all(user_id, page, limit)

    async def profile_employment_details_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> EmploymentDetail:
        user_id = get_current_user_id()
        return await self.service.get_by_id(id, user_id)

    async def profile_employment_details_post(
        self,
        employment_detail_input: EmploymentDetailInput,
    ) -> Any:
        user_id = get_current_user_id()
        return await self.service.create(user_id, employment_detail_input)

    async def profile_employment_details_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        employment_detail_input: EmploymentDetailInput,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(id, user_id, employment_detail_input)
        return {"message": "Employment detail updated successfully"}

    async def profile_employment_details_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.delete(id, user_id)
        return {"message": "Employment detail deleted successfully"}
