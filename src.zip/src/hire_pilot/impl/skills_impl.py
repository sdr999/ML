from typing import List, Any

from pydantic import StrictStr

from hire_pilot.apis.skills_api_base import BaseSkillsApi
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.skills_service import SkillsService


class SkillsImpl(BaseSkillsApi):
    def __init__(self):
        self.service = SkillsService()

    async def profile_skills_get(self) -> List[str]:
        user_id = get_current_user_id()
        return await self.service.get_by_user(user_id)

    async def profile_skills_put(
        self,
        request_body: List[StrictStr],
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(user_id, request_body)
        return {"message": "Skills updated successfully"}
