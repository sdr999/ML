from typing import Any, List
from uuid import UUID
from hire_pilot.apis.team_management_api_base import BaseTeamManagementApi
from hire_pilot.models.team_member import TeamMember
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.team_service import TeamService


class TeamManagementImpl(BaseTeamManagementApi):
    def __init__(self):
        self.service = TeamService()

    async def employer_team_get(self) -> List[TeamMember]:
        user_id = get_current_user_id()
        return await self.service.list_team(user_id)

    async def employer_team_invite_post(self, invite_data: Any = None) -> Any:
        user_id = get_current_user_id()
        # Expecting data in body, but base class doesn't define it.
        # Assuming invite_data contains name, email, role for now or use placeholders.
        # For simplicity, using placeholders if not provided.
        email = getattr(invite_data, "email", "new_member@example.com")
        name = getattr(invite_data, "name", "New Member")
        role = getattr(invite_data, "role", "RECRUITER")
        
        member_id = await self.service.invite_member(user_id, email, name, role)
        return {"id": member_id, "message": "Invitation sent"}

    async def employer_team_member_id_role_put(
        self,
        memberId: UUID,
        role_data: Any = None
    ) -> Any:
        # Assuming role_data contains the new role
        new_role = getattr(role_data, "role", "RECRUITER")
        await self.service.update_member_role(str(memberId), new_role)
        return {"message": "Role updated"}

    async def employer_team_member_id_delete(
        self,
        memberId: UUID,
    ) -> Any:
        await self.service.remove_member(str(memberId))
        return {"message": "Member removed"}
