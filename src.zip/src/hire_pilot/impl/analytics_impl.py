from typing import Any, Dict, List
from hire_pilot.apis.analytics_api_base import BaseAnalyticsApi
from hire_pilot.models.dashboard_metrics import DashboardMetrics
from hire_pilot.models.interview_report import InterviewReport
from hire_pilot.models.job_report import JobReport
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.analytics_service import AnalyticsService


class AnalyticsImpl(BaseAnalyticsApi):
    def __init__(self):
        self.service = AnalyticsService()

    async def employer_dashboard_get(self) -> DashboardMetrics:
        employer_id = get_current_user_id()
        return await self.service.get_dashboard(employer_id)

    async def employer_reports_jobs_get(self) -> List[JobReport]:
        employer_id = get_current_user_id()
        return await self.service.get_job_reports(employer_id)

    async def employer_reports_candidates_get(self) -> Dict[str, Any]:
        employer_id = get_current_user_id()
        return await self.service.get_candidate_report(employer_id)

    async def employer_reports_interviews_get(self) -> InterviewReport:
        employer_id = get_current_user_id()
        return await self.service.get_interview_report(employer_id)
