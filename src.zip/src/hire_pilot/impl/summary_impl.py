from typing import Any

from hire_pilot.apis.summary_api_base import BaseSummaryApi
from hire_pilot.models.profile_summary_get200_response import ProfileSummaryGet200Response
from hire_pilot.models.profile_summary_put_request import ProfileSummaryPutRequest
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.summary_service import SummaryService


class SummaryImpl(BaseSummaryApi):
    def __init__(self):
        self.service = SummaryService()

    async def profile_summary_get(self) -> ProfileSummaryGet200Response:
        user_id = get_current_user_id()
        return await self.service.get_by_user(user_id)

    async def profile_summary_put(
        self,
        profile_summary_put_request: ProfileSummaryPutRequest,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(user_id, profile_summary_put_request)
        return {"message": "Summary updated successfully"}
