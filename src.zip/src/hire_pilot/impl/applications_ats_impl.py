from typing import Any, List
from hire_pilot.apis.applications_ats_api_base import BaseApplicationsATSApi
from hire_pilot.models.application import Application
from hire_pilot.models.employer_applications_application_id_status_patch_request import EmployerApplicationsApplicationIdStatusPatchRequest
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.application_service import ApplicationService
from hire_pilot.services.job_service import JobService


class ApplicationsATSImpl(BaseApplicationsATSApi):
    def __init__(self):
        self.service = ApplicationService()
        self.job_service = JobService()

    # ── Candidate-facing ────────────────────────────────────

    async def candidate_apply_post(
        self,
        job_id: str,
    ) -> Any:
        user_id = get_current_user_id()
        app_id = await self.service.apply_to_job(job_id, user_id)
        return {"id": app_id, "message": "Application submitted successfully"}

    async def candidate_applications_get(
        self,
    ) -> List[Application]:
        user_id = get_current_user_id()
        return await self.service.list_candidate_applications(user_id)

    # ── Employer: Listing ───────────────────────────────────

    async def employer_jobs_job_id_applications_get(
        self,
        jobId: str,
    ) -> List[Application]:
        return await self.service.list_job_applications(jobId)

    async def employer_jobs_job_id_applications_enriched_get(
        self,
        jobId: str,
    ) -> Any:
        return await self.service.list_job_applications_enriched(jobId)

    async def employer_applications_application_id_get(
        self,
        applicationId: str,
    ) -> Application:
        return await self.service.get_application(applicationId)

    async def employer_applications_application_id_status_patch(
        self,
        applicationId: str,
        employer_applications_application_id_status_patch_request: EmployerApplicationsApplicationIdStatusPatchRequest,
    ) -> Any:
        new_status = employer_applications_application_id_status_patch_request.status.value
        await self.service.update_status(applicationId, new_status)
        return {"message": "Application status updated"}

    # ── Employer: Quick Actions ─────────────────────────────

    async def employer_applications_id_shortlist_post(
        self,
        id: str,
    ) -> Any:
        await self.service.update_status(id, "SHORTLISTED")
        return {"message": "Candidate shortlisted"}

    async def employer_applications_id_reject_post(
        self,
        id: str,
    ) -> Any:
        await self.service.update_status(id, "REJECTED")
        return {"message": "Candidate rejected"}

    async def employer_applications_id_move_stage_post(
        self,
        id: str,
        stage: str,
    ) -> Any:
        await self.service.move_stage(id, stage)
        return {"message": f"Application moved to {stage}"}

    async def employer_applications_id_add_note_post(
        self,
        id: str,
        note: str,
    ) -> Any:
        await self.service.add_application_note(id, note)
        return {"message": "Note added"}

    async def employer_applications_id_rate_post(
        self,
        id: str,
        rating: int,
    ) -> Any:
        await self.service.update_application_rating(id, rating)
        return {"message": "Candidate rated"}

    async def employer_applications_id_resume_get(
        self,
        id: str,
    ) -> Any:
        return await self.service.get_candidate_resume(id)

    # ── KPI / Analytics ─────────────────────────────────────

    async def employer_dashboard_kpis_get(
        self,
    ) -> Any:
        user_id = get_current_user_id()
        return await self.service.get_dashboard_kpis(user_id)

    async def employer_jobs_job_id_kpis_get(
        self,
        jobId: str,
    ) -> Any:
        return await self.service.get_job_kpis(jobId)

    # ── New: Duplicate, Withdraw, Bulk, Timeline ───────────

    async def employer_jobs_job_id_duplicate_post(
        self,
        jobId: str,
    ) -> Any:
        user_id = get_current_user_id()
        new_id = await self.job_service.duplicate_job(jobId, user_id)
        return {"id": new_id, "message": "Job duplicated as draft"}

    async def candidate_application_withdraw_post(
        self,
        applicationId: str,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.withdraw_application(applicationId, user_id)
        return {"message": "Application withdrawn"}

    async def employer_applications_bulk_update_post(
        self,
        body: dict,
    ) -> Any:
        ids = body.get("application_ids", [])
        new_status = body.get("status", "SHORTLISTED")
        return await self.service.bulk_update_status(ids, new_status)

    async def employer_application_timeline_get(
        self,
        applicationId: str,
    ) -> Any:
        return await self.service.get_application_timeline(applicationId)
