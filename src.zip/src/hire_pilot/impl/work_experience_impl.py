from typing import List, Optional, Any

from pydantic import StrictStr
from typing_extensions import Annotated
from pydantic import Field

from hire_pilot.apis.work_experience_api_base import BaseWorkExperienceApi
from hire_pilot.models.work_experience import WorkExperience
from hire_pilot.models.work_experience_input import WorkExperienceInput
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.work_experience_service import WorkExperienceService


class WorkExperienceImpl(BaseWorkExperienceApi):
    def __init__(self):
        self.service = WorkExperienceService()

    async def profile_work_experience_get(
        self,
        page: Annotated[Optional[Annotated[int, Field(ge=1)]], Field(description="Page number for pagination")],
        limit: Annotated[Optional[Annotated[int, Field(le=100, ge=1)]], Field(description="Number of items to return per page")],
    ) -> List[WorkExperience]:
        user_id = get_current_user_id()
        page_val = page if page is not None else 1
        limit_val = limit if limit is not None else 20
        return await self.service.get_all(user_id, page_val, limit_val)

    async def profile_work_experience_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> WorkExperience:
        user_id = get_current_user_id()
        return await self.service.get_by_id(id, user_id)

    async def profile_work_experience_post(
        self,
        work_experience_input: WorkExperienceInput,
    ) -> Any:
        user_id = get_current_user_id()
        work_experience = await self.service.create(user_id, work_experience_input)
        return work_experience

    async def profile_work_experience_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        work_experience_input: WorkExperienceInput,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(id, user_id, work_experience_input)
        return {"message": "Work experience updated successfully"}

    async def profile_work_experience_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.delete(id, user_id)
        return {"message": "Work experience deleted successfully"}
