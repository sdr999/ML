from typing import Any

from hire_pilot.apis.diversity_api_base import BaseDiversityApi
from hire_pilot.models.diversity import Diversity
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.diversity_service import DiversityService


class DiversityImpl(BaseDiversityApi):
    def __init__(self):
        self.service = DiversityService()

    async def profile_diversity_get(self) -> Diversity:
        user_id = get_current_user_id()
        return await self.service.get_by_user(user_id)

    async def profile_diversity_put(
        self,
        diversity: Diversity,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(user_id, diversity)
        return {"message": "Diversity info updated successfully"}
