from typing import Any, Dict
from hire_pilot.apis.subscription_billing_api_base import BaseSubscriptionBillingApi
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.subscription_billing_service import SubscriptionBillingService


class SubscriptionBillingImpl(BaseSubscriptionBillingApi):
    def __init__(self):
        self.service = SubscriptionBillingService()

    async def employer_plans_get(self) -> Any:
        return await self.service.list_plans()

    async def employer_subscription_get(self) -> Any:
        employer_id = get_current_user_id()
        return await self.service.get_subscription(employer_id)

    async def employer_subscription_post(
        self,
        plan_id: str
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.update_subscription(employer_id, plan_id)

    async def employer_payments_checkout_post(
        self,
        plan_id: str
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.create_checkout_session(employer_id, plan_id)

    async def employer_payments_webhook_post(
        self,
        payload: Dict[str, Any]
    ) -> Any:
        return await self.service.process_webhook(payload)

    async def employer_invoices_get(self) -> Any:
        employer_id = get_current_user_id()
        return await self.service.list_invoices(employer_id)
