from typing import List, Any

from pydantic import StrictStr
from typing_extensions import Annotated
from pydantic import Field

from hire_pilot.apis.personal_projects_api_base import BasePersonalProjectsApi
from hire_pilot.models.personal_project import PersonalProject
from hire_pilot.models.personal_project_input import PersonalProjectInput
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.personal_projects_service import PersonalProjectsService


class PersonalProjectsImpl(BasePersonalProjectsApi):
    def __init__(self):
        self.service = PersonalProjectsService()

    async def profile_projects_get(self) -> List[PersonalProject]:
        user_id = get_current_user_id()
        return await self.service.get_all(user_id)

    async def profile_projects_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> PersonalProject:
        user_id = get_current_user_id()
        return await self.service.get_by_id(id, user_id)

    async def profile_projects_post(
        self,
        personal_project_input: PersonalProjectInput,
    ) -> Any:
        user_id = get_current_user_id()
        inserted_id = await self.service.create(user_id, personal_project_input)
        return {"id": inserted_id, "message": "Project created successfully"}

    async def profile_projects_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        personal_project_input: PersonalProjectInput,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(id, user_id, personal_project_input)
        return {"message": "Project updated successfully"}

    async def profile_projects_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.delete(id, user_id)
        return {"message": "Project deleted successfully"}
