from typing import List, Any

from pydantic import StrictStr
from typing_extensions import Annotated
from pydantic import Field

from hire_pilot.apis.achievements_api_base import BaseAchievementsApi
from hire_pilot.models.achievement import Achievement
from hire_pilot.models.achievement_input import AchievementInput
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.achievements_service import AchievementsService


class AchievementsImpl(BaseAchievementsApi):
    def __init__(self):
        self.service = AchievementsService()

    async def profile_achievements_get(self) -> List[Achievement]:
        user_id = get_current_user_id()
        return await self.service.get_all(user_id)

    async def profile_achievements_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Achievement:
        user_id = get_current_user_id()
        return await self.service.get_by_id(id, user_id)

    async def profile_achievements_post(
        self,
        achievement_input: AchievementInput,
    ) -> Any:
        user_id = get_current_user_id()
        inserted_id = await self.service.create(user_id, achievement_input)
        return {"id": inserted_id, "message": "Achievement created successfully"}

    async def profile_achievements_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        achievement_input: AchievementInput,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(id, user_id, achievement_input)
        return {"message": "Achievement updated successfully"}

    async def profile_achievements_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.delete(id, user_id)
        return {"message": "Achievement deleted successfully"}
