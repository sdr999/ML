from typing import List, Any

from pydantic import StrictStr
from typing_extensions import Annotated
from pydantic import Field

from hire_pilot.apis.languages_api_base import BaseLanguagesApi
from hire_pilot.models.language import Language
from hire_pilot.models.language_input import LanguageInput
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.languages_service import LanguagesService


class LanguagesImpl(BaseLanguagesApi):
    def __init__(self):
        self.service = LanguagesService()

    async def profile_languages_get(self) -> List[Language]:
        user_id = get_current_user_id()
        return await self.service.get_all(user_id)

    async def profile_languages_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Language:
        user_id = get_current_user_id()
        return await self.service.get_by_id(id, user_id)

    async def profile_languages_post(
        self,
        language_input: LanguageInput,
    ) -> Any:
        user_id = get_current_user_id()
        inserted_id = await self.service.create(user_id, language_input)
        return {"id": inserted_id, "message": "Language created successfully"}

    async def profile_languages_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        language_input: LanguageInput,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(id, user_id, language_input)
        return {"message": "Language updated successfully"}

    async def profile_languages_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.delete(id, user_id)
        return {"message": "Language deleted successfully"}
