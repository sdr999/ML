from typing import Any, List, Optional
from hire_pilot.apis.messaging_notifications_api_base import BaseMessagingNotificationsApi
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.messaging_notifications_service import MessagingNotificationsService


class MessagingNotificationsImpl(BaseMessagingNotificationsApi):
    def __init__(self):
        self.service = MessagingNotificationsService()

    async def employer_messages_post(
        self,
        candidate_id: str,
        message: str
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.send_message(employer_id, candidate_id, "employer", message)

    async def employer_conversations_get(self) -> Any:
        employer_id = get_current_user_id()
        return await self.service.list_conversations(employer_id)

    async def employer_conversations_id_get(self, id: str) -> Any:
        employer_id = get_current_user_id()
        return await self.service.list_messages(employer_id, id)

    async def employer_communications_email_post(
        self,
        candidate_ids: List[str],
        subject: str,
        body: str
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.send_email(employer_id, candidate_ids, subject, body)

    async def employer_communications_sms_post(
        self,
        candidate_id: str,
        message: str
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.send_sms(employer_id, candidate_id, message)

    async def employer_notifications_get(self) -> Any:
        user_id = get_current_user_id()
        return await self.service.list_notifications(user_id)

    async def employer_notifications_id_read_patch(self, id: str) -> Any:
        user_id = get_current_user_id()
        return await self.service.read_notification(user_id, id)

    # ── Candidate-facing methods ───────────────────────────────

    async def candidate_inbox_get(self) -> Any:
        candidate_id = get_current_user_id()
        return await self.service.candidate_list_conversations(candidate_id)

    async def candidate_inbox_employer_get(self, employer_id: str) -> Any:
        candidate_id = get_current_user_id()
        return await self.service.candidate_list_messages(candidate_id, employer_id)

    async def candidate_inbox_reply_post(self, employer_id: str, message: str) -> Any:
        candidate_id = get_current_user_id()
        return await self.service.send_message(employer_id, candidate_id, "candidate", message)

    async def candidate_notifications_get(self) -> Any:
        user_id = get_current_user_id()
        return await self.service.list_notifications(user_id)

    async def candidate_notifications_read_patch(self, id: str) -> Any:
        user_id = get_current_user_id()
        return await self.service.read_notification(user_id, id)
