from typing import Any, Optional, List
from hire_pilot.apis.interview_management_api_base import BaseInterviewManagementApi
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.interview_service import InterviewService


class InterviewManagementImpl(BaseInterviewManagementApi):
    def __init__(self):
        self.service = InterviewService()

    async def employer_interviews_get(self) -> Any:
        employer_id = get_current_user_id()
        return await self.service.list_interviews(employer_id)

    async def employer_interviews_post(
        self,
        candidate_id: str,
        job_id: str,
        scheduled_at: str,
        duration_minutes: int,
        title: str,
        description: Optional[str] = None
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.schedule_interview(
            employer_id, candidate_id, job_id, scheduled_at, duration_minutes, title, description
        )

    async def employer_interviews_id_put(
        self,
        id: str,
        scheduled_at: str,
        duration_minutes: Optional[int] = None,
        title: Optional[str] = None,
        description: Optional[str] = None
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.reschedule_interview(
            employer_id, id, scheduled_at, duration_minutes, title, description
        )

    async def employer_interviews_id_delete(self, id: str) -> Any:
        employer_id = get_current_user_id()
        await self.service.cancel_interview(employer_id, id)
        return {"message": "Interview cancelled successfully."}

    async def employer_interviews_slots_get(self) -> Any:
        employer_id = get_current_user_id()
        return await self.service.get_slots(employer_id)

    async def employer_interviews_slots_post(
        self,
        slots: List[str]
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.add_slots(employer_id, slots)

    async def employer_interviews_id_feedback_get(self, id: str) -> Any:
        return await self.service.get_feedback(id)

    async def employer_interviews_id_feedback_post(
        self,
        id: str,
        rating: int,
        comments: str,
        recommendation: str
    ) -> Any:
        return await self.service.submit_feedback(id, rating, comments, recommendation)

    async def candidate_interviews_get(self) -> Any:
        candidate_id = get_current_user_id()
        return await self.service.list_candidate_interviews(candidate_id)
