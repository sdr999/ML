from typing import List
from hire_pilot.apis.verification_api_base import BaseVerificationApi
from hire_pilot.models.verification_request import VerificationSubmitRequest
from hire_pilot.models.verification_status import VerificationStatus
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.verification_service import VerificationService


class VerificationImpl(BaseVerificationApi):
    def __init__(self):
        self.service = VerificationService()

    async def employer_verification_pan_post(
        self, body: VerificationSubmitRequest
    ) -> VerificationStatus:
        employer_id = get_current_user_id()
        return await self.service.submit_pan(employer_id, body)

    async def employer_verification_gst_post(
        self, body: VerificationSubmitRequest
    ) -> VerificationStatus:
        employer_id = get_current_user_id()
        return await self.service.submit_gst(employer_id, body)

    async def employer_verification_company_docs_post(
        self, body: VerificationSubmitRequest
    ) -> VerificationStatus:
        employer_id = get_current_user_id()
        return await self.service.submit_company_docs(employer_id, body)

    async def employer_verification_status_get(self) -> List[VerificationStatus]:
        employer_id = get_current_user_id()
        return await self.service.get_verification_status(employer_id)
