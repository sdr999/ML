from typing import Any
from fastapi import Response
import base64
from hire_pilot.apis.profile_operations_api_base import BaseProfileOperationsApi
from hire_pilot.models.profile_resume_parse_post_request import ProfileResumeParsePostRequest
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.profile_details_service import ProfileDetailsService
from hire_pilot.services.resume_service import ResumeService
from hire_pilot.services.resume_parser_service import ResumeParserService

class ProfileOperationsImpl(BaseProfileOperationsApi):
    def __init__(self):
        self.profile_details_service = ProfileDetailsService()
        self.resume_parser_service = ResumeParserService()
        self.resume_service = ResumeService()

    async def profile_resume_parse_post(
        self,
        profile_resume_parse_post_request: ProfileResumeParsePostRequest,
    ) -> Any:
        base64_doc = profile_resume_parse_post_request.resume_document
        parsed_data = await self.resume_parser_service.parse_resume(base64_doc)
        return parsed_data

    async def profile_details_get(self) -> Any:
        user_id = get_current_user_id()
        profile = await self.profile_details_service.get_full_profile(user_id)
        return profile

    async def resume_download_get(self) -> Any:
        user_id = get_current_user_id()
        doc = await self.resume_service.get_resume(user_id)
        file_bytes = base64.b64decode(doc["file_data"])
        return Response(
            content=file_bytes,
            media_type=doc.get("content_type", "application/pdf"),
            headers={"Content-Disposition": f'attachment; filename="{doc.get("filename", "resume.pdf")}"'}
        )

    async def resume_generate_post(self) -> Any:
        user_id = get_current_user_id()
        await self.resume_service.generate_resume_from_profile(user_id)
        return {"message": "Resume generated and saved successfully."}

    async def profile_completion_get(self) -> Any:
        user_id = get_current_user_id()
        return await self.profile_details_service.get_profile_completion(user_id)
