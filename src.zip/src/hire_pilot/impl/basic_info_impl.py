from hire_pilot.apis.basic_info_api_base import BaseBasicInfoApi
from hire_pilot.models.basic_info import BasicInfo
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.basic_info_service import BasicInfoService


class BasicInfoImpl(BaseBasicInfoApi):
    def __init__(self):
        self.service = BasicInfoService()

    async def profile_basic_info_get(
        self,
    ) -> BasicInfo:
        user_id = get_current_user_id()
        return await self.service.get_by_user(user_id)

    async def profile_basic_info_put(
        self,
        basic_info: BasicInfo,
    ) -> None:
        user_id = get_current_user_id()
        await self.service.update(user_id, basic_info)
        return {"message": "Basic info updated successfully"}
