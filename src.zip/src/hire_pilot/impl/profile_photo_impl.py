from typing import Any
from hire_pilot.apis.profile_photo_api_base import BaseProfilePhotoApi
from hire_pilot.models.profile_photo_get200_response import ProfilePhotoGet200Response
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.profile_photo_service import ProfilePhotoService

class ProfilePhotoImpl(BaseProfilePhotoApi):
    def __init__(self):
        self.service = ProfilePhotoService()

    async def profile_photo_delete(self) -> None:
        user_id = get_current_user_id()
        await self.service.delete(user_id)

    async def profile_photo_get(self) -> ProfilePhotoGet200Response:
        user_id = get_current_user_id()
        photo = await self.service.get_by_user(user_id)
        if not photo:
            return ProfilePhotoGet200Response(photo="")
        return ProfilePhotoGet200Response(photo=photo)

    async def profile_photo_put(
        self,
        profile_photo_get200_response: ProfilePhotoGet200Response,
    ) -> None:
        user_id = get_current_user_id()
        photo = profile_photo_get200_response.photo
        if photo:
            await self.service.update(user_id, photo)
