from typing import List, Any

from pydantic import StrictStr
from typing_extensions import Annotated
from pydantic import Field

from hire_pilot.apis.certifications_api_base import BaseCertificationsApi
from hire_pilot.models.certification import Certification
from hire_pilot.models.certification_input import CertificationInput
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.certifications_service import CertificationsService


class CertificationsImpl(BaseCertificationsApi):
    def __init__(self):
        self.service = CertificationsService()

    async def profile_certifications_get(self) -> List[Certification]:
        user_id = get_current_user_id()
        return await self.service.get_all(user_id)

    async def profile_certifications_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Certification:
        user_id = get_current_user_id()
        return await self.service.get_by_id(id, user_id)

    async def profile_certifications_post(
        self,
        certification_input: CertificationInput,
    ) -> Any:
        user_id = get_current_user_id()
        inserted_id = await self.service.create(user_id, certification_input)
        return {"id": inserted_id, "message": "Certification created successfully"}

    async def profile_certifications_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        certification_input: CertificationInput,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(id, user_id, certification_input)
        return {"message": "Certification updated successfully"}

    async def profile_certifications_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.delete(id, user_id)
        return {"message": "Certification deleted successfully"}
