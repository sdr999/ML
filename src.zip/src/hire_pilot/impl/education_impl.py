from typing import List, Any

from pydantic import StrictStr
from typing_extensions import Annotated
from pydantic import Field

from hire_pilot.apis.education_api_base import BaseEducationApi
from hire_pilot.models.education import Education
from hire_pilot.models.education_input import EducationInput
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.education_service import EducationService


class EducationImpl(BaseEducationApi):
    def __init__(self):
        self.service = EducationService()

    async def profile_education_get(self) -> List[Education]:
        user_id = get_current_user_id()
        return await self.service.get_all(user_id)

    async def profile_education_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Education:
        user_id = get_current_user_id()
        return await self.service.get_by_id(id, user_id)

    async def profile_education_post(
        self,
        education_input: EducationInput,
    ) -> Any:
        user_id = get_current_user_id()
        inserted_id = await self.service.create(user_id, education_input)
        return {"id": inserted_id, "message": "Education created successfully"}

    async def profile_education_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        education_input: EducationInput,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.update(id, user_id, education_input)
        return {"message": "Education updated successfully"}

    async def profile_education_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.delete(id, user_id)
        return {"message": "Education deleted successfully"}
