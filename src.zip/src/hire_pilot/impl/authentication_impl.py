from typing import Any
from hire_pilot.apis.authentication_api_base import BaseAuthenticationApi
from hire_pilot.models.sign_up_request import SignUpRequest
from hire_pilot.models.sign_in_request import SignInRequest
from hire_pilot.models.auth_response import AuthResponse
from hire_pilot.services.signup_service import SignupService


class AuthenticationImpl(BaseAuthenticationApi):
    def __init__(self):
        self.sign_service = SignupService()

    async def auth_signup_post(self, sign_up_request: SignUpRequest) -> Any:
        await self.sign_service.auth_signup_post(sign_up_request=sign_up_request)
        return {"message": "User registered successfully"}

    async def auth_signin_post(self, sign_in_request: SignInRequest) -> AuthResponse:
        return await self.sign_service.auth_signin_post(sign_in_request=sign_in_request)

    async def auth_refresh_post(self, refresh_token: str) -> AuthResponse:
        return await self.sign_service.auth_refresh_post(refresh_token=refresh_token)

    async def auth_forgot_password_post(self, email: str, redirect_to: str | None = None) -> Any:
        await self.sign_service.auth_forgot_password_post(email=email, redirect_to=redirect_to)
        return {"message": "If that email exists, a reset link has been sent."}

    async def auth_reset_password_post(self, access_token: str, new_password: str) -> Any:
        await self.sign_service.auth_reset_password_post(access_token=access_token, new_password=new_password)
        return {"message": "Password has been reset successfully."}