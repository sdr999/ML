from typing import Any, Optional, Dict
from hire_pilot.apis.candidate_search_api_base import BaseCandidateSearchApi
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.candidate_search_service import CandidateSearchService


class CandidateSearchImpl(BaseCandidateSearchApi):
    def __init__(self):
        self.service = CandidateSearchService()

    async def employer_candidates_search_get(
        self,
        skills: Optional[str],
        experience: Optional[int],
        location: Optional[str],
    ) -> Any:
        return await self.service.search_candidates(skills, experience, location)

    async def employer_candidates_search_post(
        self,
    ) -> Any:
        # Fallback to general search since it's mapped to POST as well in some specs
        return await self.service.search_candidates()

    async def employer_candidates_candidate_id_get(
        self,
        candidateId: str,
    ) -> Any:
        return await self.service.get_candidate_profile(candidateId)

    async def employer_searches_save_post(
        self,
        body: Optional[Dict[str, Any]] = None,
    ) -> Any:
        user_id = get_current_user_id()
        if not body:
            body = {}
        # Expected structure: {"name": "Search Name", "filters": {"skills": "...", "location": "..."}}
        name = body.get("name", "Saved Search")
        filters = body.get("filters", {})
        search_data = {
            "name": name,
            "filters": filters
        }
        return await self.service.save_search_filters(user_id, search_data)

    async def employer_searches_get(
        self,
    ) -> Any:
        user_id = get_current_user_id()
        return await self.service.get_saved_searches(user_id)

    async def employer_searches_id_delete(
        self,
        id: str,
    ) -> Any:
        user_id = get_current_user_id()
        await self.service.delete_saved_search(user_id, id)
        return {"message": "Saved search deleted successfully"}

    async def employer_talent_pools_get(
        self,
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.get_talent_pools(employer_id)

    async def employer_talent_pools_post(
        self,
        name: str,
        description: Optional[str] = None,
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.create_talent_pool(employer_id, name, description)

    async def employer_talent_pools_id_candidates_post(
        self,
        id: str,
        candidate_id: str,
    ) -> Any:
        employer_id = get_current_user_id()
        return await self.service.add_candidate_to_pool(employer_id, id, candidate_id)
