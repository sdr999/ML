from typing import List
from hire_pilot.apis.metadata_api_base import BaseMetadataApi

class MetadataImpl(BaseMetadataApi):
    async def metadata_degrees_get(self) -> List[str]:
        return ["12TH", "BACHELOR", "MASTER", "PHD"]

    async def metadata_locations_get(self) -> List[str]:
        return ["Bangalore, India", "New York, USA", "London, UK", "Remote", "San Francisco, USA", "Berlin, Germany"]

    async def metadata_skills_get(self) -> List[str]:
        return ["Python", "JavaScript", "TypeScript", "React", "Node.js", "Java", "Go", "C++", "SQL", "MongoDB"]
