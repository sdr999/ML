from typing import Any, Dict, List, Optional
from hire_pilot.apis.public_jobs_api_base import BasePublicJobsApi
from hire_pilot.services.public_jobs_service import PublicJobsService


class PublicJobsImpl(BasePublicJobsApi):
    def __init__(self):
        self.service = PublicJobsService()

    async def jobs_get(
        self,
        keyword: Optional[str],
        skills: Optional[str],
        location: Optional[str],
        job_type: Optional[str],
        work_mode: Optional[str],
        page: int,
        limit: int,
    ) -> List[Dict[str, Any]]:
        return await self.service.list_published_jobs(
            keyword, skills, location, job_type, work_mode, page, limit
        )

    async def jobs_id_get(self, job_id: str, viewer_id: Optional[str]) -> Dict[str, Any]:
        return await self.service.get_published_job(job_id, viewer_id)
