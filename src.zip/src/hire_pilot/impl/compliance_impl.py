from typing import List
from hire_pilot.apis.compliance_api_base import BaseComplianceApi
from hire_pilot.models.moderation_report import ModerationReport, ReportCandidateRequest
from hire_pilot.models.policy import Policy
from hire_pilot.security_api import get_current_user_id
from hire_pilot.services.compliance_service import ComplianceService


class ComplianceImpl(BaseComplianceApi):
    def __init__(self):
        self.service = ComplianceService()

    async def employer_policies_get(self) -> List[Policy]:
        return await self.service.list_policies()

    async def employer_report_candidate_post(
        self, body: ReportCandidateRequest
    ) -> ModerationReport:
        reporter_id = get_current_user_id()
        return await self.service.report_candidate(
            reporter_id,
            body.reported_candidate_id,
            body.reason,
            body.description,
        )
