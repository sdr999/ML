import os
from typing import Any, Dict, Optional
from datetime import datetime, timezone

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "resumes"


class ResumeRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")


        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        log.info("Initializing MongoAdapter for resume repository.")
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_one_by_user(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve the latest resume belonging to a user."""
        log.debug("Querying resume | user_id=%s", user_id)
        doc = await self.adapter.find_one(COLLECTION, {"user_id": user_id})
        if doc and "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    async def upsert_one(
        self,
        user_id: str,
        file_bytes_b64: str,
        filename: str,
        content_type: str,
        source: str,
    ) -> None:
        """Store or replace a user's resume document.

        Args:
            user_id: Owner of the resume.
            file_bytes_b64: Base64-encoded binary content.
            filename: Original filename (or generated name).
            content_type: MIME type (e.g. application/pdf).
            source: 'uploaded' if user uploaded, 'generated' if system-generated.
        """
        log.debug("Upserting resume | user_id=%s, source=%s", user_id, source)

        doc_data = {
            "file_data": file_bytes_b64,
            "filename": filename,
            "content_type": content_type,
            "source": source,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

        existing = await self.adapter.find_one(COLLECTION, {"user_id": user_id})
        if existing:
            await self.adapter.update_one(COLLECTION, {"user_id": user_id}, doc_data)
        else:
            doc_data["user_id"] = user_id
            doc_data["created_at"] = datetime.now(timezone.utc).isoformat()
            await self.adapter.insert_one(COLLECTION, doc_data)
