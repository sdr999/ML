import os
from typing import Any, Dict, List, Optional

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "skills"


class SkillsRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        log.info("Initializing MongoAdapter for skills repository.")
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_one_by_user(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve skills belonging to a user."""
        log.debug("Querying skills | user_id=%s", user_id)
        doc = await self.adapter.find_one(COLLECTION, {"user_id": user_id})
        if doc and "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    async def upsert_one(self, user_id: str, skills: List[str]) -> None:
        """Update a user's skills document, or insert if it doesn't exist."""
        log.debug("Upserting skills | user_id=%s, count=%d", user_id, len(skills))
        
        existing = await self.adapter.find_one(COLLECTION, {"user_id": user_id})
        if existing:
            await self.adapter.update_one(
                COLLECTION,
                {"user_id": user_id},
                {"skills": skills}
            )
        else:
            await self.adapter.insert_one(
                COLLECTION,
                {"user_id": user_id, "skills": skills}
            )
