import os
from typing import Dict, List
from dotenv import dotenv_values
from hire_pilot.utils.mongodb_adapter import MongoAdapter

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)

MONGO_URI = env.get("MONGODB_URI", "")
MONGO_DB = env.get("DB_NAME", "hire_pilot")
COLLECTION = "moderation_reports"


class ComplianceRepository:
    def __init__(self):
        self.adapter = MongoAdapter(uri=MONGO_URI, db_name=MONGO_DB)

    async def insert_report(self, data: Dict) -> str:
        inserted_id = await self.adapter.insert_one(COLLECTION, data)
        return str(inserted_id)

    async def find_by_reporter(self, reporter_id: str) -> List[Dict]:
        docs = await self.adapter.find_many(COLLECTION, {"reporter_id": reporter_id})
        for doc in docs:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return docs
