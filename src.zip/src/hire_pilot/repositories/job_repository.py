import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from bson import ObjectId

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "jobs"

class JobRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_by_employer(self, employer_id: str, skip: int = 0, limit: int = 20) -> List[Dict[str, Any]]:
        log.info("Fetching jobs for employer | employer_id=%s", employer_id)
        # Using a simpler find for now, ignoring pagination for the basic find_many in adapter
        # but we can improve adapter later.
        results = await self.adapter.find_many(COLLECTION, {"employer_id": employer_id})
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        return results

    async def find_by_id(self, job_id: str) -> Optional[Dict[str, Any]]:
        log.debug("Querying job | job_id=%s", job_id)
        try:
            doc = await self.adapter.find_one(COLLECTION, {"_id": ObjectId(job_id)})
        except:
            # Fallback if jobId is not a valid ObjectId (might be a UUID string)
            doc = await self.adapter.find_one(COLLECTION, {"id": job_id})
            
        if doc and "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    async def insert_job(self, employer_id: str, job_data: Dict[str, Any]) -> str:
        log.info("Inserting job | employer_id=%s", employer_id)
        job_data["employer_id"] = employer_id
        job_data["created_at"] = datetime.now(timezone.utc).isoformat()
        job_data["status"] = "DRAFT"
        inserted_id = await self.adapter.insert_one(COLLECTION, job_data)
        return str(inserted_id)

    async def update_job(self, job_id: str, data: Dict[str, Any]) -> int:
        log.info("Updating job | job_id=%s", job_id)
        try:
            return await self.adapter.update_one(COLLECTION, {"_id": ObjectId(job_id)}, data)
        except:
            return await self.adapter.update_one(COLLECTION, {"id": job_id}, data)

    async def delete_job(self, job_id: str) -> int:
        log.info("Deleting job | job_id=%s", job_id)
        try:
            return await self.adapter.delete_one(COLLECTION, {"_id": ObjectId(job_id)})
        except:
            return await self.adapter.delete_one(COLLECTION, {"id": job_id})

    async def update_status(self, job_id: str, status: str) -> int:
        log.info("Updating job status | job_id=%s, status=%s", job_id, status)
        return await self.update_job(job_id, {"status": status})

    async def find_recommended(
        self, 
        skills: List[str], 
        locations: List[str], 
        page: int = 1, 
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        log.info("Finding recommended jobs | skills=%s, locations=%s", skills, locations)
        
        # Build the query filters
        filters = []
        if skills:
            filters.append({"skills": {"$in": skills}})
        if locations:
            filters.append({"location": {"$in": locations}})

        query = {"status": "PUBLISHED"}
        if filters:
            query["$or"] = filters

        results = await self.adapter.find_many(COLLECTION, query)
        
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        return results
