import os
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone, timedelta
from bson import ObjectId

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

SUBSCRIPTIONS_COLLECTION = "subscriptions"
INVOICES_COLLECTION = "invoices"


class SubscriptionBillingRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_subscription(self, employer_id: str) -> Optional[Dict[str, Any]]:
        log.info("Fetching subscription for employer | employer_id=%s", employer_id)
        res = await self.adapter.find_one(SUBSCRIPTIONS_COLLECTION, {"employer_id": employer_id})
        if res:
            res["id"] = str(res["_id"])
            del res["_id"]
        return res

    async def upsert_subscription(self, employer_id: str, plan_id: str, status: str = "active", billing_cycle: str = "monthly") -> Dict[str, Any]:
        log.info("Upserting subscription | employer_id=%s, plan_id=%s, status=%s", employer_id, plan_id, status)
        
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(days=30) if billing_cycle == "monthly" else now + timedelta(days=365)
        
        doc = {
            "employer_id": employer_id,
            "plan_id": plan_id,
            "status": status,
            "billing_cycle": billing_cycle,
            "started_at": now.isoformat(),
            "expires_at": expires_at.isoformat(),
            "updated_at": now.isoformat()
        }
        
        existing = await self.adapter.find_one(SUBSCRIPTIONS_COLLECTION, {"employer_id": employer_id})
        if existing:
            await self.adapter.update_one(
                SUBSCRIPTIONS_COLLECTION,
                {"employer_id": employer_id},
                doc
            )
            doc["id"] = str(existing["_id"])
        else:
            inserted_id = await self.adapter.insert_one(SUBSCRIPTIONS_COLLECTION, doc)
            doc["id"] = str(inserted_id)
            
        return doc

    async def find_invoices(self, employer_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching invoices for employer | employer_id=%s", employer_id)
        results = await self.adapter.find_many(INVOICES_COLLECTION, {"employer_id": employer_id})
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        results.sort(key=lambda x: x["issued_at"], reverse=True)
        return results

    async def insert_invoice(self, employer_id: str, invoice_data: Dict[str, Any]) -> str:
        log.info("Creating invoice for employer | employer_id=%s", employer_id)
        invoice_data["employer_id"] = employer_id
        if "issued_at" not in invoice_data:
            invoice_data["issued_at"] = datetime.now(timezone.utc).isoformat()
        inserted_id = await self.adapter.insert_one(INVOICES_COLLECTION, invoice_data)
        return str(inserted_id)
