import os
from hire_pilot.utils.logger import log
from supabase import create_client, Client, AuthApiError
from dotenv import load_dotenv, dotenv_values
import asyncio

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", 'config', '.env')
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)


class SignupRepository:
    def __init__(self):
        SUPABASE_URL = env.get("SUPABASE_URL")
        SUPABASE_KEY = env.get("SUPABASE_KEY")
        if not SUPABASE_URL or not SUPABASE_KEY:
            log.error("Supabase credentials not found in environment variables.")
            raise ValueError("Supabase credentials missing.")
        log.info("Initializing Supabase client.")
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

    async def sign_up_user(self, email: str, password: str):
        """
        Register a new user via Supabase Auth.

        Raises:
            AuthApiError: Supabase-specific auth failure (duplicate email, weak password, etc.)
            Exception: Unexpected infrastructure errors (network, timeout).
        """
        log.debug("Executing non-blocking Supabase sign_up")
        try:
            response = await asyncio.to_thread(
                self.supabase.auth.sign_up,
                {
                    "email": email,
                    "password": password
                }
            )
            return response
        except AuthApiError:
            # Let AuthApiError propagate cleanly — the service layer maps it to HTTP status
            raise
        except Exception as e:
            log.error(
                "Supabase sign_up call failed | error_type=%s, error=%s",
                type(e).__name__, str(e)
            )
            raise

    async def sign_in_user(self, email: str, password: str):
        """
        Authenticate an existing user via Supabase Auth.

        Raises:
            AuthApiError: Invalid credentials or account issues.
            Exception: Unexpected infrastructure errors (network, timeout).
        """
        log.debug("Executing non-blocking Supabase sign_in_with_password")
        try:
            response = await asyncio.to_thread(
                self.supabase.auth.sign_in_with_password,
                {
                    "email": email,
                    "password": password
                }
            )
            return response
        except AuthApiError:
            raise
        except Exception as e:
            log.error(
                "Supabase sign_in call failed | error_type=%s, error=%s",
                type(e).__name__, str(e)
            )
            raise

    async def refresh_session(self, refresh_token: str):
        """
        Refresh an expired access token using a refresh token.

        Raises:
            AuthApiError: Invalid or expired refresh token.
            Exception: Unexpected infrastructure errors.
        """
        log.debug("Executing non-blocking Supabase refresh_session")
        try:
            response = await asyncio.to_thread(
                self.supabase.auth.refresh_session,
                refresh_token
            )
            return response
        except AuthApiError:
            raise
        except Exception as e:
            log.error(
                "Supabase refresh_session call failed | error_type=%s, error=%s",
                type(e).__name__, str(e)
            )
            raise

    async def reset_password_for_email(self, email: str, redirect_to: str | None = None):
        """
        Send a password reset email to the user.

        Raises:
            AuthApiError: Supabase-specific auth failure.
            Exception: Unexpected infrastructure errors.
        """
        log.debug("Executing non-blocking Supabase reset_password_for_email")
        try:
            options = {}
            if redirect_to:
                options["redirect_to"] = redirect_to
            log.info("Sending reset email | redirect_to=%s", redirect_to)
            response = await asyncio.to_thread(
                lambda: self.supabase.auth.reset_password_for_email(
                    email,
                    options=options if options else None
                )
            )
            log.info("Supabase reset_password_for_email returned successfully")
            return response
        except AuthApiError as e:
            log.error("Supabase reset_password_for_email AuthApiError | error=%s", str(e))
            raise
        except Exception as e:
            log.error(
                "Supabase reset_password_for_email call failed | error_type=%s, error=%s",
                type(e).__name__, str(e)
            )
            raise

    async def update_user_password(self, access_token: str, new_password: str):
        """
        Update the authenticated user's password using the provided access token.
        Uses a direct HTTP call to Supabase Auth API to avoid session requirements
        of the client library.

        Raises:
            ValueError: If the Supabase API returns an error.
            Exception: Unexpected infrastructure errors.
        """
        import httpx
        log.debug("Executing direct HTTP update_user (password)")
        
        SUPABASE_URL = env.get("SUPABASE_URL")
        SUPABASE_KEY = env.get("SUPABASE_KEY")
        
        url = f"{SUPABASE_URL}/auth/v1/user"
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.put(
                    url,
                    json={"password": new_password},
                    headers=headers
                )
                
                if response.status_code != 200:
                    error_data = response.json()
                    log.error("Supabase direct update failed | status=%s, error=%s", 
                              response.status_code, error_data)
                    msg = error_data.get("msg") or error_data.get("error_description") or f"Status {response.status_code}"
                    raise ValueError(msg)
                
                return response.json()
        except Exception as e:
            log.error("Direct Supabase update failed | error=%s", str(e))
            raise