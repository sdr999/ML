import os
from typing import Any, Dict, List, Optional

from bson import ObjectId
from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "education"


class EducationRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        log.info("Initializing MongoAdapter for education repository.")
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_all_by_user(self, user_id: str) -> List[Dict[str, Any]]:
        """Retrieve all education records belonging to a user."""
        log.debug("Querying education | user_id=%s", user_id)
        docs = await self.adapter.find_many(COLLECTION, {"user_id": user_id})
        for doc in docs:
            if "_id" in doc:
                doc["id"] = str(doc["_id"])
                del doc["_id"]
        return docs

    async def find_one_by_id(self, education_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a single education record by its ID, scoped to the user."""
        log.debug("Querying single education | id=%s, user_id=%s", education_id, user_id)
        doc = await self.adapter.find_one(
            COLLECTION, {"_id": ObjectId(education_id), "user_id": user_id}
        )
        if doc and "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    async def insert_one(self, user_id: str, data: Dict[str, Any]) -> str:
        """Insert a new education document and return the generated ID."""
        data["user_id"] = user_id
        log.debug("Inserting education | user_id=%s", user_id)
        inserted_id = await self.adapter.insert_one(COLLECTION, data)
        return str(inserted_id)

    async def update_one(self, education_id: str, user_id: str, data: Dict[str, Any]) -> int:
        """Update an education document. Returns the modified count."""
        log.debug("Updating education | id=%s, user_id=%s", education_id, user_id)
        return await self.adapter.update_one(
            COLLECTION,
            {"_id": ObjectId(education_id), "user_id": user_id},
            data,
        )

    async def delete_one(self, education_id: str, user_id: str) -> int:
        """Delete an education document. Returns the deleted count."""
        log.debug("Deleting education | id=%s, user_id=%s", education_id, user_id)
        return await self.adapter.delete_one(
            COLLECTION,
            {"_id": ObjectId(education_id), "user_id": user_id},
        )
