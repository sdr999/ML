import os
from typing import Any, Dict, List, Optional
from bson import ObjectId

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "team_members"

class TeamRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_by_employer(self, employer_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching team members for employer | employer_id=%s", employer_id)
        results = await self.adapter.find_many(COLLECTION, {"employer_id": employer_id})
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        return results

    async def insert_member(self, employer_id: str, member_data: Dict[str, Any]) -> str:
        log.info("Inserting team member | employer_id=%s", employer_id)
        member_data["employer_id"] = employer_id
        inserted_id = await self.adapter.insert_one(COLLECTION, member_data)
        return str(inserted_id)

    async def update_role(self, member_id: str, role: str) -> int:
        log.info("Updating team member role | member_id=%s, role=%s", member_id, role)
        try:
            return await self.adapter.update_one(COLLECTION, {"_id": ObjectId(member_id)}, {"role": role})
        except:
            return await self.adapter.update_one(COLLECTION, {"id": member_id}, {"role": role})

    async def delete_member(self, member_id: str) -> int:
        log.info("Deleting team member | member_id=%s", member_id)
        try:
            return await self.adapter.delete_one(COLLECTION, {"_id": ObjectId(member_id)})
        except:
            return await self.adapter.delete_one(COLLECTION, {"id": member_id})
