import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from bson import ObjectId
from dotenv import dotenv_values, load_dotenv
from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "offers"


class OfferRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def insert_offer(self, data: Dict[str, Any]) -> str:
        log.info("Inserting offer | application_id=%s", data.get("application_id"))
        data["created_at"] = datetime.now(timezone.utc).isoformat()
        data["status"] = "PENDING"
        inserted_id = await self.adapter.insert_one(COLLECTION, data)
        return str(inserted_id)

    async def find_by_application(self, application_id: str) -> Optional[Dict[str, Any]]:
        doc = await self.adapter.find_one(COLLECTION, {"application_id": application_id})
        if doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    async def find_by_candidate(self, candidate_id: str) -> List[Dict[str, Any]]:
        docs = await self.adapter.find_many(COLLECTION, {"candidate_id": candidate_id})
        for doc in docs:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return docs

    async def update_offer_response(
        self,
        offer_id: str,
        candidate_id: str,
        status: str,
        notes: Optional[str],
    ) -> bool:
        log.info("Updating offer response | offer_id=%s status=%s", offer_id, status)
        try:
            data = {
                "status": status,
                "candidate_notes": notes,
                "responded_at": datetime.now(timezone.utc).isoformat(),
            }
            res = await self.adapter.update_one(
                COLLECTION,
                {"_id": ObjectId(offer_id), "candidate_id": candidate_id},
                data,
            )
            return res > 0
        except Exception:
            return False
