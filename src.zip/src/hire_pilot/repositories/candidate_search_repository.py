import os
from typing import Any, Dict, List, Optional

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

USER_COLLECTION = "users"
SKILLS_COLLECTION = "skills"
BASIC_INFO_COLLECTION = "basic_info"
SAVED_SEARCHES_COLLECTION = "saved_searches"


class CandidateSearchRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def search_candidates(
        self, 
        skills: Optional[str] = None, 
        experience: Optional[int] = None, 
        location: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        log.info("Searching candidates | skills=%s, experience=%s, location=%s", skills, experience, location)
        
        pipeline = [
            {"$match": {"role": "employee"}},
            {
                "$lookup": {
                    "from": BASIC_INFO_COLLECTION,
                    "localField": "user_id",
                    "foreignField": "user_id",
                    "as": "basic_info"
                }
            },
            {"$unwind": {"path": "$basic_info", "preserveNullAndEmptyArrays": True}},
            {
                "$lookup": {
                    "from": SKILLS_COLLECTION,
                    "localField": "user_id",
                    "foreignField": "user_id",
                    "as": "skills_data"
                }
            },
            {"$unwind": {"path": "$skills_data", "preserveNullAndEmptyArrays": True}},
        ]

        # Apply filters
        match_filters = {}
        if location:
            match_filters["basic_info.address"] = {"$regex": location, "$options": "i"}
        
        if skills:
            skill_list = [s.strip() for s in skills.split(",")]
            match_filters["skills_data.skills"] = {"$all": skill_list}
            
        if match_filters:
            pipeline.append({"$match": match_filters})

        # Project needed fields
        pipeline.append({
            "$project": {
                "_id": 0,
                "user_id": 1,
                "first_name": 1,
                "last_name": 1,
                "email": 1,
                "location": "$basic_info.address",
                "skills": "$skills_data.skills",
                "designation": 1 # Some users might have designation if they were employers or just general info
            }
        })

        results = await self.adapter.aggregate(USER_COLLECTION, pipeline)
        return results

    async def find_candidate_by_id(self, candidate_id: str) -> Optional[Dict[str, Any]]:
        log.info("Finding candidate by ID | candidate_id=%s", candidate_id)
        # We can reuse ProfileDetailsService for this if we want full details
        # But for search, we might just want the user doc and some basic info
        doc = await self.adapter.find_one(USER_COLLECTION, {"user_id": candidate_id, "role": "employee"})
        return doc

    async def save_search(self, user_id: str, search_data: Dict[str, Any]) -> str:
        log.info("Saving search filters | user_id=%s", user_id)
        search_data["user_id"] = user_id
        inserted_id = await self.adapter.insert_one(SAVED_SEARCHES_COLLECTION, search_data)
        return str(inserted_id)

    async def get_saved_searches(self, user_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching saved searches | user_id=%s", user_id)
        results = await self.adapter.find_many(SAVED_SEARCHES_COLLECTION, {"user_id": user_id})
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        return results

    async def delete_saved_search(self, user_id: str, search_id: str) -> int:
        from bson import ObjectId
        log.info("Deleting saved search | user_id=%s, search_id=%s", user_id, search_id)
        try:
            return await self.adapter.delete_one(
                SAVED_SEARCHES_COLLECTION, 
                {"_id": ObjectId(search_id), "user_id": user_id}
            )
        except Exception:
            return 0

    async def get_talent_pools(self, employer_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching talent pools | employer_id=%s", employer_id)
        results = await self.adapter.find_many("talent_pools", {"employer_id": employer_id})
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        return results

    async def create_talent_pool(self, employer_id: str, name: str, description: Optional[str] = None) -> str:
        log.info("Creating talent pool | employer_id=%s, name=%s", employer_id, name)
        from datetime import datetime, timezone
        doc = {
            "employer_id": employer_id,
            "name": name,
            "description": description or "",
            "candidates": [],
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        inserted_id = await self.adapter.insert_one("talent_pools", doc)
        return str(inserted_id)

    async def add_candidate_to_pool(self, employer_id: str, pool_id: str, candidate_id: str) -> bool:
        log.info("Adding candidate to talent pool | pool_id=%s, candidate_id=%s", pool_id, candidate_id)
        from bson import ObjectId
        try:
            pool = await self.adapter.find_one("talent_pools", {"_id": ObjectId(pool_id), "employer_id": employer_id})
            if not pool:
                return False
            
            # Avoid duplicate candidates
            if candidate_id in pool.get("candidates", []):
                return True
                
            await self.adapter.update_one(
                "talent_pools",
                {"_id": ObjectId(pool_id)},
                {"$addToSet": {"candidates": candidate_id}}
            )
            return True
        except Exception as exc:
            log.error("Failed to add candidate to pool: %s", str(exc))
            return False

