import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from bson import ObjectId

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "applications"


class ApplicationRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")

        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")

        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    # ── Helpers ─────────────────────────────────────────────
    @staticmethod
    def _normalise(doc: Dict[str, Any]) -> Dict[str, Any]:
        """Convert _id → id and return the document."""
        if doc and "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    def _oid_query(self, application_id: str) -> Dict:
        try:
            return {"_id": ObjectId(application_id)}
        except Exception:
            return {"id": application_id}

    # ── CREATE ──────────────────────────────────────────────
    async def insert_one(self, data: Dict[str, Any]) -> str:
        """Insert a new application and return its ID."""
        now = datetime.now(timezone.utc).isoformat()
        data.setdefault("applied_at", now)
        data.setdefault("status", "APPLIED")
        data.setdefault("notes", [])
        data.setdefault("rating", None)
        data.setdefault("stage", "APPLIED")
        data.setdefault("status_history", [{
            "status": "APPLIED",
            "timestamp": now,
            "label": "Application submitted"
        }])
        log.info("Inserting application | job_id=%s, candidate_id=%s", data.get("job_id"), data.get("candidate_id"))
        return await self.adapter.insert_one(COLLECTION, data)

    # ── READ ────────────────────────────────────────────────
    async def find_by_job(self, job_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching applications for job | job_id=%s", job_id)
        results = await self.adapter.find_many(COLLECTION, {"job_id": job_id})
        return [self._normalise(r) for r in results]

    async def find_by_candidate(self, candidate_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching applications for candidate | candidate_id=%s", candidate_id)
        results = await self.adapter.find_many(COLLECTION, {"candidate_id": candidate_id})
        return [self._normalise(r) for r in results]

    async def find_by_id(self, application_id: str) -> Optional[Dict[str, Any]]:
        log.debug("Querying application | application_id=%s", application_id)
        doc = await self.adapter.find_one(COLLECTION, self._oid_query(application_id))
        return self._normalise(doc) if doc else None

    async def exists(self, job_id: str, candidate_id: str) -> bool:
        """Check if a candidate has already applied to a specific job."""
        doc = await self.adapter.find_one(COLLECTION, {"job_id": job_id, "candidate_id": candidate_id})
        return doc is not None

    # ── UPDATE ──────────────────────────────────────────────
    async def update_status(self, application_id: str, status: str) -> int:
        log.info("Updating application status | id=%s, status=%s", application_id, status)
        now = datetime.now(timezone.utc).isoformat()
        return await self.adapter.update_one(
            COLLECTION,
            self._oid_query(application_id),
            {
                "$set": {"status": status, "updated_at": now},
                "$push": {
                    "status_history": {
                        "status": status,
                        "timestamp": now,
                        "label": f"Status changed to {status.replace('_', ' ').capitalize()}"
                    }
                }
            },
        )

    async def update_stage(self, application_id: str, stage: str) -> int:
        log.info("Moving application stage | id=%s, stage=%s", application_id, stage)
        return await self.adapter.update_one(
            COLLECTION,
            self._oid_query(application_id),
            {"stage": stage, "updated_at": datetime.now(timezone.utc).isoformat()},
        )

    async def add_note(self, application_id: str, note: str) -> int:
        log.info("Adding note to application | id=%s", application_id)
        now = datetime.now(timezone.utc).isoformat()
        note_obj = {"text": note, "created_at": now}
        col = self.adapter.get_collection(COLLECTION)
        res = await col.update_one(
            self._oid_query(application_id),
            {"$push": {"notes": note_obj}, "$set": {"updated_at": now}},
        )
        return res.modified_count

    async def update_rating(self, application_id: str, rating: int) -> int:
        log.info("Updating application rating | id=%s, rating=%d", application_id, rating)
        return await self.adapter.update_one(
            COLLECTION,
            self._oid_query(application_id),
            {"rating": rating},
        )

    # ── KPI / AGGREGATION ───────────────────────────────────
    async def count_by_job(self, job_id: str) -> int:
        col = self.adapter.get_collection(COLLECTION)
        return await col.count_documents({"job_id": job_id})

    async def count_by_status(self, job_id: Optional[str] = None) -> Dict[str, int]:
        """Count applications grouped by status, optionally filtered by job_id."""
        match_stage: Dict[str, Any] = {}
        if job_id:
            match_stage["job_id"] = job_id
        pipeline = [
            {"$match": match_stage} if match_stage else {"$match": {}},
            {"$group": {"_id": "$status", "count": {"$sum": 1}}},
        ]
        results = await self.adapter.aggregate(COLLECTION, pipeline)
        return {r["_id"]: r["count"] for r in results if r["_id"]}

    async def get_pipeline_stats(self, employer_id: Optional[str] = None) -> Dict[str, Any]:
        """Return full hiring pipeline stats for the KPI dashboard."""
        # We need to join with jobs to filter by employer
        pipeline: List[Dict[str, Any]] = []
        if employer_id:
            pipeline.append({
                "$lookup": {
                    "from": "jobs",
                    "localField": "job_id",
                    "foreignField": "_id_str",
                    "as": "job_info",
                }
            })
            # Alternative: join by string id
            pipeline = [
                {
                    "$addFields": {
                        "job_oid": {"$toObjectId": "$job_id"},
                    }
                },
                {
                    "$lookup": {
                        "from": "jobs",
                        "localField": "job_oid",
                        "foreignField": "_id",
                        "as": "job_info",
                    }
                },
                {"$match": {"job_info.employer_id": employer_id}},
            ]

        # Status breakdown
        pipeline.append({"$group": {"_id": "$status", "count": {"$sum": 1}}})
        status_results = await self.adapter.aggregate(COLLECTION, pipeline)
        status_counts = {r["_id"]: r["count"] for r in status_results if r["_id"]}

        total = sum(status_counts.values())

        return {
            "total_applications": total,
            "status_breakdown": status_counts,
            "applied": status_counts.get("APPLIED", 0),
            "screening": status_counts.get("SCREENING", 0),
            "shortlisted": status_counts.get("SHORTLISTED", 0),
            "interview_scheduled": status_counts.get("INTERVIEW_SCHEDULED", 0),
            "offered": status_counts.get("OFFERED", 0),
            "hired": status_counts.get("HIRED", 0),
            "rejected": status_counts.get("REJECTED", 0),
        }

    async def get_recent_applications(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Return the most recent applications for the activity feed."""
        col = self.adapter.get_collection(COLLECTION)
        cursor = col.find({}).sort("applied_at", -1).limit(limit)
        results = await cursor.to_list(length=limit)
        return [self._normalise(r) for r in results]
