import os
from typing import Any, Dict, List, Optional
from dotenv import dotenv_values
from hire_pilot.utils.mongodb_adapter import MongoAdapter

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)

MONGO_URI = env.get("MONGODB_URI", "")
MONGO_DB = env.get("DB_NAME", "hire_pilot")


class AnalyticsRepository:
    def __init__(self):
        self.adapter = MongoAdapter(uri=MONGO_URI, db_name=MONGO_DB)

    async def count_applications_for_employer(self, employer_id: str) -> int:
        pipeline = [
            {"$addFields": {"job_oid": {"$toObjectId": "$job_id"}}},
            {"$lookup": {"from": "jobs", "localField": "job_oid", "foreignField": "_id", "as": "job"}},
            {"$match": {"job.employer_id": employer_id}},
            {"$count": "total"},
        ]
        result = await self.adapter.aggregate("applications", pipeline)
        return result[0]["total"] if result else 0

    async def count_views_for_employer(self, employer_id: str) -> int:
        return await self.adapter.count(
            "analytics_events", {"employer_id": employer_id, "event_type": "JOB_VIEW"}
        )

    async def get_hiring_funnel(self, employer_id: str) -> Dict[str, int]:
        pipeline = [
            {"$addFields": {"job_oid": {"$toObjectId": "$job_id"}}},
            {"$lookup": {"from": "jobs", "localField": "job_oid", "foreignField": "_id", "as": "job"}},
            {"$match": {"job.employer_id": employer_id}},
            {"$group": {"_id": "$status", "count": {"$sum": 1}}},
        ]
        results = await self.adapter.aggregate("applications", pipeline)
        return {r["_id"].lower(): r["count"] for r in results if r.get("_id")}

    async def get_time_to_hire(self, employer_id: str) -> Optional[float]:
        pipeline = [
            {"$addFields": {"job_oid": {"$toObjectId": "$job_id"}}},
            {"$lookup": {"from": "jobs", "localField": "job_oid", "foreignField": "_id", "as": "job"}},
            {"$match": {"job.employer_id": employer_id, "status": "HIRED"}},
            {"$unwind": "$status_history"},
            {"$match": {"status_history.status": "HIRED"}},
            {"$sort": {"status_history.timestamp": 1}},
            {
                "$group": {
                    "_id": "$_id",
                    "job_created_at": {"$first": {"$arrayElemAt": ["$job.created_at", 0]}},
                    "hired_at": {"$first": "$status_history.timestamp"},
                }
            },
            {
                "$addFields": {
                    "days_to_hire": {
                        "$divide": [
                            {
                                "$subtract": [
                                    {"$toDate": "$hired_at"},
                                    {"$toDate": "$job_created_at"},
                                ]
                            },
                            86400000,
                        ]
                    }
                }
            },
            {"$match": {"days_to_hire": {"$gt": 0}}},
            {"$group": {"_id": None, "avg_days": {"$avg": "$days_to_hire"}}},
        ]
        result = await self.adapter.aggregate("applications", pipeline)
        return round(result[0]["avg_days"], 2) if result else None

    async def get_total_spend(self, employer_id: str) -> float:
        pipeline = [
            {"$match": {"employer_id": employer_id}},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}},
        ]
        result = await self.adapter.aggregate("invoices", pipeline)
        return result[0]["total"] if result else 0.0

    async def count_hired(self, employer_id: str) -> int:
        pipeline = [
            {"$addFields": {"job_oid": {"$toObjectId": "$job_id"}}},
            {"$lookup": {"from": "jobs", "localField": "job_oid", "foreignField": "_id", "as": "job"}},
            {"$match": {"job.employer_id": employer_id, "status": "HIRED"}},
            {"$count": "total"},
        ]
        result = await self.adapter.aggregate("applications", pipeline)
        return result[0]["total"] if result else 0

    async def get_per_job_stats(self, employer_id: str) -> List[Dict[str, Any]]:
        pipeline = [
            {"$match": {"employer_id": employer_id}},
            {
                "$lookup": {
                    "from": "analytics_events",
                    "let": {"jid": {"$toString": "$_id"}},
                    "pipeline": [
                        {
                            "$match": {
                                "$expr": {
                                    "$and": [
                                        {"$eq": ["$job_id", "$$jid"]},
                                        {"$eq": ["$event_type", "JOB_VIEW"]},
                                    ]
                                }
                            }
                        }
                    ],
                    "as": "view_events",
                }
            },
            {
                "$lookup": {
                    "from": "applications",
                    "let": {"jid": {"$toString": "$_id"}},
                    "pipeline": [
                        {"$match": {"$expr": {"$eq": ["$job_id", "$$jid"]}}}
                    ],
                    "as": "apps",
                }
            },
            {
                "$project": {
                    "job_id": {"$toString": "$_id"},
                    "title": 1,
                    "created_at": 1,
                    "views": {"$size": "$view_events"},
                    "applications": {"$size": "$apps"},
                    "shortlisted": {
                        "$size": {
                            "$filter": {
                                "input": "$apps",
                                "cond": {
                                    "$in": [
                                        "$$this.status",
                                        ["SHORTLISTED", "INTERVIEW_SCHEDULED", "OFFERED", "HIRED"],
                                    ]
                                },
                            }
                        }
                    },
                    "hired": {
                        "$size": {
                            "$filter": {
                                "input": "$apps",
                                "cond": {"$eq": ["$$this.status", "HIRED"]},
                            }
                        }
                    },
                }
            },
        ]
        return await self.adapter.aggregate("jobs", pipeline)

    async def get_interview_stats(self, employer_id: str) -> Dict[str, Any]:
        total = await self.adapter.count("interviews", {"employer_id": employer_id})
        completed = await self.adapter.count(
            "interviews", {"employer_id": employer_id, "status": "FEEDBACK_SUBMITTED"}
        )

        hired_with_interview_pipeline = [
            {"$match": {"employer_id": employer_id, "status": "FEEDBACK_SUBMITTED"}},
            {"$addFields": {"app_oid": {"$toObjectId": "$application_id"}}},
            {
                "$lookup": {
                    "from": "applications",
                    "localField": "app_oid",
                    "foreignField": "_id",
                    "as": "application",
                }
            },
            {"$match": {"application.status": "HIRED"}},
            {"$count": "total"},
        ]
        hired_result = await self.adapter.aggregate("interviews", hired_with_interview_pipeline)
        hired_after_interview = hired_result[0]["total"] if hired_result else 0

        score_pipeline = [
            {
                "$lookup": {
                    "from": "interviews",
                    "let": {"iid": {"$toObjectId": "$interview_id"}},
                    "pipeline": [
                        {"$match": {"$expr": {"$eq": ["$_id", "$$iid"]}}}
                    ],
                    "as": "interview",
                }
            },
            {"$match": {"interview.employer_id": employer_id}},
            {"$group": {"_id": None, "avg": {"$avg": "$rating"}}},
        ]
        score_result = await self.adapter.aggregate("interview_feedback", score_pipeline)
        avg_score = round(score_result[0]["avg"], 2) if score_result else None

        return {
            "total_interviews": total,
            "completed": completed,
            "hired_after_interview": hired_after_interview,
            "avg_feedback_score": avg_score,
        }
