import os
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
from bson import ObjectId

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

INTERVIEWS_COLLECTION = "interviews"
SLOTS_COLLECTION = "interview_slots"
FEEDBACK_COLLECTION = "interview_feedback"


class InterviewRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_by_employer(self, employer_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching interviews for employer | employer_id=%s", employer_id)
        results = await self.adapter.find_many(INTERVIEWS_COLLECTION, {"employer_id": employer_id})
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        return results

    async def find_by_candidate(self, candidate_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching interviews for candidate | candidate_id=%s", candidate_id)
        results = await self.adapter.find_many(INTERVIEWS_COLLECTION, {"candidate_id": candidate_id})
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        # Sort upcoming first
        results.sort(key=lambda x: x.get("scheduled_at", ""))
        return results

    async def insert_interview(self, employer_id: str, data: Dict[str, Any]) -> str:
        log.info("Scheduling interview | employer_id=%s", employer_id)
        data["employer_id"] = employer_id
        data["created_at"] = datetime.now(timezone.utc).isoformat()
        inserted_id = await self.adapter.insert_one(INTERVIEWS_COLLECTION, data)
        return str(inserted_id)

    async def update_interview(self, employer_id: str, interview_id: str, data: Dict[str, Any]) -> bool:
        log.info("Updating interview | id=%s", interview_id)
        try:
            res = await self.adapter.update_one(
                INTERVIEWS_COLLECTION,
                {"_id": ObjectId(interview_id), "employer_id": employer_id},
                data
            )
            return res > 0
        except Exception:
            return False

    async def delete_interview(self, employer_id: str, interview_id: str) -> bool:
        log.info("Cancelling interview | id=%s", interview_id)
        try:
            res = await self.adapter.delete_one(
                INTERVIEWS_COLLECTION,
                {"_id": ObjectId(interview_id), "employer_id": employer_id}
            )
            return res > 0
        except Exception:
            return False

    async def get_slots(self, employer_id: str) -> List[str]:
        log.info("Fetching slots | employer_id=%s", employer_id)
        doc = await self.adapter.find_one(SLOTS_COLLECTION, {"employer_id": employer_id})
        if doc:
            return doc.get("slots", [])
        return []

    async def save_slots(self, employer_id: str, slots: List[str]) -> None:
        log.info("Saving availability slots | employer_id=%s", employer_id)
        existing = await self.adapter.find_one(SLOTS_COLLECTION, {"employer_id": employer_id})
        if existing:
            await self.adapter.update_one(
                SLOTS_COLLECTION,
                {"employer_id": employer_id},
                {"slots": slots}
            )
        else:
            await self.adapter.insert_one(
                SLOTS_COLLECTION,
                {"employer_id": employer_id, "slots": slots}
            )

    async def get_feedback(self, interview_id: str) -> Optional[Dict[str, Any]]:
        log.info("Fetching feedback | interview_id=%s", interview_id)
        res = await self.adapter.find_one(FEEDBACK_COLLECTION, {"interview_id": interview_id})
        if res:
            res["id"] = str(res["_id"])
            del res["_id"]
        return res

    async def update_candidate_response(
        self, interview_id: str, candidate_id: str, candidate_status: str, notes: Optional[str]
    ) -> bool:
        log.info("Recording candidate interview response | id=%s status=%s", interview_id, candidate_status)
        try:
            data = {
                "candidate_status": candidate_status,
                "candidate_notes": notes,
                "responded_at": datetime.now(timezone.utc).isoformat(),
            }
            res = await self.adapter.update_one(
                INTERVIEWS_COLLECTION,
                {"_id": ObjectId(interview_id), "candidate_id": candidate_id},
                data,
            )
            return res > 0
        except Exception:
            return False

    async def insert_feedback(self, interview_id: str, feedback_data: Dict[str, Any]) -> str:
        log.info("Inserting feedback | interview_id=%s", interview_id)
        feedback_data["interview_id"] = interview_id
        feedback_data["created_at"] = datetime.now(timezone.utc).isoformat()
        inserted_id = await self.adapter.insert_one(FEEDBACK_COLLECTION, feedback_data)
        return str(inserted_id)
