import os
from datetime import datetime, timezone
from typing import Dict, List, Optional
from dotenv import dotenv_values
from hire_pilot.utils.mongodb_adapter import MongoAdapter

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)

MONGO_URI = env.get("MONGODB_URI", "")
MONGO_DB = env.get("DB_NAME", "hire_pilot")
COLLECTION = "verifications"


class VerificationRepository:
    def __init__(self):
        self.adapter = MongoAdapter(uri=MONGO_URI, db_name=MONGO_DB)

    async def upsert_verification(
        self,
        employer_id: str,
        verification_type: str,
        document_url: str,
        document_number: Optional[str],
        notes: Optional[str],
    ) -> None:
        data = {
            "employer_id": employer_id,
            "type": verification_type,
            "document_url": document_url,
            "document_number": document_number,
            "notes": notes,
            "status": "PENDING",
            "submitted_at": datetime.now(timezone.utc).isoformat(),
            "reviewed_at": None,
            "reviewer_notes": None,
        }
        await self.adapter.upsert_one(
            COLLECTION,
            {"employer_id": employer_id, "type": verification_type},
            {"$set": data},
        )

    async def find_all_for_employer(self, employer_id: str) -> List[Dict]:
        docs = await self.adapter.find_many(COLLECTION, {"employer_id": employer_id})
        for doc in docs:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return docs

    async def find_by_employer_and_type(
        self, employer_id: str, verification_type: str
    ) -> Optional[Dict]:
        doc = await self.adapter.find_one(
            COLLECTION, {"employer_id": employer_id, "type": verification_type}
        )
        if doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc
