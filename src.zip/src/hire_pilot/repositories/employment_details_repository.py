import os
from typing import Any, Dict, List, Optional

from bson import ObjectId
from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "employment_details"


class EmploymentDetailsRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        log.info("Initializing MongoAdapter for employment details repository.")
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_all_by_user(self, user_id: str, skip: int = 0, limit: int = 20) -> List[Dict[str, Any]]:
        """Retrieve employment details belonging to a user with pagination."""
        log.debug("Querying employment details | user_id=%s, skip=%d, limit=%d", user_id, skip, limit)
        docs = await self.adapter.find_many(COLLECTION, {"user_id": user_id})
        
        # Apply in-memory pagination
        paginated_docs = docs[skip : skip + limit]
        
        for doc in paginated_docs:
            if "_id" in doc:
                doc["id"] = str(doc["_id"])
                del doc["_id"]
        return paginated_docs

    async def find_one_by_id(self, detail_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a single employment detail by its ID, scoped to the user."""
        log.debug("Querying single employment detail | id=%s, user_id=%s", detail_id, user_id)
        doc = await self.adapter.find_one(
            COLLECTION, {"_id": ObjectId(detail_id), "user_id": user_id}
        )
        if doc and "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    async def insert_one(self, user_id: str, data: Dict[str, Any]) -> str:
        """Insert a new employment detail document and return the generated ID."""
        data["user_id"] = user_id
        log.debug("Inserting employment detail | user_id=%s", user_id)
        inserted_id = await self.adapter.insert_one(COLLECTION, data)
        return str(inserted_id)

    async def update_one(self, detail_id: str, user_id: str, data: Dict[str, Any]) -> int:
        """Update an employment detail document. Returns the modified count."""
        log.debug("Updating employment detail | id=%s, user_id=%s", detail_id, user_id)
        return await self.adapter.update_one(
            COLLECTION,
            {"_id": ObjectId(detail_id), "user_id": user_id},
            data,
        )

    async def delete_one(self, detail_id: str, user_id: str) -> int:
        """Delete an employment detail document. Returns the deleted count."""
        log.debug("Deleting employment detail | id=%s, user_id=%s", detail_id, user_id)
        return await self.adapter.delete_one(
            COLLECTION,
            {"_id": ObjectId(detail_id), "user_id": user_id},
        )
