import os
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
from bson import ObjectId

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

MESSAGES_COLLECTION = "messages"
NOTIFICATIONS_COLLECTION = "notifications"
USER_COLLECTION = "users"


class MessagingNotificationsRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def insert_message(self, employer_id: str, candidate_id: str, sender: str, text: str) -> str:
        log.info("Saving message | employer_id=%s, candidate_id=%s, sender=%s", employer_id, candidate_id, sender)
        doc = {
            "employer_id": employer_id,
            "candidate_id": candidate_id,
            "sender": sender,  # "employer" or "candidate"
            "text": text,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        inserted_id = await self.adapter.insert_one(MESSAGES_COLLECTION, doc)
        return str(inserted_id)

    async def find_conversations(self, employer_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching conversations for employer | employer_id=%s", employer_id)
        # Standard aggregation to get unique candidate IDs and their latest message
        pipeline = [
            {"$match": {"employer_id": employer_id}},
            {"$sort": {"timestamp": -1}},
            {
                "$group": {
                    "_id": "$candidate_id",
                    "latest_message": {"$first": "$text"},
                    "latest_timestamp": {"$first": "$timestamp"},
                }
            }
        ]
        groups = await self.adapter.aggregate(MESSAGES_COLLECTION, pipeline)
        
        results = []
        for g in groups:
            cand_id = g["_id"]
            
            # Lookup candidate name
            cand_name = "Candidate"
            cand_email = ""
            try:
                user_doc = await self.adapter.find_one(USER_COLLECTION, {"user_id": cand_id})
                if user_doc:
                    cand_name = f"{user_doc.get('first_name', '')} {user_doc.get('last_name', '')}".strip() or "Candidate"
                    cand_email = user_doc.get("email", "")
            except Exception as e:
                log.warning("Could not lookup candidate details for messaging: %s", str(e))

            results.append({
                "candidate_id": cand_id,
                "candidate_name": cand_name,
                "candidate_email": cand_email,
                "latest_message": g["latest_message"],
                "latest_timestamp": g["latest_timestamp"],
            })
            
        # Sort conversations by latest timestamp descending
        results.sort(key=lambda x: x["latest_timestamp"], reverse=True)
        return results

    async def find_messages(self, employer_id: str, candidate_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching messages between employer=%s and candidate=%s", employer_id, candidate_id)
        results = await self.adapter.find_many(
            MESSAGES_COLLECTION,
            {"employer_id": employer_id, "candidate_id": candidate_id}
        )
        # Sort messages chronologically
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        results.sort(key=lambda x: x["timestamp"])
        return results

    async def find_conversations_by_candidate(self, candidate_id: str) -> List[Dict[str, Any]]:
        """Return unique employer threads where this candidate has messages."""
        log.info("Fetching inbox for candidate | candidate_id=%s", candidate_id)
        pipeline = [
            {"$match": {"candidate_id": candidate_id}},
            {"$sort": {"timestamp": -1}},
            {
                "$group": {
                    "_id": "$employer_id",
                    "latest_message": {"$first": "$text"},
                    "latest_sender": {"$first": "$sender"},
                    "latest_timestamp": {"$first": "$timestamp"},
                }
            }
        ]
        groups = await self.adapter.aggregate(MESSAGES_COLLECTION, pipeline)

        results = []
        for g in groups:
            emp_id = g["_id"]
            emp_name = "Employer"
            emp_email = ""
            try:
                user_doc = await self.adapter.find_one(USER_COLLECTION, {"user_id": emp_id})
                if user_doc:
                    emp_name = f"{user_doc.get('first_name', '')} {user_doc.get('last_name', '')}".strip() or "Employer"
                    emp_email = user_doc.get("email", "")
            except Exception as e:
                log.warning("Could not lookup employer details for candidate inbox: %s", str(e))

            results.append({
                "employer_id": emp_id,
                "employer_name": emp_name,
                "employer_email": emp_email,
                "latest_message": g["latest_message"],
                "latest_sender": g["latest_sender"],
                "latest_timestamp": g["latest_timestamp"],
            })

        results.sort(key=lambda x: x["latest_timestamp"], reverse=True)
        return results

    async def create_notification(self, user_id: str, title: str, message: str, notify_type: str = "general") -> str:
        log.info("Creating notification | user_id=%s, title=%s", user_id, title)
        doc = {
            "user_id": user_id,
            "title": title,
            "message": message,
            "type": notify_type,
            "read": False,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        inserted_id = await self.adapter.insert_one(NOTIFICATIONS_COLLECTION, doc)
        return str(inserted_id)

    async def find_notifications(self, user_id: str) -> List[Dict[str, Any]]:
        log.info("Fetching notifications | user_id=%s", user_id)
        results = await self.adapter.find_many(NOTIFICATIONS_COLLECTION, {"user_id": user_id})
        for res in results:
            res["id"] = str(res["_id"])
            del res["_id"]
        results.sort(key=lambda x: x["created_at"], reverse=True)
        return results

    async def mark_notification_read(self, user_id: str, notification_id: str) -> bool:
        log.info("Marking notification read | id=%s", notification_id)
        try:
            res = await self.adapter.update_one(
                NOTIFICATIONS_COLLECTION,
                {"_id": ObjectId(notification_id), "user_id": user_id},
                {"read": True}
            )
            return res > 0
        except Exception:
            return False
