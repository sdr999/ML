import os
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "users"


class UserRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")


        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        log.info("Initializing MongoAdapter for user repository.")
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def insert_user(self, user_data: Dict[str, Any]) -> str:
        """Insert a new user document and return the generated ID."""
        user_data["created_at"] = datetime.now(timezone.utc).isoformat()
        user_data["updated_at"] = datetime.now(timezone.utc).isoformat()
        log.debug("Inserting user | user_id=%s", user_data.get("user_id"))
        inserted_id = await self.adapter.insert_one(COLLECTION, user_data)
        return str(inserted_id)

    async def find_by_user_id(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Find a user document by their Supabase user_id."""
        log.debug("Querying user | user_id=%s", user_id)
        doc = await self.adapter.find_one(COLLECTION, {"user_id": user_id})
        if doc and "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    async def get_user_role(self, user_id: str) -> Optional[str]:
        """Retrieve only the role for a given user. Returns None if user not found."""
        log.debug("Fetching user role | user_id=%s", user_id)
        doc = await self.adapter.find_one(COLLECTION, {"user_id": user_id})
        if doc:
            return doc.get("role", "employee")
        return None

    async def update_role(self, user_id: str, role: str) -> int:
        """Update the role for a given user. Returns modified count."""
        log.debug("Updating user role | user_id=%s, role=%s", user_id, role)
        return await self.adapter.update_one(
            COLLECTION,
            {"user_id": user_id},
            {"role": role, "updated_at": datetime.now(timezone.utc).isoformat()},
        )
    async def update_user(self, user_id: str, data: Dict[str, Any]) -> int:
        """Update user details for a given user_id."""
        log.debug("Updating user | user_id=%s", user_id)
        data["updated_at"] = datetime.now(timezone.utc).isoformat()
        return await self.adapter.update_one(
            COLLECTION,
            {"user_id": user_id},
            data,
        )
