import os
from typing import Any, Dict, Optional

from bson import ObjectId
from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "basic_info"


class BasicInfoRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        log.info("Initializing MongoAdapter for basic_info repository.")
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_one_by_user(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve basic info for a user."""
        log.debug("Querying basic info | user_id=%s", user_id)
        doc = await self.adapter.find_one(
            COLLECTION, {"user_id": user_id}
        )
        if doc and "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    async def insert_one(self, user_id: str, data: Dict[str, Any]) -> str:
        """Insert a new basic info document and return the generated ID."""
        data["user_id"] = user_id
        log.debug("Inserting basic info | user_id=%s", user_id)
        inserted_id = await self.adapter.insert_one(COLLECTION, data)
        return str(inserted_id)

    async def update_one_by_user(self, user_id: str, data: Dict[str, Any]) -> int:
        """Update basic info for a user."""
        log.debug("Updating basic info | user_id=%s", user_id)
        return await self.adapter.update_one(
            COLLECTION,
            {"user_id": user_id},
            data,
        )
