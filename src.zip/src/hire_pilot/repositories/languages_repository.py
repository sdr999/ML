import os
from typing import Any, Dict, List, Optional

from bson import ObjectId
from hire_pilot.utils.logger import log
from hire_pilot.utils.mongodb_adapter import MongoAdapter
from dotenv import dotenv_values, load_dotenv

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

COLLECTION = "languages"


class LanguagesRepository:
    def __init__(self):
        mongo_uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        mongo_db = env.get("DB_NAME", "hire_pilot")
        
        
        if not mongo_uri or not mongo_db:
            log.error("MongoDB credentials not found in environment variables.")
            raise ValueError("MongoDB credentials missing.")
        log.info("Initializing MongoAdapter for languages repository.")
        self.adapter = MongoAdapter(uri=mongo_uri, db_name=mongo_db)

    async def find_all_by_user(self, user_id: str) -> List[Dict[str, Any]]:
        """Retrieve all languages belonging to a user."""
        log.debug("Querying languages | user_id=%s", user_id)
        docs = await self.adapter.find_many(COLLECTION, {"user_id": user_id})
        for doc in docs:
            if "_id" in doc:
                doc["id"] = str(doc["_id"])
                del doc["_id"]
        return docs

    async def find_one_by_id(self, language_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a single language by its ID, scoped to the user."""
        log.debug("Querying single language | id=%s, user_id=%s", language_id, user_id)
        doc = await self.adapter.find_one(
            COLLECTION, {"_id": ObjectId(language_id), "user_id": user_id}
        )
        if doc and "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        return doc

    async def insert_one(self, user_id: str, data: Dict[str, Any]) -> str:
        """Insert a new language document and return the generated ID."""
        data["user_id"] = user_id
        log.debug("Inserting language | user_id=%s", user_id)
        inserted_id = await self.adapter.insert_one(COLLECTION, data)
        return str(inserted_id)

    async def update_one(self, language_id: str, user_id: str, data: Dict[str, Any]) -> int:
        """Update a language document. Returns the modified count."""
        log.debug("Updating language | id=%s, user_id=%s", language_id, user_id)
        return await self.adapter.update_one(
            COLLECTION,
            {"_id": ObjectId(language_id), "user_id": user_id},
            data,
        )

    async def delete_one(self, language_id: str, user_id: str) -> int:
        """Delete a language document. Returns the deleted count."""
        log.debug("Deleting language | id=%s, user_id=%s", language_id, user_id)
        return await self.adapter.delete_one(
            COLLECTION,
            {"_id": ObjectId(language_id), "user_id": user_id},
        )
