# coding: utf-8

from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
import uuid
from hire_pilot.utils.logger import trace_id_var, log
from hire_pilot.utils.mongo_pool import ensure_indexes, close_mongo_connection
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.apis.achievements_api import router as AchievementsApiRouter
from hire_pilot.apis.authentication_api import router as AuthenticationApiRouter
from hire_pilot.apis.basic_info_api import router as BasicInfoApiRouter
from hire_pilot.apis.certifications_api import router as CertificationsApiRouter
from hire_pilot.apis.diversity_api import router as DiversityApiRouter
from hire_pilot.apis.education_api import router as EducationApiRouter
from hire_pilot.apis.employment_details_api import router as EmploymentDetailsApiRouter
from hire_pilot.apis.languages_api import router as LanguagesApiRouter
from hire_pilot.apis.metadata_api import router as MetadataApiRouter
from hire_pilot.apis.personal_projects_api import router as PersonalProjectsApiRouter
from hire_pilot.apis.profile_operations_api import router as ProfileOperationsApiRouter
from hire_pilot.apis.profile_photo_api import router as ProfilePhotoApiRouter
from hire_pilot.apis.skills_api import router as SkillsApiRouter
from hire_pilot.apis.summary_api import router as SummaryApiRouter
from hire_pilot.apis.work_experience_api import router as WorkExperienceApiRouter
from hire_pilot.apis.employer_profile_api import router as EmployerProfileApiRouter
from hire_pilot.apis.employer_auth_api import router as EmployerAuthApiRouter
from hire_pilot.apis.candidate_search_api import router as CandidateSearchApiRouter
from hire_pilot.apis.job_management_api import router as JobManagementApiRouter
from hire_pilot.apis.applications_ats_api import router as ApplicationsATSApiRouter
from hire_pilot.apis.team_management_api import router as TeamManagementApiRouter
from hire_pilot.apis.interview_management_api import router as InterviewManagementApiRouter
from hire_pilot.apis.messaging_notifications_api import router as MessagingNotificationsApiRouter
from hire_pilot.apis.subscription_billing_api import router as SubscriptionBillingApiRouter
from hire_pilot.apis.analytics_api import router as AnalyticsApiRouter
from hire_pilot.apis.verification_api import router as VerificationApiRouter
from hire_pilot.apis.compliance_api import router as ComplianceApiRouter
from supabase import create_client, Client
from dotenv import load_dotenv, dotenv_values
import os

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),'config','.env')
env = dotenv_values(dotenv_path = env_path)
load_dotenv(dotenv_path = env_path)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: warm up connections + indexes on startup, clean up on shutdown."""
    log.info("HirePilot startup — initialising MongoDB pool & indexes…")
    try:
        await ensure_indexes()
        log.info("Startup complete.")
    except Exception as exc:
        log.error("Startup index creation failed (non-fatal): %s", exc)
    yield
    log.info("HirePilot shutdown — closing MongoDB pool…")
    await close_mongo_connection()


app = FastAPI(
    title="Hire Pilot",
    description="Career Identity &amp; Profile Management AP",
    version="1.0.0",
    lifespan=lifespan,
)

class TraceMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        trace_id = str(uuid.uuid4())
        token = trace_id_var.set(trace_id)
        
        # Skip logging for healthchecks or root if needed, but let's log everything for now
        log.info("Incoming request | method=%s, path=%s", request.method, request.url.path)
        
        try:
            response = await call_next(request)
            response.headers["X-Trace-Id"] = trace_id
            return response
        finally:
            log.info("Request completed | method=%s, path=%s", request.method, request.url.path)
            trace_id_var.reset(token)

from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# Compress responses >1KB — huge win for job listings / candidate search payloads
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(TraceMiddleware)


@app.get("/health", tags=["Health"], include_in_schema=False)
async def health_check():
    """Lightweight health probe for load balancers / uptime monitors."""
    return {"status": "ok"}

SUPABASE_URL = env.get("SUPABASE_URL")
SUPABASE_KEY = env.get("SUPABASE_KEY")
if not SUPABASE_URL or not SUPABASE_KEY:
    log.warning("Supabase credentials not found in main.py")
else:
    log.info("Initializing global Supabase client in main.py")
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)



@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    error_code = "error"
    if exc.status_code == 400:
        error_code = "bad_request"
    elif exc.status_code == 401:
        error_code = "unauthorized"
    elif exc.status_code == 403:
        error_code = "forbidden"
    elif exc.status_code == 404:
        error_code = "not_found"
    elif exc.status_code == 500:
        error_code = "internal_error"
        
    error_response = ErrorResponse(
        error=error_code,
        message=str(exc.detail)
    )
    return JSONResponse(
        status_code=exc.status_code,
        content=error_response.model_dump(by_alias=True, exclude_none=True)
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    details = []
    for error in exc.errors():
        loc = " -> ".join([str(l) for l in error.get("loc", [])])
        details.append(f"{loc}: {error.get('msg')}")
        
    error_response = ErrorResponse(
        error="validation_error",
        message="Invalid request parameters",
        details=details
    )
    return JSONResponse(
        status_code=422,
        content=error_response.model_dump(by_alias=True, exclude_none=True)
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    log.exception("Unhandled global exception")
    error_response = ErrorResponse(
        error="internal_server_error",
        message="An unexpected error occurred."
    )
    return JSONResponse(
        status_code=500,
        content=error_response.model_dump(by_alias=True, exclude_none=True)
    )

app.include_router(AchievementsApiRouter)
app.include_router(AuthenticationApiRouter)
app.include_router(BasicInfoApiRouter)
app.include_router(CertificationsApiRouter)
app.include_router(DiversityApiRouter)
app.include_router(EducationApiRouter)
app.include_router(EmploymentDetailsApiRouter)
app.include_router(LanguagesApiRouter)
app.include_router(MetadataApiRouter)
app.include_router(PersonalProjectsApiRouter)
app.include_router(ProfileOperationsApiRouter)
app.include_router(ProfilePhotoApiRouter)
app.include_router(SkillsApiRouter)
app.include_router(SummaryApiRouter)
app.include_router(WorkExperienceApiRouter)
app.include_router(EmployerProfileApiRouter)
app.include_router(EmployerAuthApiRouter)
app.include_router(CandidateSearchApiRouter)
app.include_router(JobManagementApiRouter)
app.include_router(ApplicationsATSApiRouter)
app.include_router(TeamManagementApiRouter)
app.include_router(InterviewManagementApiRouter)
app.include_router(MessagingNotificationsApiRouter)
app.include_router(SubscriptionBillingApiRouter)
app.include_router(AnalyticsApiRouter)
app.include_router(VerificationApiRouter)
app.include_router(ComplianceApiRouter)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)