# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field
from typing import Any, List, Optional
from typing_extensions import Annotated
from uuid import UUID
from hire_pilot.models.job import Job
from hire_pilot.models.job_input import JobInput
from hire_pilot.security_api import get_token_bearerAuth

class BaseJobManagementApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseJobManagementApi.subclasses = BaseJobManagementApi.subclasses + (cls,)
    async def employer_jobs_recommendations_get(
        self,
        page: int,
        limit: int,
    ) -> List[Job]:
        ...


    async def employer_jobs_get(
        self,
        page: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page number for pagination")],
        limit: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="Number of items to return per page")],
    ) -> List[Job]:
        ...


    async def employer_jobs_post(
        self,
        job_input: JobInput,
    ) -> None:
        ...


    async def employer_jobs_job_id_get(
        self,
        jobId: str,
    ) -> Job:
        ...


    async def employer_jobs_job_id_put(
        self,
        jobId: str,
        job_input: JobInput,
    ) -> None:
        ...


    async def employer_jobs_job_id_delete(
        self,
        jobId: str,
    ) -> None:
        ...


    async def employer_jobs_job_id_publish_patch(
        self,
        jobId: str,
    ) -> None:
        ...


    async def employer_jobs_job_id_pause_patch(
        self,
        jobId: str,
    ) -> None:
        ...


    async def employer_jobs_job_id_close_patch(
        self,
        jobId: str,
    ) -> None:
        ...


    async def employer_jobs_job_id_archive_patch(
        self,
        jobId: str,
    ) -> None:
        ...


    async def employer_jobs_job_id_duplicate_post(
        self,
        jobId: str,
    ) -> None:
        ...


    async def employer_jobs_job_id_repost_post(
        self,
        jobId: str,
    ) -> None:
        ...


    async def employer_jobs_job_id_boost_post(
        self,
        jobId: str,
    ) -> None:
        ...


    async def employer_jobs_job_id_feature_post(
        self,
        jobId: str,
    ) -> None:
        ...


    async def employer_job_templates_get(
        self,
    ) -> None:
        ...


    async def employer_job_templates_post(
        self,
    ) -> None:
        ...


    async def employer_job_templates_id_put(
        self,
        id: Annotated[str, Field(description="The UUID of the specific resource")],
    ) -> None:
        ...


    async def employer_job_templates_id_delete(
        self,
        id: Annotated[str, Field(description="The UUID of the specific resource")],
    ) -> None:
        ...
