# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.metadata_api_base import BaseMetadataApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import StrictStr
from typing import Any, List


router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/metadata/degrees",
    responses={
        200: {"description": "Array of degree names"},
    },
    tags=["Metadata"],
    summary="Get all available degrees",
    response_model_by_alias=True,
)
async def metadata_degrees_get(
) -> None:
    if not BaseMetadataApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMetadataApi.subclasses[0]().metadata_degrees_get()


@router.get(
    "/metadata/locations",
    responses={
        200: {"description": "Array of locations"},
    },
    tags=["Metadata"],
    summary="Get all available locations",
    response_model_by_alias=True,
)
async def metadata_locations_get(
) -> None:
    if not BaseMetadataApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMetadataApi.subclasses[0]().metadata_locations_get()


@router.get(
    "/metadata/skills",
    responses={
        200: {"model": List[str], "description": "Array of skill names"},
    },
    tags=["Metadata"],
    summary="Get all available skills",
    response_model_by_alias=True,
)
async def metadata_skills_get(
) -> List[str]:
    if not BaseMetadataApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMetadataApi.subclasses[0]().metadata_skills_get()
