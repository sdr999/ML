# coding: utf-8

from typing import Any, Dict, List, Optional  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.analytics_api_base import BaseAnalyticsApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    HTTPException,
    Security,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from hire_pilot.models.dashboard_metrics import DashboardMetrics
from hire_pilot.models.interview_report import InterviewReport
from hire_pilot.models.job_report import JobReport
from hire_pilot.models.analytics_event_input import AnalyticsEventInput
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/employer/dashboard",
    responses={200: {"model": DashboardMetrics, "description": "Dashboard metrics"}},
    tags=["Analytics"],
    summary="Get Employer Dashboard Metrics",
    response_model_by_alias=True,
)
async def employer_dashboard_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> DashboardMetrics:
    if not BaseAnalyticsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAnalyticsApi.subclasses[0]().employer_dashboard_get()


@router.get(
    "/employer/reports/jobs",
    responses={200: {"model": List[JobReport], "description": "Job-level report"}},
    tags=["Analytics"],
    summary="Get Jobs Report",
    response_model_by_alias=True,
)
async def employer_reports_jobs_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> List[JobReport]:
    if not BaseAnalyticsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAnalyticsApi.subclasses[0]().employer_reports_jobs_get()


@router.get(
    "/employer/reports/candidates",
    responses={200: {"description": "Candidate pipeline funnel breakdown"}},
    tags=["Analytics"],
    summary="Get Candidates Report",
    response_model_by_alias=True,
)
async def employer_reports_candidates_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Dict[str, Any]:
    if not BaseAnalyticsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAnalyticsApi.subclasses[0]().employer_reports_candidates_get()


@router.get(
    "/employer/reports/interviews",
    responses={200: {"model": InterviewReport, "description": "Interview statistics"}},
    tags=["Analytics"],
    summary="Get Interviews Report",
    response_model_by_alias=True,
)
async def employer_reports_interviews_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> InterviewReport:
    if not BaseAnalyticsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAnalyticsApi.subclasses[0]().employer_reports_interviews_get()


@router.post(
    "/analytics/events",
    responses={201: {"description": "Event recorded"}},
    tags=["Analytics"],
    summary="Record an Analytics Event (job view, click, apply-start)",
    response_model_by_alias=True,
    status_code=201,
)
async def analytics_event_post(
    body: AnalyticsEventInput = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Dict[str, str]:
    if not BaseAnalyticsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAnalyticsApi.subclasses[0]().analytics_event_post(
        body.event_type, body.job_id, body.employer_id, body.metadata
    )
