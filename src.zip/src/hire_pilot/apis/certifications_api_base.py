# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field, StrictStr
from typing import Any, List, Any 
from typing_extensions import Annotated
from hire_pilot.models.certification import Certification
from hire_pilot.models.certification_input import CertificationInput
from hire_pilot.security_api import get_token_bearerAuth

class BaseCertificationsApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseCertificationsApi.subclasses = BaseCertificationsApi.subclasses + (cls,)
    async def profile_certifications_get(
        self,
    ) -> List[Certification]:
        ...


    async def profile_certifications_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        ...


    async def profile_certifications_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Certification:
        ...


    async def profile_certifications_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        certification_input: CertificationInput,
    ) -> Any:
        ...


    async def profile_certifications_post(
        self,
        certification_input: CertificationInput,
    ) -> Any:
        ...
