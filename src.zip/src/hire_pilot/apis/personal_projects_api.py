# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.personal_projects_api_base import BasePersonalProjectsApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import Field, StrictStr
from typing import Any, List
from hire_pilot.models.error_response import ErrorResponse
from typing_extensions import Annotated
from hire_pilot.models.personal_project import PersonalProject
from hire_pilot.models.personal_project_input import PersonalProjectInput
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/projects",
    responses={
        200: {"model": List[PersonalProject], "description": "List of projects"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Personal Projects"],
    summary="Get all projects",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_projects_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[PersonalProject]:
    if not BasePersonalProjectsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BasePersonalProjectsApi.subclasses[0]().profile_projects_get()


@router.delete(
    "/profile/projects/{id}",
    responses={
        200: {"description": "Deleted"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Project not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Personal Projects"],
    summary="Delete project",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_projects_id_delete(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BasePersonalProjectsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BasePersonalProjectsApi.subclasses[0]().profile_projects_id_delete(id)


@router.get(
    "/profile/projects/{id}",
    responses={
        200: {"model": PersonalProject, "description": "Project detail"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Project not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Personal Projects"],
    summary="Get specific project",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_projects_id_get(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> PersonalProject:
    if not BasePersonalProjectsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BasePersonalProjectsApi.subclasses[0]().profile_projects_id_get(id)


@router.put(
    "/profile/projects/{id}",
    responses={
        200: {"description": "Updated"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Project not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Personal Projects"],
    summary="Update project",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_projects_id_put(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    personal_project_input: PersonalProjectInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BasePersonalProjectsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BasePersonalProjectsApi.subclasses[0]().profile_projects_id_put(id, personal_project_input)


@router.post(
    "/profile/projects",
    responses={
        201: {"description": "Created"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Personal Projects"],
    summary="Add project",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def profile_projects_post(
    personal_project_input: PersonalProjectInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BasePersonalProjectsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BasePersonalProjectsApi.subclasses[0]().profile_projects_post(personal_project_input)
