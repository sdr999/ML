# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field, StrictStr
from typing import Any, List
from typing_extensions import Annotated
from hire_pilot.models.achievement import Achievement
from hire_pilot.models.achievement_input import AchievementInput
from hire_pilot.security_api import get_token_bearerAuth

class BaseAchievementsApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseAchievementsApi.subclasses = BaseAchievementsApi.subclasses + (cls,)
    async def profile_achievements_get(
        self,
    ) -> List[Achievement]:
        ...


    async def profile_achievements_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        ...


    async def profile_achievements_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Achievement:
        ...


    async def profile_achievements_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        achievement_input: AchievementInput,
    ) -> Any:
        ...


    async def profile_achievements_post(
        self,
        achievement_input: AchievementInput,
    ) -> Any:
        ...
