# coding: utf-8

from typing import Dict, List, Any, Optional
from hire_pilot.models.interview_response import InterviewResponseInput
import importlib
import pkgutil

from hire_pilot.apis.interview_management_api_base import BaseInterviewManagementApi
import hire_pilot.impl

from fastapi import (
    APIRouter,
    Body,
    HTTPException,
    Path,
    Query,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/employer/interviews",
    responses={
        200: {"description": "List of interviews"},
    },
    tags=["Interviews"],
    summary="List Interviews",
)
async def employer_interviews_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().employer_interviews_get()


@router.post(
    "/employer/interviews",
    responses={
        201: {"description": "Interview scheduled"},
    },
    tags=["Interviews"],
    summary="Schedule Interview",
)
async def employer_interviews_post(
    candidate_id: str = Body(..., embed=True),
    job_id: str = Body(..., embed=True),
    scheduled_at: str = Body(..., embed=True),
    duration_minutes: int = Body(..., embed=True),
    title: str = Body(..., embed=True),
    description: Optional[str] = Body(None, embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().employer_interviews_post(
        candidate_id, job_id, scheduled_at, duration_minutes, title, description
    )


@router.put(
    "/employer/interviews/{id}",
    responses={
        200: {"description": "Interview updated"},
    },
    tags=["Interviews"],
    summary="Reschedule Interview",
)
async def employer_interviews_id_put(
    id: str = Path(..., description="The interview UUID"),
    scheduled_at: str = Body(..., embed=True),
    duration_minutes: Optional[int] = Body(None, embed=True),
    title: Optional[str] = Body(None, embed=True),
    description: Optional[str] = Body(None, embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().employer_interviews_id_put(
        id, scheduled_at, duration_minutes, title, description
    )


@router.delete(
    "/employer/interviews/{id}",
    responses={
        204: {"description": "Interview cancelled"},
    },
    tags=["Interviews"],
    summary="Cancel Interview",
)
async def employer_interviews_id_delete(
    id: str = Path(..., description="The interview UUID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().employer_interviews_id_delete(id)


@router.get(
    "/employer/interviews/slots",
    responses={
        200: {"description": "Available slots"},
    },
    tags=["Interviews"],
    summary="Get Interviewer Slots",
)
async def employer_interviews_slots_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().employer_interviews_slots_get()


@router.post(
    "/employer/interviews/slots",
    responses={
        201: {"description": "Slots added"},
    },
    tags=["Interviews"],
    summary="Add Availability Slots",
)
async def employer_interviews_slots_post(
    slots: List[str] = Body(..., embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().employer_interviews_slots_post(slots)


@router.get(
    "/employer/interviews/{id}/feedback",
    responses={
        200: {"description": "Feedback retrieved"},
    },
    tags=["Interviews"],
    summary="Get Interview Feedback",
)
async def employer_interviews_id_feedback_get(
    id: str = Path(..., description="The interview UUID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().employer_interviews_id_feedback_get(id)


@router.post(
    "/employer/interviews/{id}/feedback",
    responses={
        201: {"description": "Feedback submitted"},
    },
    tags=["Interviews"],
    summary="Submit Interview Feedback",
)
async def employer_interviews_id_feedback_post(
    id: str = Path(..., description="The interview UUID"),
    rating: int = Body(..., embed=True),
    comments: str = Body(..., embed=True),
    recommendation: str = Body(..., embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().employer_interviews_id_feedback_post(
        id, rating, comments, recommendation
    )


@router.get(
    "/candidate/interviews",
    responses={200: {"description": "Candidate's interview schedule"}},
    tags=["Interviews"],
    summary="Candidate: List My Interviews",
)
async def candidate_interviews_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().candidate_interviews_get()


@router.patch(
    "/candidate/interviews/{interviewId}/respond",
    responses={200: {"description": "Interview response recorded"}},
    tags=["Interviews"],
    summary="Candidate: Confirm or Decline Interview",
)
async def candidate_interview_respond_patch(
    interviewId: str = Path(..., description="Interview ID"),
    body: InterviewResponseInput = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseInterviewManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseInterviewManagementApi.subclasses[0]().candidate_interview_respond_patch(
        interviewId, body.status.value, body.notes
    )
