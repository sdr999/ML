# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field, StrictStr
from typing import Any, List, Optional
from typing_extensions import Annotated
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.models.work_experience import WorkExperience
from hire_pilot.models.work_experience_input import WorkExperienceInput
from hire_pilot.security_api import get_token_bearerAuth

class BaseWorkExperienceApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseWorkExperienceApi.subclasses = BaseWorkExperienceApi.subclasses + (cls,)
    async def profile_work_experience_get(
        self,
        page: Annotated[Optional[Annotated[int, Field(ge=1)]], Field(description="Page number for pagination")],
        limit: Annotated[Optional[Annotated[int, Field(le=100, ge=1)]], Field(description="Number of items to return per page")],
    ) -> List[WorkExperience]:
        ...


    async def profile_work_experience_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        ...


    async def profile_work_experience_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> WorkExperience:
        ...


    async def profile_work_experience_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        work_experience_input: WorkExperienceInput,
    ) -> Any:
        ...


    async def profile_work_experience_post(
        self,
        work_experience_input: WorkExperienceInput,
    ) -> Any:
        ...
