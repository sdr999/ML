# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.models.profile_resume_parse_post_request import ProfileResumeParsePostRequest
from hire_pilot.security_api import get_token_bearerAuth

class BaseProfileOperationsApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseProfileOperationsApi.subclasses = BaseProfileOperationsApi.subclasses + (cls,)
    async def profile_resume_parse_post(
        self,
        profile_resume_parse_post_request: ProfileResumeParsePostRequest,
    ) -> Any:
        ...

    async def profile_details_get(self) -> Any:
        ...

    async def resume_download_get(self) -> Any:
        ...

    async def resume_generate_post(self) -> Any:
        ...

    async def profile_completion_get(self) -> Any:
        ...
