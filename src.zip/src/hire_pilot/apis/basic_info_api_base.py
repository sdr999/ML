# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any
from hire_pilot.models.basic_info import BasicInfo
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.security_api import get_token_bearerAuth

class BaseBasicInfoApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseBasicInfoApi.subclasses = BaseBasicInfoApi.subclasses + (cls,)
    async def profile_basic_info_get(
        self,
    ) -> BasicInfo:
        ...


    async def profile_basic_info_put(
        self,
        basic_info: BasicInfo,
    ) -> None:
        ...
