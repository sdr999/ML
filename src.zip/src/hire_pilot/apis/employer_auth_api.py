# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.employer_auth_api_base import BaseEmployerAuthApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from typing import Any
from hire_pilot.models.auth_response import AuthResponse
from hire_pilot.models.employer_register_request import EmployerRegisterRequest
from hire_pilot.models.sign_in_request import SignInRequest
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.post(
    "/employer/auth/register",
    responses={
        201: {"description": "Employer registered successfully"},
    },
    tags=["Employer Auth"],
    summary="Employer Registration",
    response_model_by_alias=True,
)
async def employer_auth_register_post(
    employer_register_request: EmployerRegisterRequest = Body(None, description=""),
) -> None:
    if not BaseEmployerAuthApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerAuthApi.subclasses[0]().employer_auth_register_post(employer_register_request)


@router.post(
    "/employer/auth/login",
    responses={
        200: {"model": AuthResponse, "description": "Successful login"},
    },
    tags=["Employer Auth"],
    summary="Employer Login",
    response_model_by_alias=True,
)
async def employer_auth_login_post(
    sign_in_request: SignInRequest = Body(None, description=""),
) -> AuthResponse:
    if not BaseEmployerAuthApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerAuthApi.subclasses[0]().employer_auth_login_post(sign_in_request)


@router.post(
    "/employer/auth/logout",
    responses={
        204: {"description": "Logged out"},
    },
    tags=["Employer Auth"],
    summary="Employer Logout",
    response_model_by_alias=True,
)
async def employer_auth_logout_post(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseEmployerAuthApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerAuthApi.subclasses[0]().employer_auth_logout_post()


@router.post(
    "/employer/auth/refresh-token",
    responses={
        200: {"description": "Token refreshed"},
    },
    tags=["Employer Auth"],
    summary="Refresh Auth Token",
    response_model_by_alias=True,
)
async def employer_auth_refresh_token_post(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseEmployerAuthApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerAuthApi.subclasses[0]().employer_auth_refresh_token_post()


@router.post(
    "/employer/auth/forgot-password",
    responses={
        200: {"description": "Reset email sent"},
    },
    tags=["Employer Auth"],
    summary="Forgot Password",
    response_model_by_alias=True,
)
async def employer_auth_forgot_password_post(
) -> None:
    if not BaseEmployerAuthApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerAuthApi.subclasses[0]().employer_auth_forgot_password_post()


@router.post(
    "/employer/auth/reset-password",
    responses={
        200: {"description": "Password reset successful"},
    },
    tags=["Employer Auth"],
    summary="Reset Password",
    response_model_by_alias=True,
)
async def employer_auth_reset_password_post(
) -> None:
    if not BaseEmployerAuthApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerAuthApi.subclasses[0]().employer_auth_reset_password_post()


@router.post(
    "/employer/auth/verify-email",
    responses={
        200: {"description": "Email verified"},
    },
    tags=["Employer Auth"],
    summary="Verify Email",
    response_model_by_alias=True,
)
async def employer_auth_verify_email_post(
) -> None:
    if not BaseEmployerAuthApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerAuthApi.subclasses[0]().employer_auth_verify_email_post()
