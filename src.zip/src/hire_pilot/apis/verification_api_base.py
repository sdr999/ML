# coding: utf-8

from typing import ClassVar, List, Tuple
from hire_pilot.models.verification_request import VerificationSubmitRequest
from hire_pilot.models.verification_status import VerificationStatus


class BaseVerificationApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseVerificationApi.subclasses = BaseVerificationApi.subclasses + (cls,)

    async def employer_verification_pan_post(
        self, body: VerificationSubmitRequest
    ) -> VerificationStatus:
        ...

    async def employer_verification_gst_post(
        self, body: VerificationSubmitRequest
    ) -> VerificationStatus:
        ...

    async def employer_verification_company_docs_post(
        self, body: VerificationSubmitRequest
    ) -> VerificationStatus:
        ...

    async def employer_verification_status_get(self) -> List[VerificationStatus]:
        ...
