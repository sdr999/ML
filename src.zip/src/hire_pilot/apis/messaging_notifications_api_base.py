# coding: utf-8

from typing import ClassVar, Dict, List, Tuple, Any, Optional

class BaseMessagingNotificationsApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseMessagingNotificationsApi.subclasses = BaseMessagingNotificationsApi.subclasses + (cls,)

    async def employer_messages_post(
        self,
        candidate_id: str,
        message: str
    ) -> Any:
        ...

    async def employer_conversations_get(self) -> Any:
        ...

    async def employer_conversations_id_get(self, id: str) -> Any:
        ...

    async def employer_communications_email_post(
        self,
        candidate_ids: List[str],
        subject: str,
        body: str
    ) -> Any:
        ...

    async def employer_communications_sms_post(
        self,
        candidate_id: str,
        message: str
    ) -> Any:
        ...

    async def employer_notifications_get(self) -> Any:
        ...

    async def employer_notifications_id_read_patch(self, id: str) -> Any:
        ...

    # ── Candidate-facing ──────────────────────────────────────────

    async def candidate_inbox_get(self) -> Any:
        ...

    async def candidate_inbox_employer_get(self, employer_id: str) -> Any:
        ...

    async def candidate_inbox_reply_post(self, employer_id: str, message: str) -> Any:
        ...

    async def candidate_notifications_get(self) -> Any:
        ...

    async def candidate_notifications_read_patch(self, id: str) -> Any:
        ...
