# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field, StrictStr
from typing import Any, List, Optional
from typing_extensions import Annotated
from hire_pilot.models.employment_detail import EmploymentDetail
from hire_pilot.models.employment_detail_input import EmploymentDetailInput
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.security_api import get_token_bearerAuth

class BaseEmploymentDetailsApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseEmploymentDetailsApi.subclasses = BaseEmploymentDetailsApi.subclasses + (cls,)
    async def profile_employment_details_get(
        self,
        page: Annotated[Optional[Annotated[int, Field(ge=1)]], Field(description="Page number for pagination")],
        limit: Annotated[Optional[Annotated[int, Field(le=100, ge=1)]], Field(description="Number of items to return per page")],
    ) -> List[EmploymentDetail]:
        ...


    async def profile_employment_details_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        ...


    async def profile_employment_details_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> EmploymentDetail:
        ...


    async def profile_employment_details_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        employment_detail_input: EmploymentDetailInput,
    ) -> Any:
        ...


    async def profile_employment_details_post(
        self,
        employment_detail_input: EmploymentDetailInput,
    ) -> Any:
        ...
