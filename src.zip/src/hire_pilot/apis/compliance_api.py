# coding: utf-8

from typing import List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.compliance_api_base import BaseComplianceApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    HTTPException,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from hire_pilot.models.moderation_report import ModerationReport, ReportCandidateRequest
from hire_pilot.models.policy import Policy
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/employer/policies",
    responses={200: {"model": List[Policy], "description": "Platform policies"}},
    tags=["Admin/Moderation"],
    summary="Get Platform Policies",
    response_model_by_alias=True,
)
async def employer_policies_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> List[Policy]:
    if not BaseComplianceApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseComplianceApi.subclasses[0]().employer_policies_get()


@router.post(
    "/employer/report-candidate",
    responses={201: {"model": ModerationReport, "description": "Candidate reported"}},
    tags=["Admin/Moderation"],
    summary="Report a Candidate",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def employer_report_candidate_post(
    body: ReportCandidateRequest = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> ModerationReport:
    if not BaseComplianceApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseComplianceApi.subclasses[0]().employer_report_candidate_post(body)
