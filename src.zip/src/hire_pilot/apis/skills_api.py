# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.skills_api_base import BaseSkillsApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import StrictStr
from typing import Any, List
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/skills",
    responses={
        200: {"model": List[str], "description": "Skills retrieved"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Skills"],
    summary="Get user skills",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_skills_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[str]:
    if not BaseSkillsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSkillsApi.subclasses[0]().profile_skills_get()


@router.put(
    "/profile/skills",
    responses={
        200: {"description": "Skills updated"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Skills"],
    summary="Replace all user skills",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_skills_put(
    request_body: List[StrictStr] = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseSkillsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSkillsApi.subclasses[0]().profile_skills_put(request_body)
