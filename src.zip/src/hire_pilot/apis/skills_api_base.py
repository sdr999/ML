# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import StrictStr
from typing import Any, List
from hire_pilot.security_api import get_token_bearerAuth

class BaseSkillsApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseSkillsApi.subclasses = BaseSkillsApi.subclasses + (cls,)
    async def profile_skills_get(
        self,
    ) -> List[str]:
        ...


    async def profile_skills_put(
        self,
        request_body: List[StrictStr],
    ) -> Any:
        ...
