# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any
from hire_pilot.models.auth_response import AuthResponse
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.models.sign_in_request import SignInRequest
from hire_pilot.models.sign_up_request import SignUpRequest


class BaseAuthenticationApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseAuthenticationApi.subclasses = BaseAuthenticationApi.subclasses + (cls,)
    async def auth_signin_post(
        self,
        sign_in_request: SignInRequest,
    ) -> AuthResponse:
        ...


    async def auth_signup_post(
        self,
        sign_up_request: SignUpRequest,
    ) -> Any:
        ...

    async def auth_refresh_post(
        self,
        refresh_token: str,
    ) -> AuthResponse:
        ...

    async def auth_forgot_password_post(
        self,
        email: str,
        redirect_to: str | None = None,
    ) -> Any:
        ...

    async def auth_reset_password_post(
        self,
        access_token: str,
        new_password: str,
    ) -> Any:
        ...
