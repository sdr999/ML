# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any
from hire_pilot.models.profile_summary_get200_response import ProfileSummaryGet200Response
from hire_pilot.models.profile_summary_put_request import ProfileSummaryPutRequest
from hire_pilot.security_api import get_token_bearerAuth

class BaseSummaryApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseSummaryApi.subclasses = BaseSummaryApi.subclasses + (cls,)
    async def profile_summary_get(
        self,
    ) -> ProfileSummaryGet200Response:
        ...


    async def profile_summary_put(
        self,
        profile_summary_put_request: ProfileSummaryPutRequest,
    ) -> Any:
        ...
