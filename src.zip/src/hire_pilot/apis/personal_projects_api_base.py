# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field, StrictStr
from typing import Any, List
from typing_extensions import Annotated
from hire_pilot.models.personal_project import PersonalProject
from hire_pilot.models.personal_project_input import PersonalProjectInput
from hire_pilot.security_api import get_token_bearerAuth

class BasePersonalProjectsApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BasePersonalProjectsApi.subclasses = BasePersonalProjectsApi.subclasses + (cls,)
    async def profile_projects_get(
        self,
    ) -> List[PersonalProject]:
        ...


    async def profile_projects_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        ...


    async def profile_projects_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> PersonalProject:
        ...


    async def profile_projects_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        personal_project_input: PersonalProjectInput,
    ) -> Any:
        ...


    async def profile_projects_post(
        self,
        personal_project_input: PersonalProjectInput,
    ) -> Any:
        ...
