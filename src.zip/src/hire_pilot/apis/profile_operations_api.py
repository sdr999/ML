# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.profile_operations_api_base import BaseProfileOperationsApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from typing import Any
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.models.profile_resume_parse_post_request import ProfileResumeParsePostRequest
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.post(
    "/profile/resume-parse",
    responses={
        200: {"description": "Extracted profile data objects"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters or payload."},
    },
    tags=["Profile Operations"],
    summary="Autofill profile with Resume",
    response_model_by_alias=True,
)
async def profile_resume_parse_post(
    profile_resume_parse_post_request: ProfileResumeParsePostRequest = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseProfileOperationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseProfileOperationsApi.subclasses[0]().profile_resume_parse_post(profile_resume_parse_post_request)

@router.get(
    "/profile/details",
    responses={
        200: {"description": "Aggregated profile details"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Profile Operations"],
    summary="Get aggregated profile details",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_details_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseProfileOperationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseProfileOperationsApi.subclasses[0]().profile_details_get()


@router.get(
    "/profile/resume/download",
    responses={
        200: {"description": "Resume file download", "content": {"application/pdf": {}}},
        404: {"model": ErrorResponse, "description": "No resume found."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
    },
    tags=["Profile Operations"],
    summary="Download stored resume",
)
async def resume_download_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseProfileOperationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseProfileOperationsApi.subclasses[0]().resume_download_get()


@router.post(
    "/profile/resume/generate",
    responses={
        200: {"description": "Resume generated and saved successfully."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Profile Operations"],
    summary="Generate resume from profile data",
    status_code=status.HTTP_200_OK,
)
async def resume_generate_post(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseProfileOperationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseProfileOperationsApi.subclasses[0]().resume_generate_post()


@router.get(
    "/profile/completion",
    responses={
        200: {"description": "Profile completion percentage and missing sections"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
    },
    tags=["Profile Operations"],
    summary="Get profile completion percentage",
    response_model_by_alias=True,
)
async def profile_completion_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseProfileOperationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseProfileOperationsApi.subclasses[0]().profile_completion_get()
