# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any
from hire_pilot.models.company_profile import CompanyProfile
from hire_pilot.security_api import get_token_bearerAuth

class BaseEmployerProfileApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseEmployerProfileApi.subclasses = BaseEmployerProfileApi.subclasses + (cls,)
    async def employer_profile_get(
        self,
    ) -> None:
        ...


    async def employer_profile_put(
        self,
    ) -> None:
        ...


    async def employer_company_get(
        self,
    ) -> CompanyProfile:
        ...


    async def employer_company_put(
        self,
        company_profile: CompanyProfile,
    ) -> None:
        ...


    async def employer_company_logo_post(
        self,
    ) -> None:
        ...


    async def employer_company_documents_post(
        self,
    ) -> None:
        ...
