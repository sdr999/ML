# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import StrictStr
from typing import Any, List


class BaseMetadataApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseMetadataApi.subclasses = BaseMetadataApi.subclasses + (cls,)
    async def metadata_degrees_get(
        self,
    ) -> None:
        ...


    async def metadata_locations_get(
        self,
    ) -> None:
        ...


    async def metadata_skills_get(
        self,
    ) -> List[str]:
        ...
