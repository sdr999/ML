# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field, StrictStr
from typing import Any, List
from typing_extensions import Annotated
from hire_pilot.models.language import Language
from hire_pilot.models.language_input import LanguageInput
from hire_pilot.security_api import get_token_bearerAuth

class BaseLanguagesApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseLanguagesApi.subclasses = BaseLanguagesApi.subclasses + (cls,)
    async def profile_languages_get(
        self,
    ) -> List[Language]:
        ...


    async def profile_languages_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        ...


    async def profile_languages_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Language:
        ...


    async def profile_languages_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        language_input: LanguageInput,
    ) -> Any:
        ...


    async def profile_languages_post(
        self,
        language_input: LanguageInput,
    ) -> Any:
        ...
