# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.applications_ats_api_base import BaseApplicationsATSApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import BaseModel, Field, StrictStr
from typing import Any, List, Optional
from typing_extensions import Annotated
from hire_pilot.models.application import Application
from hire_pilot.models.employer_applications_application_id_status_patch_request import EmployerApplicationsApplicationIdStatusPatchRequest
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


# ── Request Bodies ──────────────────────────────────────────
class MoveStageRequest(BaseModel):
    stage: StrictStr = Field(..., description="Target pipeline stage")

class AddNoteRequest(BaseModel):
    note: StrictStr = Field(..., description="Note text")

class RateRequest(BaseModel):
    rating: int = Field(..., ge=1, le=5, description="Rating 1-5")

class ApplyRequest(BaseModel):
    job_id: StrictStr = Field(..., description="The job ID to apply to")


# ═══════════════════════════════════════════════════════════
# CANDIDATE-FACING ENDPOINTS
# ═══════════════════════════════════════════════════════════

@router.post(
    "/candidate/applications",
    responses={
        201: {"description": "Application submitted"},
        409: {"description": "Already applied"},
    },
    tags=["Applications (Candidate)"],
    summary="Apply to a Job",
    response_model_by_alias=True,
)
async def candidate_apply_post(
    body: ApplyRequest = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().candidate_apply_post(body.job_id)


@router.get(
    "/candidate/applications",
    responses={
        200: {"model": List[Application], "description": "List of candidate's applications"},
    },
    tags=["Applications (Candidate)"],
    summary="My Applications",
    response_model_by_alias=True,
)
async def candidate_applications_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> List[Application]:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().candidate_applications_get()


# ═══════════════════════════════════════════════════════════
# EMPLOYER: APPLICATION LISTING
# ═══════════════════════════════════════════════════════════

@router.get(
    "/employer/jobs/{jobId}/applications",
    responses={
        200: {"model": List[Application], "description": "List of applications"},
    },
    tags=["Applications (ATS)"],
    summary="List Applications for a Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_applications_get(
    jobId: StrictStr = Path(..., description="Job ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> List[Application]:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_jobs_job_id_applications_get(jobId)


@router.get(
    "/employer/jobs/{jobId}/applications/enriched",
    responses={
        200: {"description": "Enriched list of applications with candidate profiles"},
    },
    tags=["Applications (ATS)"],
    summary="List Applications with Candidate Profiles",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_applications_enriched_get(
    jobId: StrictStr = Path(..., description="Job ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_jobs_job_id_applications_enriched_get(jobId)


@router.get(
    "/employer/applications/{applicationId}",
    responses={
        200: {"model": Application, "description": "Application details"},
    },
    tags=["Applications (ATS)"],
    summary="Get Application Details",
    response_model_by_alias=True,
)
async def employer_applications_application_id_get(
    applicationId: StrictStr = Path(..., description="Application ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Application:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_applications_application_id_get(applicationId)


@router.patch(
    "/employer/applications/{applicationId}/status",
    responses={
        200: {"description": "Status updated"},
    },
    tags=["Applications (ATS)"],
    summary="Update Application Status",
    response_model_by_alias=True,
)
async def employer_applications_application_id_status_patch(
    applicationId: StrictStr = Path(..., description="Application ID"),
    body: EmployerApplicationsApplicationIdStatusPatchRequest = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> None:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_applications_application_id_status_patch(applicationId, body)


# ═══════════════════════════════════════════════════════════
# EMPLOYER: CANDIDATE QUICK ACTIONS
# ═══════════════════════════════════════════════════════════

@router.post(
    "/employer/applications/{id}/shortlist",
    responses={200: {"description": "Shortlisted"}},
    tags=["Applications (ATS)"],
    summary="Shortlist Application",
    response_model_by_alias=True,
)
async def employer_applications_id_shortlist_post(
    id: StrictStr = Path(..., description="Application ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> None:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_applications_id_shortlist_post(id)


@router.post(
    "/employer/applications/{id}/reject",
    responses={200: {"description": "Rejected"}},
    tags=["Applications (ATS)"],
    summary="Reject Application",
    response_model_by_alias=True,
)
async def employer_applications_id_reject_post(
    id: StrictStr = Path(..., description="Application ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> None:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_applications_id_reject_post(id)


@router.post(
    "/employer/applications/{id}/move-stage",
    responses={200: {"description": "Stage moved"}},
    tags=["Applications (ATS)"],
    summary="Move Application Stage",
    response_model_by_alias=True,
)
async def employer_applications_id_move_stage_post(
    id: StrictStr = Path(..., description="Application ID"),
    body: MoveStageRequest = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> None:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_applications_id_move_stage_post(id, body.stage)


@router.post(
    "/employer/applications/{id}/add-note",
    responses={201: {"description": "Note added"}},
    tags=["Applications (ATS)"],
    summary="Add Note to Application",
    response_model_by_alias=True,
)
async def employer_applications_id_add_note_post(
    id: StrictStr = Path(..., description="Application ID"),
    body: AddNoteRequest = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> None:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_applications_id_add_note_post(id, body.note)


@router.post(
    "/employer/applications/{id}/rate",
    responses={200: {"description": "Rated"}},
    tags=["Applications (ATS)"],
    summary="Rate Candidate",
    response_model_by_alias=True,
)
async def employer_applications_id_rate_post(
    id: StrictStr = Path(..., description="Application ID"),
    body: RateRequest = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> None:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_applications_id_rate_post(id, body.rating)


@router.get(
    "/employer/applications/{id}/resume",
    responses={200: {"description": "Resume retrieved"}},
    tags=["Applications (ATS)"],
    summary="View Candidate Resume",
    response_model_by_alias=True,
)
async def employer_applications_id_resume_get(
    id: StrictStr = Path(..., description="Application ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> None:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_applications_id_resume_get(id)


# ═══════════════════════════════════════════════════════════
# KPI / ANALYTICS ENDPOINTS
# ═══════════════════════════════════════════════════════════

@router.get(
    "/employer/dashboard/kpis",
    responses={200: {"description": "Dashboard KPIs"}},
    tags=["Analytics & KPIs"],
    summary="Get Employer Dashboard KPIs",
    response_model_by_alias=True,
)
async def employer_dashboard_kpis_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_dashboard_kpis_get()


@router.get(
    "/employer/jobs/{jobId}/kpis",
    responses={200: {"description": "Job-specific KPIs"}},
    tags=["Analytics & KPIs"],
    summary="Get Job KPIs",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_kpis_get(
    jobId: StrictStr = Path(..., description="Job ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_jobs_job_id_kpis_get(jobId)


# ── Duplicate Job ──────────────────────────────────────────

@router.post(
    "/employer/jobs/{jobId}/duplicate",
    responses={200: {"description": "Job duplicated successfully"}},
    tags=["Job Management"],
    summary="Duplicate a job posting",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_duplicate_post(
    jobId: StrictStr = Path(..., description="Job ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_jobs_job_id_duplicate_post(jobId)


# ── Candidate Withdraw ─────────────────────────────────────

@router.post(
    "/candidate/applications/{applicationId}/withdraw",
    responses={200: {"description": "Application withdrawn"}},
    tags=["Candidate Applications"],
    summary="Withdraw your application",
    response_model_by_alias=True,
)
async def candidate_application_withdraw_post(
    applicationId: StrictStr = Path(..., description="Application ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().candidate_application_withdraw_post(applicationId)


# ── Bulk Status Update ─────────────────────────────────────

@router.post(
    "/employer/applications/bulk-update-status",
    responses={200: {"description": "Bulk status update result"}},
    tags=["ATS - Applicant Tracking"],
    summary="Bulk update application statuses",
    response_model_by_alias=True,
)
async def employer_applications_bulk_update_post(
    body: dict = Body(..., description="application_ids and status"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_applications_bulk_update_post(body)


# ── Application Timeline ──────────────────────────────────

@router.get(
    "/employer/applications/{applicationId}/timeline",
    responses={200: {"description": "Application timeline / audit trail"}},
    tags=["ATS - Applicant Tracking"],
    summary="Get application status timeline",
    response_model_by_alias=True,
)
async def employer_application_timeline_get(
    applicationId: StrictStr = Path(..., description="Application ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseApplicationsATSApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseApplicationsATSApi.subclasses[0]().employer_application_timeline_get(applicationId)
