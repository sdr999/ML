# coding: utf-8

from typing import ClassVar, Dict, List, Tuple, Any, Optional

class BaseSubscriptionBillingApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseSubscriptionBillingApi.subclasses = BaseSubscriptionBillingApi.subclasses + (cls,)

    async def employer_plans_get(self) -> Any:
        ...

    async def employer_subscription_get(self) -> Any:
        ...

    async def employer_subscription_post(
        self,
        plan_id: str
    ) -> Any:
        ...

    async def employer_payments_checkout_post(
        self,
        plan_id: str
    ) -> Any:
        ...

    async def employer_payments_webhook_post(
        self,
        payload: Dict[str, Any]
    ) -> Any:
        ...

    async def employer_invoices_get(self) -> Any:
        ...
