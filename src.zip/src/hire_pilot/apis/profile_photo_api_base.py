# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any
from hire_pilot.models.profile_photo_get200_response import ProfilePhotoGet200Response
from hire_pilot.security_api import get_token_bearerAuth

class BaseProfilePhotoApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseProfilePhotoApi.subclasses = BaseProfilePhotoApi.subclasses + (cls,)
    async def profile_photo_delete(
        self,
    ) -> None:
        ...


    async def profile_photo_get(
        self,
    ) -> ProfilePhotoGet200Response:
        ...


    async def profile_photo_put(
        self,
        profile_photo_get200_response: ProfilePhotoGet200Response,
    ) -> None:
        ...
