# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.summary_api_base import BaseSummaryApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from typing import Any
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.models.profile_summary_get200_response import ProfileSummaryGet200Response
from hire_pilot.models.profile_summary_put_request import ProfileSummaryPutRequest
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/summary",
    responses={
        200: {"model": ProfileSummaryGet200Response, "description": "Summary retrieved"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Summary"],
    summary="Get summary",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_summary_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> ProfileSummaryGet200Response:
    if not BaseSummaryApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSummaryApi.subclasses[0]().profile_summary_get()


@router.put(
    "/profile/summary",
    responses={
        200: {"description": "Summary updated"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Summary"],
    summary="Update summary",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_summary_put(
    profile_summary_put_request: ProfileSummaryPutRequest = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseSummaryApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSummaryApi.subclasses[0]().profile_summary_put(profile_summary_put_request)
