# coding: utf-8

from typing import Any, Dict, List, Optional
import importlib
import pkgutil

from hire_pilot.apis.public_jobs_api_base import BasePublicJobsApi
import hire_pilot.impl

from fastapi import APIRouter, HTTPException, Path, Query

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/jobs",
    responses={200: {"description": "Paginated list of published jobs"}},
    tags=["Public Job Board"],
    summary="Browse Published Jobs",
    response_model_by_alias=True,
)
async def jobs_get(
    keyword: Optional[str] = Query(None, description="Full-text search across title and description"),
    skills: Optional[str] = Query(None, description="Comma-separated skills, e.g. Python,React"),
    location: Optional[str] = Query(None, description="City or region filter"),
    job_type: Optional[str] = Query(None, description="FULL_TIME | PART_TIME | CONTRACT | INTERNSHIP"),
    work_mode: Optional[str] = Query(None, description="REMOTE | HYBRID | ONSITE"),
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
) -> List[Dict[str, Any]]:
    if not BasePublicJobsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BasePublicJobsApi.subclasses[0]().jobs_get(
        keyword, skills, location, job_type, work_mode, page, limit
    )


@router.get(
    "/jobs/{jobId}",
    responses={
        200: {"description": "Job details"},
        404: {"description": "Job not found"},
    },
    tags=["Public Job Board"],
    summary="Get Job Details (fires JOB_VIEW event)",
    response_model_by_alias=True,
)
async def jobs_id_get(
    jobId: str = Path(..., description="Job ID"),
    viewer_id: Optional[str] = Query(None, description="Viewer user ID for analytics attribution"),
) -> Dict[str, Any]:
    if not BasePublicJobsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BasePublicJobsApi.subclasses[0]().jobs_id_get(jobId, viewer_id)
