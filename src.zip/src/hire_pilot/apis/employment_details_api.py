# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.employment_details_api_base import BaseEmploymentDetailsApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import Field, StrictStr
from typing import Any, List, Optional
from typing_extensions import Annotated
from hire_pilot.models.employment_detail import EmploymentDetail
from hire_pilot.models.employment_detail_input import EmploymentDetailInput
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/employment-details",
    responses={
        200: {"model": List[EmploymentDetail], "description": "List of employment details"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Employment Details"],
    summary="Get all employment details",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_employment_details_get(
    page: Annotated[Optional[Annotated[int, Field(ge=1)]], Field(description="Page number for pagination")] = Query(1, description="Page number for pagination", alias="page", ge=1),
    limit: Annotated[Optional[Annotated[int, Field(le=100, ge=1)]], Field(description="Number of items to return per page")] = Query(20, description="Number of items to return per page", alias="limit", ge=1, le=100),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[EmploymentDetail]:
    if not BaseEmploymentDetailsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmploymentDetailsApi.subclasses[0]().profile_employment_details_get(page, limit)


@router.delete(
    "/profile/employment-details/{id}",
    responses={
        200: {"description": "Deleted successfully"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Employment detail not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Employment Details"],
    summary="Delete employment detail",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_employment_details_id_delete(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseEmploymentDetailsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmploymentDetailsApi.subclasses[0]().profile_employment_details_id_delete(id)


@router.get(
    "/profile/employment-details/{id}",
    responses={
        200: {"model": EmploymentDetail, "description": "Employment detail retrieved"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "The requested resource could not be found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Employment Details"],
    summary="Get specific employment detail",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_employment_details_id_get(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> EmploymentDetail:
    if not BaseEmploymentDetailsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmploymentDetailsApi.subclasses[0]().profile_employment_details_id_get(id)


@router.put(
    "/profile/employment-details/{id}",
    responses={
        200: {"description": "Updated successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Employment detail not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Employment Details"],
    summary="Update employment detail",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_employment_details_id_put(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    employment_detail_input: EmploymentDetailInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseEmploymentDetailsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmploymentDetailsApi.subclasses[0]().profile_employment_details_id_put(id, employment_detail_input)


@router.post(
    "/profile/employment-details",
    responses={
        201: {"model": EmploymentDetail, "description": "Created"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Employment Details"],
    summary="Add employment details record",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def profile_employment_details_post(
    employment_detail_input: EmploymentDetailInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseEmploymentDetailsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmploymentDetailsApi.subclasses[0]().profile_employment_details_post(employment_detail_input)
