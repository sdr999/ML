# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.basic_info_api_base import BaseBasicInfoApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from typing import Any
from hire_pilot.models.basic_info import BasicInfo
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/basic-info",
    responses={
        200: {"model": BasicInfo, "description": "Basic info retrieved"},
        404: {"model": ErrorResponse, "description": "The requested resource could not be found."},
    },
    tags=["Basic Info"],
    summary="Get basic info",
    response_model_by_alias=True,
)
async def profile_basic_info_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> BasicInfo:
    if not BaseBasicInfoApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseBasicInfoApi.subclasses[0]().profile_basic_info_get()


@router.put(
    "/profile/basic-info",
    responses={
        200: {"description": "Basic info updated"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters or payload."},
    },
    tags=["Basic Info"],
    summary="Update basic info",
    response_model_by_alias=True,
)
async def profile_basic_info_put(
    basic_info: BasicInfo = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseBasicInfoApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseBasicInfoApi.subclasses[0]().profile_basic_info_put(basic_info)
