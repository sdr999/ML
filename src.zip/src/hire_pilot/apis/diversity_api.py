# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.diversity_api_base import BaseDiversityApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from typing import Any
from hire_pilot.models.diversity import Diversity
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/diversity",
    responses={
        200: {"model": Diversity, "description": "Diversity info retrieved"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Diversity"],
    summary="Get diversity info",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_diversity_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Diversity:
    if not BaseDiversityApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseDiversityApi.subclasses[0]().profile_diversity_get()


@router.put(
    "/profile/diversity",
    responses={
        200: {"description": "Updated successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Diversity"],
    summary="Update diversity info",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_diversity_put(
    diversity: Diversity = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseDiversityApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseDiversityApi.subclasses[0]().profile_diversity_put(diversity)
