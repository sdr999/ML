# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field
from typing import Any, List, Optional
from typing_extensions import Annotated
from hire_pilot.models.application import Application
from hire_pilot.models.employer_applications_application_id_status_patch_request import EmployerApplicationsApplicationIdStatusPatchRequest
from hire_pilot.security_api import get_token_bearerAuth


class BaseApplicationsATSApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseApplicationsATSApi.subclasses = BaseApplicationsATSApi.subclasses + (cls,)

    # ── Candidate-facing ────────────────────────────────────

    async def candidate_apply_post(
        self,
        job_id: str,
    ) -> Any:
        ...

    async def candidate_applications_get(
        self,
    ) -> List[Application]:
        ...

    # ── Employer: Listing ───────────────────────────────────

    async def employer_jobs_job_id_applications_get(
        self,
        jobId: str,
    ) -> List[Application]:
        ...

    async def employer_jobs_job_id_applications_enriched_get(
        self,
        jobId: str,
    ) -> Any:
        ...

    async def employer_applications_application_id_get(
        self,
        applicationId: str,
    ) -> Application:
        ...

    async def employer_applications_application_id_status_patch(
        self,
        applicationId: str,
        employer_applications_application_id_status_patch_request: EmployerApplicationsApplicationIdStatusPatchRequest,
    ) -> None:
        ...

    # ── Employer: Quick Actions ─────────────────────────────

    async def employer_applications_id_shortlist_post(
        self,
        id: str,
    ) -> None:
        ...

    async def employer_applications_id_reject_post(
        self,
        id: str,
    ) -> None:
        ...

    async def employer_applications_id_move_stage_post(
        self,
        id: str,
        stage: str,
    ) -> None:
        ...

    async def employer_applications_id_add_note_post(
        self,
        id: str,
        note: str,
    ) -> None:
        ...

    async def employer_applications_id_rate_post(
        self,
        id: str,
        rating: int,
    ) -> None:
        ...

    async def employer_applications_id_resume_get(
        self,
        id: str,
    ) -> None:
        ...

    # ── KPI / Analytics ─────────────────────────────────────

    async def employer_dashboard_kpis_get(
        self,
    ) -> Any:
        ...

    async def employer_jobs_job_id_kpis_get(
        self,
        jobId: str,
    ) -> Any:
        ...

    # ── New: Duplicate, Withdraw, Bulk, Timeline ───────────

    async def employer_jobs_job_id_duplicate_post(
        self,
        jobId: str,
    ) -> Any:
        ...

    async def candidate_application_withdraw_post(
        self,
        applicationId: str,
    ) -> Any:
        ...

    async def employer_applications_bulk_update_post(
        self,
        body: dict,
    ) -> Any:
        ...

    async def employer_application_timeline_get(
        self,
        applicationId: str,
    ) -> Any:
        ...
