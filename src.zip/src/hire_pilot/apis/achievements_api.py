# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.achievements_api_base import BaseAchievementsApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from hire_pilot.models.error_response import ErrorResponse
from pydantic import Field, StrictStr
from typing import Any, List
from typing_extensions import Annotated
from hire_pilot.models.achievement import Achievement
from hire_pilot.models.achievement_input import AchievementInput
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/achievements",
    responses={
        200: {"model": List[Achievement], "description": "List of achievements"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Achievements"],
    summary="Get all achievements",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_achievements_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[Achievement]:
    if not BaseAchievementsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAchievementsApi.subclasses[0]().profile_achievements_get()


@router.post(
    "/profile/achievements",
    responses={
        201: {"description": "Created"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Achievements"],
    summary="Add achievement",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def profile_achievements_post(
    achievement_input: AchievementInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseAchievementsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAchievementsApi.subclasses[0]().profile_achievements_post(achievement_input)


@router.get(
    "/profile/achievements/{id}",
    responses={
        200: {"model": Achievement, "description": "Achievement detail"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Achievement not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Achievements"],
    summary="Get specific achievement",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_achievements_id_get(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Achievement:
    if not BaseAchievementsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAchievementsApi.subclasses[0]().profile_achievements_id_get(id)


@router.put(
    "/profile/achievements/{id}",
    responses={
        200: {"description": "Updated"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Achievement not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Achievements"],
    summary="Update achievement",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_achievements_id_put(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    achievement_input: AchievementInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseAchievementsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAchievementsApi.subclasses[0]().profile_achievements_id_put(id, achievement_input)


@router.delete(
    "/profile/achievements/{id}",
    responses={
        200: {"description": "Deleted"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Achievement not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Achievements"],
    summary="Delete achievement",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_achievements_id_delete(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseAchievementsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAchievementsApi.subclasses[0]().profile_achievements_id_delete(id)
