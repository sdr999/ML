# coding: utf-8

from typing import Any, ClassVar, Dict, List, Optional, Tuple


class BasePublicJobsApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BasePublicJobsApi.subclasses = BasePublicJobsApi.subclasses + (cls,)

    async def jobs_get(
        self,
        keyword: Optional[str],
        skills: Optional[str],
        location: Optional[str],
        job_type: Optional[str],
        work_mode: Optional[str],
        page: int,
        limit: int,
    ) -> List[Dict[str, Any]]:
        ...

    async def jobs_id_get(self, job_id: str, viewer_id: Optional[str]) -> Dict[str, Any]:
        ...
