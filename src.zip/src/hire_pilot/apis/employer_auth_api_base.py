# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any
from hire_pilot.models.auth_response import AuthResponse
from hire_pilot.models.employer_register_request import EmployerRegisterRequest
from hire_pilot.models.sign_in_request import SignInRequest
from hire_pilot.security_api import get_token_bearerAuth

class BaseEmployerAuthApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseEmployerAuthApi.subclasses = BaseEmployerAuthApi.subclasses + (cls,)
    async def employer_auth_register_post(
        self,
        employer_register_request: EmployerRegisterRequest,
    ) -> None:
        ...


    async def employer_auth_login_post(
        self,
        sign_in_request: SignInRequest,
    ) -> AuthResponse:
        ...


    async def employer_auth_logout_post(
        self,
    ) -> None:
        ...


    async def employer_auth_refresh_token_post(
        self,
    ) -> None:
        ...


    async def employer_auth_forgot_password_post(
        self,
    ) -> None:
        ...


    async def employer_auth_reset_password_post(
        self,
    ) -> None:
        ...


    async def employer_auth_verify_email_post(
        self,
    ) -> None:
        ...
