# coding: utf-8

import importlib
import pkgutil

from hire_pilot.apis.offer_management_api_base import BaseOfferManagementApi
import hire_pilot.impl

from fastapi import APIRouter, Body, HTTPException, Path, Security, status

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from hire_pilot.models.offer import Offer, OfferInput, OfferResponseInput
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.post(
    "/employer/applications/{applicationId}/offer",
    responses={201: {"model": Offer, "description": "Offer extended to candidate"}},
    tags=["Offer Management"],
    summary="Make a Formal Offer",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def employer_applications_offer_post(
    applicationId: str = Path(..., description="Application ID"),
    body: OfferInput = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Offer:
    if not BaseOfferManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseOfferManagementApi.subclasses[0]().employer_applications_offer_post(
        applicationId, body
    )


@router.patch(
    "/candidate/applications/{applicationId}/offer/respond",
    responses={200: {"model": Offer, "description": "Offer response recorded"}},
    tags=["Offer Management"],
    summary="Accept or Decline an Offer",
    response_model_by_alias=True,
)
async def candidate_applications_offer_respond_patch(
    applicationId: str = Path(..., description="Application ID"),
    body: OfferResponseInput = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Offer:
    if not BaseOfferManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseOfferManagementApi.subclasses[0]().candidate_applications_offer_respond_patch(
        applicationId, body
    )
