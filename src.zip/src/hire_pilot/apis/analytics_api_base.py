# coding: utf-8

from typing import Any, ClassVar, Dict, List, Tuple
from hire_pilot.models.dashboard_metrics import DashboardMetrics
from hire_pilot.models.interview_report import InterviewReport
from hire_pilot.models.job_report import JobReport


class BaseAnalyticsApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseAnalyticsApi.subclasses = BaseAnalyticsApi.subclasses + (cls,)

    async def employer_dashboard_get(self) -> DashboardMetrics:
        ...

    async def employer_reports_jobs_get(self) -> List[JobReport]:
        ...

    async def employer_reports_candidates_get(self) -> Dict[str, Any]:
        ...

    async def employer_reports_interviews_get(self) -> InterviewReport:
        ...
