# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any
from hire_pilot.models.diversity import Diversity
from hire_pilot.security_api import get_token_bearerAuth

class BaseDiversityApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseDiversityApi.subclasses = BaseDiversityApi.subclasses + (cls,)
    async def profile_diversity_get(
        self,
    ) -> Diversity:
        ...


    async def profile_diversity_put(
        self,
        diversity: Diversity,
    ) -> Any:
        ...
