# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.work_experience_api_base import BaseWorkExperienceApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import Field, StrictStr
from typing import Any, List, Optional
from typing_extensions import Annotated
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.models.work_experience import WorkExperience
from hire_pilot.models.work_experience_input import WorkExperienceInput
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/work-experience",
    responses={
        200: {"model": List[WorkExperience], "description": "List of work experiences"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Work Experience"],
    summary="Get all work experience",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_work_experience_get(
    page: Annotated[Optional[Annotated[int, Field(ge=1)]], Field(description="Page number for pagination")] = Query(1, description="Page number for pagination", alias="page", ge=1),
    limit: Annotated[Optional[Annotated[int, Field(le=100, ge=1)]], Field(description="Number of items to return per page")] = Query(20, description="Number of items to return per page", alias="limit", ge=1, le=100),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[WorkExperience]:
    if not BaseWorkExperienceApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseWorkExperienceApi.subclasses[0]().profile_work_experience_get(page, limit)


@router.delete(
    "/profile/work-experience/{id}",
    responses={
        200: {"description": "Deleted"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "The requested resource could not be found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Work Experience"],
    summary="Delete specific work experience",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_work_experience_id_delete(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseWorkExperienceApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseWorkExperienceApi.subclasses[0]().profile_work_experience_id_delete(id)


@router.get(
    "/profile/work-experience/{id}",
    responses={
        200: {"model": WorkExperience, "description": "Work experience details"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "The requested resource could not be found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Work Experience"],
    summary="Get specific work experience",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_work_experience_id_get(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> WorkExperience:
    if not BaseWorkExperienceApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseWorkExperienceApi.subclasses[0]().profile_work_experience_id_get(id)


@router.put(
    "/profile/work-experience/{id}",
    responses={
        200: {"description": "Updated"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "The requested resource could not be found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Work Experience"],
    summary="Update specific work experience",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_work_experience_id_put(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    work_experience_input: WorkExperienceInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseWorkExperienceApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseWorkExperienceApi.subclasses[0]().profile_work_experience_id_put(id, work_experience_input)


@router.post(
    "/profile/work-experience",
    responses={
        201: {"model": WorkExperience, "description": "Created"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Work Experience"],
    summary="Add work experience",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def profile_work_experience_post(
    work_experience_input: WorkExperienceInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseWorkExperienceApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseWorkExperienceApi.subclasses[0]().profile_work_experience_post(work_experience_input)
