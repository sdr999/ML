# coding: utf-8

from typing import Dict, List, Any, Optional
import importlib
import pkgutil

from hire_pilot.apis.subscription_billing_api_base import BaseSubscriptionBillingApi
import hire_pilot.impl

from fastapi import (
    APIRouter,
    Body,
    HTTPException,
    Path,
    Query,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/employer/plans",
    responses={
        200: {"description": "List of plans"},
    },
    tags=["Billing"],
    summary="List Subscription Plans",
)
async def employer_plans_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseSubscriptionBillingApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSubscriptionBillingApi.subclasses[0]().employer_plans_get()


@router.get(
    "/employer/subscription",
    responses={
        200: {"description": "Subscription details"},
    },
    tags=["Billing"],
    summary="Get Current Subscription",
)
async def employer_subscription_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseSubscriptionBillingApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSubscriptionBillingApi.subclasses[0]().employer_subscription_get()


@router.post(
    "/employer/subscription",
    responses={
        200: {"description": "Subscription updated"},
    },
    tags=["Billing"],
    summary="Update/Start Subscription",
)
async def employer_subscription_post(
    plan_id: str = Body(..., embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseSubscriptionBillingApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSubscriptionBillingApi.subclasses[0]().employer_subscription_post(plan_id)


@router.post(
    "/employer/payments/checkout",
    responses={
        200: {"description": "Checkout URL returned"},
    },
    tags=["Billing"],
    summary="Create Checkout Session",
)
async def employer_payments_checkout_post(
    plan_id: str = Body(..., embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseSubscriptionBillingApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSubscriptionBillingApi.subclasses[0]().employer_payments_checkout_post(plan_id)


@router.post(
    "/employer/payments/webhook",
    responses={
        200: {"description": "Webhook processed"},
    },
    tags=["Billing"],
    summary="Payment Webhook",
)
async def employer_payments_webhook_post(
    payload: Dict[str, Any] = Body(...),
) -> Any:
    # Webhook does not require authorization header since it comes from Stripe
    if not BaseSubscriptionBillingApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSubscriptionBillingApi.subclasses[0]().employer_payments_webhook_post(payload)


@router.get(
    "/employer/invoices",
    responses={
        200: {"description": "List of invoices"},
    },
    tags=["Billing"],
    summary="List Invoices",
)
async def employer_invoices_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseSubscriptionBillingApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseSubscriptionBillingApi.subclasses[0]().employer_invoices_get()
