# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.authentication_api_base import BaseAuthenticationApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from typing import Any
from hire_pilot.models.auth_response import AuthResponse
from hire_pilot.models.error_response import ErrorResponse
from hire_pilot.models.sign_in_request import SignInRequest
from hire_pilot.models.sign_up_request import SignUpRequest


router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.post(
    "/auth/signin",
    responses={
        200: {"model": AuthResponse, "description": "Successful login"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Invalid credentials."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Authentication"],
    summary="User Sign In",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def auth_signin_post(
    sign_in_request: SignInRequest = Body(None, description=""),
) -> AuthResponse:
    if not BaseAuthenticationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAuthenticationApi.subclasses[0]().auth_signin_post(sign_in_request)


@router.post(
    "/auth/signup",
    responses={
        201: {"description": "User created successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters or payload."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Authentication"],
    summary="User Sign Up (Supabase)",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def auth_signup_post(
    sign_up_request: SignUpRequest = Body(None, description=""),
) -> Any:
    if not BaseAuthenticationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseAuthenticationApi.subclasses[0]().auth_signup_post(sign_up_request)


@router.post(
    "/auth/refresh",
    responses={
        200: {"model": AuthResponse, "description": "Tokens refreshed successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request."},
        401: {"model": ErrorResponse, "description": "Invalid or expired refresh token."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Authentication"],
    summary="Refresh access token",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def auth_refresh_post(
    body: dict = Body(..., description=""),
) -> AuthResponse:
    if not BaseAuthenticationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    refresh_token = body.get("refresh_token", "")
    return await BaseAuthenticationApi.subclasses[0]().auth_refresh_post(refresh_token)


@router.post(
    "/auth/forgot-password",
    responses={
        200: {"description": "Reset email sent (if account exists)"},
        400: {"model": ErrorResponse, "description": "Invalid request."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Authentication"],
    summary="Send password reset email",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def auth_forgot_password_post(
    body: dict = Body(..., description=""),
) -> Any:
    if not BaseAuthenticationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    email = body.get("email", "")
    redirect_to = body.get("redirect_to")
    return await BaseAuthenticationApi.subclasses[0]().auth_forgot_password_post(email, redirect_to)


@router.post(
    "/auth/reset-password",
    responses={
        200: {"description": "Password reset successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request or expired token."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Authentication"],
    summary="Reset password with token",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def auth_reset_password_post(
    body: dict = Body(..., description=""),
) -> Any:
    if not BaseAuthenticationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    access_token = body.get("access_token", "")
    new_password = body.get("new_password", "")
    return await BaseAuthenticationApi.subclasses[0]().auth_reset_password_post(access_token, new_password)
