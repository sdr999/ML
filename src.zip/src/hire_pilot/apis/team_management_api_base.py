# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any, List
from uuid import UUID
from hire_pilot.models.team_member import TeamMember
from hire_pilot.security_api import get_token_bearerAuth

class BaseTeamManagementApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseTeamManagementApi.subclasses = BaseTeamManagementApi.subclasses + (cls,)
    async def employer_team_get(
        self,
    ) -> List[TeamMember]:
        ...


    async def employer_team_invite_post(
        self,
    ) -> None:
        ...


    async def employer_team_member_id_role_put(
        self,
        memberId: UUID,
    ) -> None:
        ...


    async def employer_team_member_id_delete(
        self,
        memberId: UUID,
    ) -> None:
        ...
