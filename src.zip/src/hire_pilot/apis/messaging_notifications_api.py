# coding: utf-8

from typing import Dict, List, Any, Optional
import importlib
import pkgutil

from hire_pilot.apis.messaging_notifications_api_base import BaseMessagingNotificationsApi
import hire_pilot.impl

from fastapi import (
    APIRouter,
    Body,
    HTTPException,
    Path,
    Query,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.post(
    "/employer/messages",
    responses={
        201: {"description": "Message sent"},
    },
    tags=["Messaging"],
    summary="Send Message",
)
async def employer_messages_post(
    candidate_id: str = Body(..., embed=True),
    message: str = Body(..., embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().employer_messages_post(candidate_id, message)


@router.get(
    "/employer/conversations",
    responses={
        200: {"description": "List of conversations"},
    },
    tags=["Messaging"],
    summary="List Conversations",
)
async def employer_conversations_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().employer_conversations_get()


@router.get(
    "/employer/conversations/{id}",
    responses={
        200: {"description": "Messages retrieved"},
    },
    tags=["Messaging"],
    summary="Get Conversation Messages",
)
async def employer_conversations_id_get(
    id: str = Path(..., description="The conversation UUID (candidate ID)"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().employer_conversations_id_get(id)


@router.post(
    "/employer/communications/email",
    responses={
        200: {"description": "Emails sent"},
    },
    tags=["Communications"],
    summary="Send Bulk Email",
)
async def employer_communications_email_post(
    candidate_ids: List[str] = Body(..., embed=True),
    subject: str = Body(..., embed=True),
    body: str = Body(..., embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().employer_communications_email_post(
        candidate_ids, subject, body
    )


@router.post(
    "/employer/communications/sms",
    responses={
        200: {"description": "SMS sent"},
    },
    tags=["Communications"],
    summary="Send SMS",
)
async def employer_communications_sms_post(
    candidate_id: str = Body(..., embed=True),
    message: str = Body(..., embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().employer_communications_sms_post(
        candidate_id, message
    )


@router.get(
    "/employer/notifications",
    responses={
        200: {"description": "List of notifications"},
    },
    tags=["Messaging"],
    summary="List Notifications",
)
async def employer_notifications_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().employer_notifications_get()


@router.patch(
    "/employer/notifications/{id}/read",
    responses={
        200: {"description": "Marked as read"},
    },
    tags=["Messaging"],
    summary="Mark Notification as Read",
)
async def employer_notifications_id_read_patch(
    id: str = Path(..., description="The notification UUID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().employer_notifications_id_read_patch(id)


# ══════════════════════════════════════════════════════════════════
# CANDIDATE-FACING ENDPOINTS  (inbox + notifications)
# ══════════════════════════════════════════════════════════════════

@router.get(
    "/candidate/inbox",
    responses={200: {"description": "List of conversations (candidate view)"}},
    tags=["Messaging"],
    summary="Candidate: List Inbox Conversations",
)
async def candidate_inbox_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().candidate_inbox_get()


@router.get(
    "/candidate/inbox/{employer_id}",
    responses={200: {"description": "Message thread with a specific employer"}},
    tags=["Messaging"],
    summary="Candidate: Get Messages from Employer",
)
async def candidate_inbox_employer_get(
    employer_id: str = Path(..., description="Employer user ID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().candidate_inbox_employer_get(employer_id)


@router.post(
    "/candidate/inbox/{employer_id}/reply",
    responses={201: {"description": "Reply sent"}},
    tags=["Messaging"],
    summary="Candidate: Reply to Employer Message",
)
async def candidate_inbox_reply_post(
    employer_id: str = Path(..., description="Employer user ID"),
    message: str = Body(..., embed=True),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().candidate_inbox_reply_post(employer_id, message)


@router.get(
    "/candidate/notifications",
    responses={200: {"description": "Candidate notifications"}},
    tags=["Messaging"],
    summary="Candidate: List Notifications",
)
async def candidate_notifications_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().candidate_notifications_get()


@router.patch(
    "/candidate/notifications/{id}/read",
    responses={200: {"description": "Marked as read"}},
    tags=["Messaging"],
    summary="Candidate: Mark Notification as Read",
)
async def candidate_notifications_read_patch(
    id: str = Path(..., description="Notification UUID"),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> Any:
    if not BaseMessagingNotificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseMessagingNotificationsApi.subclasses[0]().candidate_notifications_read_patch(id)
