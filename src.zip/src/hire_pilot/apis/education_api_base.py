# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field, StrictStr
from typing import Any, List
from typing_extensions import Annotated
from hire_pilot.models.education import Education
from hire_pilot.models.education_input import EducationInput
from hire_pilot.security_api import get_token_bearerAuth

class BaseEducationApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseEducationApi.subclasses = BaseEducationApi.subclasses + (cls,)
    async def profile_education_get(
        self,
    ) -> List[Education]:
        ...


    async def profile_education_id_delete(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Any:
        ...


    async def profile_education_id_get(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
    ) -> Education:
        ...


    async def profile_education_id_put(
        self,
        id: Annotated[StrictStr, Field(description="The UUID of the specific resource")],
        education_input: EducationInput,
    ) -> Any:
        ...


    async def profile_education_post(
        self,
        education_input: EducationInput,
    ) -> Any:
        ...
