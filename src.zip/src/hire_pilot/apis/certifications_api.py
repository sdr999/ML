# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.certifications_api_base import BaseCertificationsApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from hire_pilot.models.error_response import ErrorResponse
from pydantic import Field, StrictStr
from typing import Any, List
from typing_extensions import Annotated
from hire_pilot.models.certification import Certification
from hire_pilot.models.certification_input import CertificationInput
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/certifications",
    responses={
        200: {"model": List[Certification], "description": "List of certifications"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Certifications"],
    summary="Get all certifications",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_certifications_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[Certification]:
    if not BaseCertificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCertificationsApi.subclasses[0]().profile_certifications_get()


@router.delete(
    "/profile/certifications/{id}",
    responses={
        200: {"description": "Deleted"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Certification not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Certifications"],
    summary="Delete certification",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_certifications_id_delete(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseCertificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCertificationsApi.subclasses[0]().profile_certifications_id_delete(id)


@router.get(
    "/profile/certifications/{id}",
    responses={
        200: {"model": Certification, "description": "Certification detail"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Certification not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Certifications"],
    summary="Get specific certification",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_certifications_id_get(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Certification:
    if not BaseCertificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCertificationsApi.subclasses[0]().profile_certifications_id_get(id)


@router.put(
    "/profile/certifications/{id}",
    responses={
        200: {"description": "Updated"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Certification not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Certifications"],
    summary="Update certification",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_certifications_id_put(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    certification_input: CertificationInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseCertificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCertificationsApi.subclasses[0]().profile_certifications_id_put(id, certification_input)


@router.post(
    "/profile/certifications",
    responses={
        201: {"description": "Created"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Certifications"],
    summary="Add certification",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def profile_certifications_post(
    certification_input: CertificationInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseCertificationsApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCertificationsApi.subclasses[0]().profile_certifications_post(certification_input)
