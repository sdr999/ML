# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.languages_api_base import BaseLanguagesApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import Field, StrictStr
from typing import Any, List
from hire_pilot.models.error_response import ErrorResponse
from typing_extensions import Annotated
from hire_pilot.models.language import Language
from hire_pilot.models.language_input import LanguageInput
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/languages",
    responses={
        200: {"model": List[Language], "description": "List of languages"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Languages"],
    summary="Get all languages",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_languages_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[Language]:
    if not BaseLanguagesApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseLanguagesApi.subclasses[0]().profile_languages_get()


@router.delete(
    "/profile/languages/{id}",
    responses={
        200: {"description": "Deleted"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Language not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Languages"],
    summary="Delete language",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_languages_id_delete(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseLanguagesApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseLanguagesApi.subclasses[0]().profile_languages_id_delete(id)


@router.get(
    "/profile/languages/{id}",
    responses={
        200: {"model": Language, "description": "Language detail"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Language not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Languages"],
    summary="Get specific language",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_languages_id_get(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Language:
    if not BaseLanguagesApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseLanguagesApi.subclasses[0]().profile_languages_id_get(id)


@router.put(
    "/profile/languages/{id}",
    responses={
        200: {"description": "Updated"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Language not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Languages"],
    summary="Update language",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_languages_id_put(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    language_input: LanguageInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseLanguagesApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseLanguagesApi.subclasses[0]().profile_languages_id_put(id, language_input)


@router.post(
    "/profile/languages",
    responses={
        201: {"description": "Created"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Languages"],
    summary="Add language",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def profile_languages_post(
    language_input: LanguageInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseLanguagesApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseLanguagesApi.subclasses[0]().profile_languages_post(language_input)
