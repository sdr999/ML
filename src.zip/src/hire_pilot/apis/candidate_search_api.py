# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.candidate_search_api_base import BaseCandidateSearchApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import Field, StrictInt, StrictStr
from typing import Any, Optional
from typing_extensions import Annotated
from uuid import UUID
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/employer/candidates/search",
    responses={
        200: {"description": "Search results"},
    },
    tags=["Candidate Search"],
    summary="Search Candidates",
    response_model_by_alias=True,
)
async def employer_candidates_search_get(
    skills: Optional[StrictStr] = Query(None, description="", alias="skills"),
    experience: Optional[int] = Query(None, description="", alias="experience"),
    location: Optional[StrictStr] = Query(None, description="", alias="location"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseCandidateSearchApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCandidateSearchApi.subclasses[0]().employer_candidates_search_get(skills, experience, location)


@router.post(
    "/employer/candidates/search",
    responses={
        200: {"description": "Search results"},
    },
    tags=["Candidate Search"],
    summary="Advanced Candidate Search",
    response_model_by_alias=True,
)
async def employer_candidates_search_post(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseCandidateSearchApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCandidateSearchApi.subclasses[0]().employer_candidates_search_post()


@router.get(
    "/employer/candidates/{candidateId}",
    responses={
        200: {"description": "Candidate details"},
    },
    tags=["Candidate Search"],
    summary="Get Candidate Profile",
    response_model_by_alias=True,
)
async def employer_candidates_candidate_id_get(
    candidateId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseCandidateSearchApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCandidateSearchApi.subclasses[0]().employer_candidates_candidate_id_get(candidateId)


@router.post(
    "/employer/searches/save",
    responses={
        201: {"description": "Search saved"},
    },
    tags=["Candidate Search"],
    summary="Save Search Filters",
    response_model_by_alias=True,
)
async def employer_searches_save_post(
    body: Dict[str, Any] = Body(None),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseCandidateSearchApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCandidateSearchApi.subclasses[0]().employer_searches_save_post(body)



@router.get(
    "/employer/searches",
    responses={
        200: {"description": "List of saved searches"},
    },
    tags=["Candidate Search"],
    summary="List Saved Searches",
    response_model_by_alias=True,
)
async def employer_searches_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseCandidateSearchApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCandidateSearchApi.subclasses[0]().employer_searches_get()


@router.delete(
    "/employer/searches/{id}",
    responses={
        204: {"description": "Deleted"},
    },
    tags=["Candidate Search"],
    summary="Delete Saved Search",
    response_model_by_alias=True,
)
async def employer_searches_id_delete(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseCandidateSearchApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCandidateSearchApi.subclasses[0]().employer_searches_id_delete(id)


@router.get(
    "/employer/talent-pools",
    responses={
        200: {"description": "List of pools"},
    },
    tags=["Talent Pool"],
    summary="List Talent Pools",
    response_model_by_alias=True,
)
async def employer_talent_pools_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseCandidateSearchApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCandidateSearchApi.subclasses[0]().employer_talent_pools_get()


@router.post(
    "/employer/talent-pools",
    responses={
        201: {"description": "Pool created"},
    },
    tags=["Talent Pool"],
    summary="Create Talent Pool",
    response_model_by_alias=True,
)
async def employer_talent_pools_post(
    name: str = Body(..., embed=True),
    description: Optional[str] = Body(None, embed=True),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseCandidateSearchApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCandidateSearchApi.subclasses[0]().employer_talent_pools_post(name, description)


@router.post(
    "/employer/talent-pools/{id}/candidates",
    responses={
        201: {"description": "Candidate added"},
    },
    tags=["Talent Pool"],
    summary="Add Candidate to Pool",
    response_model_by_alias=True,
)
async def employer_talent_pools_id_candidates_post(
    id: str = Path(..., description="The UUID of the specific resource"),
    candidate_id: str = Body(..., embed=True),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseCandidateSearchApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseCandidateSearchApi.subclasses[0]().employer_talent_pools_id_candidates_post(id, candidate_id)

