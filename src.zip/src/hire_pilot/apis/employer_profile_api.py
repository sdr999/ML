# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.employer_profile_api_base import BaseEmployerProfileApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from typing import Any
from hire_pilot.models.company_profile import CompanyProfile
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/employer/profile",
    responses={
        200: {"description": "Profile retrieved"},
    },
    tags=["Employer Profile"],
    summary="Get Employer Profile",
    response_model_by_alias=True,
)
async def employer_profile_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseEmployerProfileApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerProfileApi.subclasses[0]().employer_profile_get()


@router.put(
    "/employer/profile",
    responses={
        200: {"description": "Profile updated"},
    },
    tags=["Employer Profile"],
    summary="Update Employer Profile",
    response_model_by_alias=True,
)
async def employer_profile_put(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseEmployerProfileApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerProfileApi.subclasses[0]().employer_profile_put()


@router.get(
    "/employer/company",
    responses={
        200: {"model": CompanyProfile, "description": "Company info retrieved"},
    },
    tags=["Employer Profile"],
    summary="Get Company Details",
    response_model_by_alias=True,
)
async def employer_company_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> CompanyProfile:
    if not BaseEmployerProfileApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerProfileApi.subclasses[0]().employer_company_get()


@router.put(
    "/employer/company",
    responses={
        200: {"description": "Company info updated"},
    },
    tags=["Employer Profile"],
    summary="Update Company Details",
    response_model_by_alias=True,
)
async def employer_company_put(
    company_profile: CompanyProfile = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseEmployerProfileApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerProfileApi.subclasses[0]().employer_company_put(company_profile)


@router.post(
    "/employer/company/logo",
    responses={
        200: {"description": "Logo uploaded"},
    },
    tags=["Employer Profile"],
    summary="Upload Company Logo",
    response_model_by_alias=True,
)
async def employer_company_logo_post(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseEmployerProfileApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerProfileApi.subclasses[0]().employer_company_logo_post()


@router.post(
    "/employer/company/documents",
    responses={
        200: {"description": "Documents uploaded"},
    },
    tags=["Employer Profile"],
    summary="Upload Company Documents",
    response_model_by_alias=True,
)
async def employer_company_documents_post(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseEmployerProfileApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEmployerProfileApi.subclasses[0]().employer_company_documents_post()
