# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from pydantic import Field, StrictInt, StrictStr
from typing import Any, Optional
from typing_extensions import Annotated
from uuid import UUID
from hire_pilot.security_api import get_token_bearerAuth

class BaseCandidateSearchApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseCandidateSearchApi.subclasses = BaseCandidateSearchApi.subclasses + (cls,)
    async def employer_candidates_search_get(
        self,
        skills: Optional[StrictStr],
        experience: Optional[StrictInt],
        location: Optional[StrictStr],
    ) -> None:
        ...


    async def employer_candidates_search_post(
        self,
    ) -> Any:
        ...


    async def employer_candidates_candidate_id_get(
        self,
        candidateId: str,
    ) -> Any:
        ...


    async def employer_searches_save_post(
        self,
        body: Optional[Dict[str, Any]] = None,
    ) -> Any:
        ...


    async def employer_searches_get(
        self,
    ) -> Any:
        ...


    async def employer_searches_id_delete(
        self,
        id: str,
    ) -> Any:
        ...


    async def employer_talent_pools_get(
        self,
    ) -> Any:
        ...


    async def employer_talent_pools_post(
        self,
        name: str,
        description: Optional[str] = None,
    ) -> Any:
        ...


    async def employer_talent_pools_id_candidates_post(
        self,
        id: str,
        candidate_id: str,
    ) -> Any:
        ...

