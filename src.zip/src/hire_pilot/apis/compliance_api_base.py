# coding: utf-8

from typing import ClassVar, List, Tuple
from hire_pilot.models.moderation_report import ModerationReport, ReportCandidateRequest
from hire_pilot.models.policy import Policy


class BaseComplianceApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseComplianceApi.subclasses = BaseComplianceApi.subclasses + (cls,)

    async def employer_policies_get(self) -> List[Policy]:
        ...

    async def employer_report_candidate_post(
        self, body: ReportCandidateRequest
    ) -> ModerationReport:
        ...
