# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.team_management_api_base import BaseTeamManagementApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import StrictStr
from typing import Any, List
from uuid import UUID
from hire_pilot.models.team_member import TeamMember
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/employer/team",
    responses={
        200: {"model": List[TeamMember], "description": "List of members"},
    },
    tags=["Team Management"],
    summary="List Team Members",
    response_model_by_alias=True,
)
async def employer_team_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[TeamMember]:
    if not BaseTeamManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseTeamManagementApi.subclasses[0]().employer_team_get()


@router.post(
    "/employer/team/invite",
    responses={
        201: {"description": "Invitation sent"},
    },
    tags=["Team Management"],
    summary="Invite Team Member",
    response_model_by_alias=True,
)
async def employer_team_invite_post(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseTeamManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseTeamManagementApi.subclasses[0]().employer_team_invite_post()


@router.put(
    "/employer/team/{memberId}/role",
    responses={
        200: {"description": "Role updated"},
    },
    tags=["Team Management"],
    summary="Update Member Role",
    response_model_by_alias=True,
)
async def employer_team_member_id_role_put(
    memberId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseTeamManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseTeamManagementApi.subclasses[0]().employer_team_member_id_role_put(memberId)


@router.delete(
    "/employer/team/{memberId}",
    responses={
        204: {"description": "Member removed"},
    },
    tags=["Team Management"],
    summary="Remove Team Member",
    response_model_by_alias=True,
)
async def employer_team_member_id_delete(
    memberId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseTeamManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseTeamManagementApi.subclasses[0]().employer_team_member_id_delete(memberId)
