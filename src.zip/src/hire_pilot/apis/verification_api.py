# coding: utf-8

from typing import List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.verification_api_base import BaseVerificationApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    HTTPException,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from hire_pilot.models.verification_request import VerificationSubmitRequest
from hire_pilot.models.verification_status import VerificationStatus
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.post(
    "/employer/verification/pan",
    responses={201: {"model": VerificationStatus, "description": "PAN verification submitted"}},
    tags=["Admin/Moderation"],
    summary="Submit PAN Verification",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def employer_verification_pan_post(
    body: VerificationSubmitRequest = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> VerificationStatus:
    if not BaseVerificationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseVerificationApi.subclasses[0]().employer_verification_pan_post(body)


@router.post(
    "/employer/verification/gst",
    responses={201: {"model": VerificationStatus, "description": "GST verification submitted"}},
    tags=["Admin/Moderation"],
    summary="Submit GST Verification",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def employer_verification_gst_post(
    body: VerificationSubmitRequest = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> VerificationStatus:
    if not BaseVerificationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseVerificationApi.subclasses[0]().employer_verification_gst_post(body)


@router.post(
    "/employer/verification/company-docs",
    responses={201: {"model": VerificationStatus, "description": "Company docs submitted"}},
    tags=["Admin/Moderation"],
    summary="Submit Company Documents",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def employer_verification_company_docs_post(
    body: VerificationSubmitRequest = Body(...),
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> VerificationStatus:
    if not BaseVerificationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseVerificationApi.subclasses[0]().employer_verification_company_docs_post(body)


@router.get(
    "/employer/verification/status",
    responses={200: {"model": List[VerificationStatus], "description": "Verification statuses"}},
    tags=["Admin/Moderation"],
    summary="Get Verification Status",
    response_model_by_alias=True,
)
async def employer_verification_status_get(
    token_bearerAuth: TokenModel = Security(get_token_bearerAuth),
) -> List[VerificationStatus]:
    if not BaseVerificationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseVerificationApi.subclasses[0]().employer_verification_status_get()
