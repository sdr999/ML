# coding: utf-8

from typing import ClassVar, Dict, List, Tuple, Any, Optional

class BaseInterviewManagementApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseInterviewManagementApi.subclasses = BaseInterviewManagementApi.subclasses + (cls,)

    async def employer_interviews_get(self) -> Any:
        ...

    async def employer_interviews_post(
        self,
        candidate_id: str,
        job_id: str,
        scheduled_at: str,
        duration_minutes: int,
        title: str,
        description: Optional[str] = None
    ) -> Any:
        ...

    async def employer_interviews_id_put(
        self,
        id: str,
        scheduled_at: str,
        duration_minutes: Optional[int] = None,
        title: Optional[str] = None,
        description: Optional[str] = None
    ) -> Any:
        ...

    async def employer_interviews_id_delete(self, id: str) -> Any:
        ...

    async def employer_interviews_slots_get(self) -> Any:
        ...

    async def employer_interviews_slots_post(
        self,
        slots: List[str]  # ISO format slot times
    ) -> Any:
        ...

    async def employer_interviews_id_feedback_get(self, id: str) -> Any:
        ...

    async def employer_interviews_id_feedback_post(
        self,
        id: str,
        rating: int,
        comments: str,
        recommendation: str
    ) -> Any:
        ...

    async def candidate_interviews_get(self) -> Any:
        ...

    async def candidate_interview_respond_patch(
        self, interview_id: str, candidate_status: str, notes: Optional[str]
    ) -> Any:
        ...
