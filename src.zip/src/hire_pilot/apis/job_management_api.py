# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.job_management_api_base import BaseJobManagementApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import Field, StrictStr
from typing import Any, List, Optional
from typing_extensions import Annotated
from uuid import UUID
from hire_pilot.models.job import Job
from hire_pilot.models.job_input import JobInput
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/employer/jobs/recommendations",
    responses={
        200: {"model": List[Job], "description": "List of recommended jobs"},
    },
    tags=["Job Management"],
    summary="Get Recommended Jobs",
    response_model_by_alias=True,
)
async def employer_jobs_recommendations_get(
    page: Annotated[Optional[Annotated[int, Field(ge=1)]], Field(description="Page number for pagination")] = Query(1, description="Page number for pagination", alias="page", ge=1),
    limit: Annotated[Optional[Annotated[int, Field(le=100, ge=1)]], Field(description="Number of items to return per page")] = Query(20, description="Number of items to return per page", alias="limit", ge=1, le=100),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[Job]:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_recommendations_get(page, limit)


@router.get(
    "/employer/jobs",
    responses={
        200: {"model": List[Job], "description": "List of jobs"},
    },
    tags=["Job Management"],
    summary="List Jobs",
    response_model_by_alias=True,
)
async def employer_jobs_get(
    page: Annotated[Optional[Annotated[int, Field(ge=1)]], Field(description="Page number for pagination")] = Query(1, description="Page number for pagination", alias="page", ge=1),
    limit: Annotated[Optional[Annotated[int, Field(le=100, ge=1)]], Field(description="Number of items to return per page")] = Query(20, description="Number of items to return per page", alias="limit", ge=1, le=100),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[Job]:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_get(page, limit)


@router.post(
    "/employer/jobs",
    responses={
        201: {"description": "Job created"},
    },
    tags=["Job Management"],
    summary="Create Job",
    response_model_by_alias=True,
)
async def employer_jobs_post(
    job_input: JobInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_post(job_input)


@router.get(
    "/employer/jobs/{jobId}",
    responses={
        200: {"model": Job, "description": "Job details"},
    },
    tags=["Job Management"],
    summary="Get Job Details",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_get(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Job:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_get(jobId)


@router.put(
    "/employer/jobs/{jobId}",
    responses={
        200: {"description": "Job updated"},
    },
    tags=["Job Management"],
    summary="Update Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_put(
    jobId: StrictStr = Path(..., description=""),
    job_input: JobInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_put(jobId, job_input)


@router.delete(
    "/employer/jobs/{jobId}",
    responses={
        204: {"description": "Job deleted"},
    },
    tags=["Job Management"],
    summary="Delete Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_delete(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_delete(jobId)


@router.patch(
    "/employer/jobs/{jobId}/publish",
    responses={
        200: {"description": "Job published"},
    },
    tags=["Job Management"],
    summary="Publish Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_publish_patch(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_publish_patch(jobId)


@router.patch(
    "/employer/jobs/{jobId}/pause",
    responses={
        200: {"description": "Job paused"},
    },
    tags=["Job Management"],
    summary="Pause Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_pause_patch(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_pause_patch(jobId)


@router.patch(
    "/employer/jobs/{jobId}/close",
    responses={
        200: {"description": "Job closed"},
    },
    tags=["Job Management"],
    summary="Close Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_close_patch(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_close_patch(jobId)


@router.patch(
    "/employer/jobs/{jobId}/archive",
    responses={
        200: {"description": "Job archived"},
    },
    tags=["Job Management"],
    summary="Archive Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_archive_patch(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_archive_patch(jobId)


@router.post(
    "/employer/jobs/{jobId}/duplicate",
    responses={
        201: {"description": "Job duplicated"},
    },
    tags=["Job Management"],
    summary="Duplicate Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_duplicate_post(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_duplicate_post(jobId)


@router.post(
    "/employer/jobs/{jobId}/repost",
    responses={
        201: {"description": "Job reposted"},
    },
    tags=["Job Management"],
    summary="Repost Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_repost_post(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_repost_post(jobId)


@router.post(
    "/employer/jobs/{jobId}/boost",
    responses={
        200: {"description": "Job boosted"},
    },
    tags=["Job Management"],
    summary="Boost Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_boost_post(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_boost_post(jobId)


@router.post(
    "/employer/jobs/{jobId}/feature",
    responses={
        200: {"description": "Job featured"},
    },
    tags=["Job Management"],
    summary="Feature Job",
    response_model_by_alias=True,
)
async def employer_jobs_job_id_feature_post(
    jobId: StrictStr = Path(..., description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_jobs_job_id_feature_post(jobId)


@router.get(
    "/employer/job-templates",
    responses={
        200: {"description": "List of templates"},
    },
    tags=["Job Management"],
    summary="List Job Templates",
    response_model_by_alias=True,
)
async def employer_job_templates_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_job_templates_get()


@router.post(
    "/employer/job-templates",
    responses={
        201: {"description": "Template created"},
    },
    tags=["Job Management"],
    summary="Create Job Template",
    response_model_by_alias=True,
)
async def employer_job_templates_post(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_job_templates_post()


@router.put(
    "/employer/job-templates/{id}",
    responses={
        200: {"description": "Template updated"},
    },
    tags=["Job Management"],
    summary="Update Job Template",
    response_model_by_alias=True,
)
async def employer_job_templates_id_put(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_job_templates_id_put(id)


@router.delete(
    "/employer/job-templates/{id}",
    responses={
        204: {"description": "Template deleted"},
    },
    tags=["Job Management"],
    summary="Delete Job Template",
    response_model_by_alias=True,
)
async def employer_job_templates_id_delete(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseJobManagementApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseJobManagementApi.subclasses[0]().employer_job_templates_id_delete(id)
