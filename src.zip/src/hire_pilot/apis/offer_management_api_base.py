# coding: utf-8

from typing import ClassVar, Tuple
from hire_pilot.models.offer import Offer, OfferInput, OfferResponseInput


class BaseOfferManagementApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseOfferManagementApi.subclasses = BaseOfferManagementApi.subclasses + (cls,)

    async def employer_applications_offer_post(
        self, application_id: str, body: OfferInput
    ) -> Offer:
        ...

    async def candidate_applications_offer_respond_patch(
        self, application_id: str, body: OfferResponseInput
    ) -> Offer:
        ...
