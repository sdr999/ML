# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.profile_photo_api_base import BaseProfilePhotoApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from typing import Any
from hire_pilot.models.profile_photo_get200_response import ProfilePhotoGet200Response
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.delete(
    "/profile/photo",
    responses={
        204: {"description": "Photo removed"},
    },
    tags=["Profile Photo"],
    summary="Remove profile photo",
    response_model_by_alias=True,
)
async def profile_photo_delete(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseProfilePhotoApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseProfilePhotoApi.subclasses[0]().profile_photo_delete()


@router.get(
    "/profile/photo",
    responses={
        200: {"model": ProfilePhotoGet200Response, "description": "Profile photo base64"},
    },
    tags=["Profile Photo"],
    summary="Get profile photo",
    response_model_by_alias=True,
)
async def profile_photo_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> ProfilePhotoGet200Response:
    if not BaseProfilePhotoApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseProfilePhotoApi.subclasses[0]().profile_photo_get()


@router.put(
    "/profile/photo",
    responses={
        200: {"description": "Photo updated"},
    },
    tags=["Profile Photo"],
    summary="Upload profile photo",
    response_model_by_alias=True,
)
async def profile_photo_put(
    profile_photo_get200_response: ProfilePhotoGet200Response = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> None:
    if not BaseProfilePhotoApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseProfilePhotoApi.subclasses[0]().profile_photo_put(profile_photo_get200_response)
