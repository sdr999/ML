# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from hire_pilot.apis.education_api_base import BaseEducationApi
import hire_pilot.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from hire_pilot.models.extra_models import TokenModel  # noqa: F401
from pydantic import Field, StrictStr
from typing import Any, List
from hire_pilot.models.error_response import ErrorResponse
from typing_extensions import Annotated
from hire_pilot.models.education import Education
from hire_pilot.models.education_input import EducationInput
from hire_pilot.security_api import get_token_bearerAuth

router = APIRouter()

ns_pkg = hire_pilot.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/profile/education",
    responses={
        200: {"model": List[Education], "description": "List of education details"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Education"],
    summary="Get all education",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_education_get(
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> List[Education]:
    if not BaseEducationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEducationApi.subclasses[0]().profile_education_get()


@router.delete(
    "/profile/education/{id}",
    responses={
        200: {"description": "Deleted"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Education not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Education"],
    summary="Delete specific education",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_education_id_delete(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseEducationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEducationApi.subclasses[0]().profile_education_id_delete(id)


@router.get(
    "/profile/education/{id}",
    responses={
        200: {"model": Education, "description": "Education detail"},
        400: {"model": ErrorResponse, "description": "Invalid ID format."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Education not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Education"],
    summary="Get specific education",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_education_id_get(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Education:
    if not BaseEducationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEducationApi.subclasses[0]().profile_education_id_get(id)


@router.put(
    "/profile/education/{id}",
    responses={
        200: {"description": "Updated"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters."},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        404: {"model": ErrorResponse, "description": "Education not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Education"],
    summary="Update specific education",
    response_model_by_alias=True,
    status_code=status.HTTP_200_OK,
)
async def profile_education_id_put(
    id: Annotated[StrictStr, Field(description="The UUID of the specific resource")] = Path(..., description="The UUID of the specific resource"),
    education_input: EducationInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseEducationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEducationApi.subclasses[0]().profile_education_id_put(id, education_input)


@router.post(
    "/profile/education",
    responses={
        201: {"description": "Created"},
        400: {"model": ErrorResponse, "description": "Bad request (e.g., limit of 3 exceeded)"},
        401: {"model": ErrorResponse, "description": "Unauthorized."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    tags=["Education"],
    summary="Add education (Max 3)",
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def profile_education_post(
    education_input: EducationInput = Body(None, description=""),
    token_bearerAuth: TokenModel = Security(
        get_token_bearerAuth
    ),
) -> Any:
    if not BaseEducationApi.subclasses:
        raise HTTPException(status_code=500, detail="Not implemented")
    return await BaseEducationApi.subclasses[0]().profile_education_post(education_input)
