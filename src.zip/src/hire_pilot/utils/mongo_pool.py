"""
Global MongoDB connection pool — single AsyncIOMotorClient shared across all requests.

Motor's AsyncIOMotorClient is thread-safe and manages an internal connection pool
(default maxPoolSize=100). Creating one client per request wastes TLS handshakes,
TCP connections, and auth round-trips. This module ensures a single client is
created at startup and reused for the lifetime of the process.
"""

import os
import asyncio
import logging
from typing import Optional

import certifi
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from dotenv import dotenv_values, load_dotenv

log = logging.getLogger(__name__)

env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../", "config", ".env")
env = dotenv_values(dotenv_path=env_path)
load_dotenv(dotenv_path=env_path)

_client: Optional[AsyncIOMotorClient] = None
_db: Optional[AsyncIOMotorDatabase] = None

# ── Tunable pool settings ─────────────────────────────────────────────────────
# maxPoolSize  : max simultaneous connections per process (default 100)
# minPoolSize  : keep this many connections warm (avoids cold-start latency)
# maxIdleTimeMS: drop idle connections after this many ms
# connectTimeoutMS / socketTimeoutMS: fail fast rather than hang
# serverSelectionTimeoutMS: how long to wait for a healthy primary
_POOL_CONFIG = dict(
    maxPoolSize=200,
    minPoolSize=10,
    maxIdleTimeMS=30_000,
    connectTimeoutMS=5_000,
    socketTimeoutMS=10_000,
    serverSelectionTimeoutMS=5_000,
    tlsCAFile=certifi.where(),
    # Retryable reads / writes — Motor 3.x supports these natively
    retryReads=True,
    retryWrites=True,
)


def get_mongo_client() -> AsyncIOMotorClient:
    """Return the global Motor client, initialising it on first call."""
    global _client
    if _client is None:
        uri = env.get("MONGODB_URI", "mongodb://localhost:27017")
        db_name = env.get("DB_NAME", "hire_pilot")
        if not uri or not db_name:
            raise RuntimeError("MONGODB_URI / DB_NAME not configured.")
        log.info("Initialising global MongoDB connection pool | maxPoolSize=%d", _POOL_CONFIG["maxPoolSize"])
        _client = AsyncIOMotorClient(uri, **_POOL_CONFIG)
    return _client


def get_database() -> AsyncIOMotorDatabase:
    """Return the global Motor database handle."""
    global _db
    if _db is None:
        db_name = env.get("DB_NAME", "hire_pilot")
        _db = get_mongo_client()[db_name]
    return _db


async def close_mongo_connection() -> None:
    """Cleanly close the Motor client on shutdown."""
    global _client, _db
    if _client is not None:
        log.info("Closing global MongoDB connection pool.")
        _client.close()
        _client = None
        _db = None


async def ensure_indexes() -> None:
    """
    Create all performance-critical MongoDB indexes at startup.

    Compound + single-field indexes are idempotent — running this on every
    startup is safe; Motor skips creation if the index already exists.
    """
    db = get_database()
    log.info("Ensuring MongoDB indexes…")

    # ── jobs ──────────────────────────────────────────────────────────────────
    jobs = db["jobs"]
    await asyncio.gather(
        jobs.create_index("employer_id"),                         # list by employer
        jobs.create_index("status"),                              # filter PUBLISHED
        jobs.create_index([("status", 1), ("created_at", -1)]),  # explore feed
        jobs.create_index("skills"),                              # skill-match
        jobs.create_index("location"),                            # location filter
        jobs.create_index([("employer_id", 1), ("status", 1)]),  # employer active jobs
    )

    # ── applications ──────────────────────────────────────────────────────────
    apps = db["applications"]
    await asyncio.gather(
        apps.create_index("candidate_id"),
        apps.create_index("job_id"),
        apps.create_index([("job_id", 1), ("status", 1)]),
        apps.create_index([("candidate_id", 1), ("status", 1)]),
        apps.create_index([("employer_id", 1), ("created_at", -1)]),
    )

    # ── interviews ────────────────────────────────────────────────────────────
    interviews = db["interviews"]
    await asyncio.gather(
        interviews.create_index("employer_id"),
        interviews.create_index("candidate_id"),
        interviews.create_index([("employer_id", 1), ("scheduled_at", 1)]),
        interviews.create_index([("candidate_id", 1), ("scheduled_at", 1)]),
    )

    # ── messages ─────────────────────────────────────────────────────────────
    messages = db["messages"]
    await asyncio.gather(
        messages.create_index([("employer_id", 1), ("candidate_id", 1)]),
        messages.create_index([("candidate_id", 1), ("timestamp", -1)]),
        messages.create_index([("employer_id", 1), ("timestamp", -1)]),
    )

    # ── notifications ─────────────────────────────────────────────────────────
    notifications = db["notifications"]
    await asyncio.gather(
        notifications.create_index([("user_id", 1), ("read", 1)]),
        notifications.create_index([("user_id", 1), ("created_at", -1)]),
    )

    # ── users / profiles ──────────────────────────────────────────────────────
    users = db["users"]
    await asyncio.gather(
        users.create_index("user_id", unique=True),
        users.create_index("email", unique=True),
        users.create_index("role"),
    )

    for col in ["basic_info", "profile_skills", "profile_summary",
                "work_experience", "education", "certifications",
                "achievements", "languages", "personal_projects",
                "employment_details", "diversity"]:
        await db[col].create_index("user_id")

    # ── employer / company ────────────────────────────────────────────────────
    await db["companies"].create_index("employer_id", unique=True)
    await db["employer_profiles"].create_index("user_id", unique=True)
    await db["team_members"].create_index("employer_id")
    await db["team_members"].create_index("email")

    # ── analytics_events ─────────────────────────────────────────────────────
    analytics_events = db["analytics_events"]
    await asyncio.gather(
        analytics_events.create_index([("employer_id", 1), ("event_type", 1)]),
        analytics_events.create_index([("job_id", 1), ("event_type", 1)]),
        analytics_events.create_index("timestamp"),
    )

    # ── verifications ────────────────────────────────────────────────────────
    verifications = db["verifications"]
    await asyncio.gather(
        verifications.create_index([("employer_id", 1), ("type", 1)], unique=True),
        verifications.create_index("status"),
    )

    # ── moderation_reports ───────────────────────────────────────────────────
    mod_reports = db["moderation_reports"]
    await asyncio.gather(
        mod_reports.create_index("reporter_id"),
        mod_reports.create_index("reported_candidate_id"),
        mod_reports.create_index([("reporter_id", 1), ("status", 1)]),
    )

    log.info("MongoDB indexes ensured successfully.")
