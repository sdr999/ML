import logging
import uuid
import contextvars

# 1. Define a ContextVar to store the trace ID
trace_id_var = contextvars.ContextVar("trace_id", default="n/a")

# 2. Add a custom 'TRACE' level (lower than DEBUG)
TRACE_LEVEL_NUM = 5
logging.addLevelName(TRACE_LEVEL_NUM, "TRACE")

def trace(self, message, *args, **kws):
    if self.isEnabledFor(TRACE_LEVEL_NUM):
        self._log(TRACE_LEVEL_NUM, message, args, **kws)

logging.Logger.trace = trace

# 3. Custom Filter to inject trace_id into every log record
class TraceFilter(logging.Filter):
    def filter(self, record):
        record.trace_id = trace_id_var.get()
        return True

def setup_logger():
    # 4. Configure formatting
    log_format = (
        "%(asctime)s | %(levelname)-8s | [Trace: %(trace_id)s] | %(message)s"
    )
    
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(log_format))
    handler.addFilter(TraceFilter())

    logger = logging.getLogger("AppLogger")
    logger.addHandler(handler)
    logger.setLevel(TRACE_LEVEL_NUM) # Capture everything
    
    return logger

# Initialize
log = setup_logger()