"""
MongoAdapter — thin async CRUD wrapper around the global Motor connection pool.

IMPORTANT: The adapter NO LONGER creates its own AsyncIOMotorClient.
Instead it pulls the shared database handle from mongo_pool.get_database(),
which means every repository instance reuses the same underlying TCP connection
pool rather than opening a brand-new one on each request.
"""

from typing import Any, Dict, List, Optional
from pymongo.results import InsertOneResult, UpdateResult, DeleteResult

from hire_pilot.utils.mongo_pool import get_database


class MongoAdapter:
    """
    Thin async CRUD wrapper.

    The ``uri`` / ``db_name`` constructor parameters are kept for backward
    compatibility but are now *ignored* — the global pool is always used.
    """

    def __init__(self, uri: str = "", db_name: str = ""):
        # Pull the shared, pre-warmed Motor database from the pool module.
        # This is effectively a no-op after the first call because get_database()
        # is cached at the module level.
        self.db = get_database()

    def get_collection(self, collection_name: str):
        return self.db[collection_name]

    # ── CREATE ────────────────────────────────────────────────────────────────

    async def insert_one(self, collection: str, document: Dict[str, Any]) -> str:
        result: InsertOneResult = await self.get_collection(collection).insert_one(document)
        return str(result.inserted_id)

    async def insert_many(self, collection: str, documents: List[Dict[str, Any]]) -> List[str]:
        result = await self.get_collection(collection).insert_many(documents)
        return [str(i) for i in result.inserted_ids]

    # ── READ ──────────────────────────────────────────────────────────────────

    async def find_one(
        self,
        collection: str,
        query: Dict[str, Any],
        projection: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        return await self.get_collection(collection).find_one(query, projection)

    async def find_many(
        self,
        collection: str,
        query: Dict[str, Any],
        limit: int = 0,
        skip: int = 0,
        sort: Optional[List[tuple]] = None,
        projection: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        col = self.get_collection(collection)
        cursor = col.find(query, projection)
        if sort:
            cursor = cursor.sort(sort)
        if skip:
            cursor = cursor.skip(skip)
        if limit:
            cursor = cursor.limit(limit)
        # Always cap at 1000 to prevent unbounded memory usage.
        # Callers that truly need more should use pagination.
        return await cursor.to_list(length=limit if limit else 1000)

    async def count(self, collection: str, query: Dict[str, Any]) -> int:
        """Cheap index-only count — never fetches documents."""
        return await self.get_collection(collection).count_documents(query)

    # ── UPDATE ────────────────────────────────────────────────────────────────

    async def update_one(
        self,
        collection: str,
        query: Dict[str, Any],
        update_data: Dict[str, Any],
    ) -> int:
        has_operators = any(k.startswith("$") for k in update_data)
        update_doc = update_data if has_operators else {"$set": update_data}
        result: UpdateResult = await self.get_collection(collection).update_one(query, update_doc)
        return result.modified_count

    async def upsert_one(
        self,
        collection: str,
        query: Dict[str, Any],
        update_data: Dict[str, Any],
    ) -> int:
        has_operators = any(k.startswith("$") for k in update_data)
        update_doc = update_data if has_operators else {"$set": update_data}
        result: UpdateResult = await self.get_collection(collection).update_one(
            query, update_doc, upsert=True
        )
        return result.modified_count + (1 if result.upserted_id else 0)

    async def update_many(
        self,
        collection: str,
        query: Dict[str, Any],
        update_data: Dict[str, Any],
    ) -> int:
        has_operators = any(k.startswith("$") for k in update_data)
        update_doc = update_data if has_operators else {"$set": update_data}
        result: UpdateResult = await self.get_collection(collection).update_many(query, update_doc)
        return result.modified_count

    # ── DELETE ────────────────────────────────────────────────────────────────

    async def delete_one(self, collection: str, query: Dict[str, Any]) -> int:
        result: DeleteResult = await self.get_collection(collection).delete_one(query)
        return result.deleted_count

    async def delete_many(self, collection: str, query: Dict[str, Any]) -> int:
        result: DeleteResult = await self.get_collection(collection).delete_many(query)
        return result.deleted_count

    # ── AGGREGATION ───────────────────────────────────────────────────────────

    async def aggregate(
        self,
        collection: str,
        pipeline: List[Dict[str, Any]],
        allow_disk_use: bool = False,
    ) -> List[Dict[str, Any]]:
        cursor = self.get_collection(collection).aggregate(
            pipeline, allowDiskUse=allow_disk_use
        )
        return await cursor.to_list(length=None)

    # ── COMPATIBILITY ─────────────────────────────────────────────────────────

    def close(self) -> None:
        """No-op — the global pool is closed by the app lifecycle hook."""
        pass