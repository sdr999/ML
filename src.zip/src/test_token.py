import asyncio
import jwt
from pydantic import SecretStr
from hire_pilot.services.signup_service import SignupService
from hire_pilot.models.sign_up_request import SignUpRequest
from hire_pilot.models.sign_in_request import SignInRequest
import datetime
import time

async def main():
    service = SignupService()
    try:
        email = f"test_jwt_{int(time.time())}@gmail.com"
        
        user_reg = SignUpRequest(
            email=email, 
            password="Password123!", 
            confirm_password="Password123!",
            first_name="Test",
            last_name="User",
            mobile_no="1234567890",
            dob=datetime.date(1990, 1, 1)
        )
        try:
            await service.auth_signup_post(user_reg)
            print("Registration success")
        except Exception as e:
            print("Registration issue:", e)
        
        user_login = SignInRequest(
            username=email, 
            password=SecretStr("Password123!"),
            captcha="test"
        )
        res2 = await service.auth_signin_post(user_login)
        print("Login result access_token:", res2.access_token[:20] + "...")
        
        token = res2.access_token
        header = jwt.get_unverified_header(token)
        print("Token Header:", header)
        
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    asyncio.run(main())
